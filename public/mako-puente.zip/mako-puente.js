// =============================================================================
// El apretón de manos con MaKo — corre en hola-mako.com
// =============================================================================
// Existe para que el usuario NO tenga que copiar y pegar un código.
//
// Todo por el DOM y no por `externally_connectable`: ese mecanismo necesita el
// ID de la extensión, y el ID CAMBIA al publicarse en la Chrome Web Store.
// Marcando el DOM funciona igual instalada a mano o desde la tienda.
//
// ⚠️ EL SENTIDO SE DIO VUELTA. Antes la PÁGINA empujaba el token cuando alguien
// apretaba «Conectar» en la web. Ahora el botón vive en el popup de la extensión
// —el dueño: «esto tiene que ir DENTRO del desplegable de la extensión»— así que
// el pedido nace del service worker y la página pasa a ser un MENSAJERO:
//
//   popup ─CONECTAR─▶ SW ─EMPAREJAR─▶ este script
//                                       │  MAKO_PUENTE_PIDO_TOKEN (evento)
//                                       ▼
//                                    la página (PuenteEnlace.tsx) acuña con la
//                                    sesión del usuario y contesta por evento
//
// El acuñado NO se puede mover acá: el token nace de una server action con la
// cookie de sesión, y un fetch de extensión muere en el chequeo de Origin del
// proxy. Lo que se mudó al popup es el DISPARO y el RESULTADO.

document.documentElement.setAttribute('data-mako-puente', chrome.runtime.getManifest().version);

/** Cuántos ms se espera a que la página conteste el pedido de token. */
const ESPERA_MS = 12000;

/**
 * Le pide un token a la página y contesta al service worker.
 *
 * El `id` de correlación no es decorativo: los eventos son globales, así que sin
 * él dos pedidos en vuelo se resuelven con la respuesta del otro. Es la misma
 * razón que ya está escrita en `content.js`.
 */
function pedirToken(forzar) {
  return new Promise((resolve) => {
    const id = `p${Date.now()}${Math.random()}`;
    let cerrado = false;

    const cerrar = (out) => {
      if (cerrado) return;
      cerrado = true;
      clearTimeout(reloj);
      window.removeEventListener('MAKO_PUENTE_TOKEN', alToken);
      window.removeEventListener('MAKO_PUENTE_TOKEN_ERROR', alError);
      resolve(out);
    };

    const alToken = (ev) => {
      const d = (ev && ev.detail) || {};
      if (d.id !== id) return;
      const token = d.token;
      if (typeof token !== 'string' || !token.startsWith('flow_')) {
        cerrar({ ok: false, motivo: 'error' });
        return;
      }
      // Se guarda ACÁ y no en el service worker: es el único punto por el que
      // pasa el token, y guardarlo antes de contestar hace que el «ok» no pueda
      // ser más optimista que la realidad.
      // ⚠️ CAMBIAR DE CLIENTE TIENE QUE BORRAR LO APRENDIDO CON EL ANTERIOR.
      //
      // El respaldo de plantillas vive bajo UNA clave global (`plantillas`), sin
      // token ni workspace adentro. Antes esto pisaba solo el `token`, asi que el
      // navegador seguia con las plantillas del cliente anterior — y el latido
      // siguiente las subia al workspace nuevo: su projectId de Flow, el cuerpo
      // de su generacion y el mediaId de su cara terminaban guardados en la fila
      // de otro cliente, y de ahi bajaban al navegador real de ese otro.
      //
      // Es el caso normal del super-admin, que abre un cliente por pestaña.
      //
      // Se limpia SOLO cuando el token cambia: reconectar el mismo cliente no
      // puede costarle lo que ya habia aprendido, que es justo lo que evita
      // volver a pedirle que genere algo a mano.
      // ⚠️ SE COMPARA EL WORKSPACE, NO EL TOKEN — y la primera version comparaba
      // el token, que era un bug con cara de arreglo: `crearTokenPuente` acuña un
      // token NUEVO en cada conexion, asi que «el token cambio» era cierto hasta
      // reconectando el MISMO cliente, y con eso se le borraban las plantillas
      // que ya habia aprendido. El comentario decia lo contrario del codigo.
      const wsId = Number(d.wsId) || 0;
      chrome.storage.local.get(['wsId'], (previo) => {
        // Sin `wsId` no se borra nada: no saber de quien era es razon para
        // abstenerse, no para tirarle a alguien lo que le costo generar.
        const cambio = !!wsId && !!previo && !!previo.wsId && previo.wsId !== wsId;
        const guardar = () => chrome.storage.local.set(
          { token, wsId, workspaceNombre: String(d.workspace || '') },
          () => cerrar({ ok: true }),
        );
        if (!cambio) { guardar(); return; }
        // `firmaPlantillas` va con `plantillas` o el latido creeria que no cambio
        // nada y no volveria a subir las del cliente nuevo. `projectId` y
        // `ultimoRedirectMedio` son del proyecto de Flow del anterior.
        // ⚠️ Y LA SONDA TAMBIEN. `sondaResultado` lleva el mediaId completo del
        // cliente anterior y urls firmadas suyas; `sondaSW` lleva el resultado de
        // pedirlas. Si no se borran, el proximo latido —que ya es del cliente
        // NUEVO— los sube a SU fila: datos de un cliente guardados en el
        // workspace de otro, por el mismo camino que ya se cerro para las
        // plantillas y por el mismo motivo.
        //
        // Es el caso normal del super-admin, que abre un cliente por pestana.
        chrome.storage.local.remove(
          [
            'plantillas', 'firmaPlantillas', 'projectId', 'ultimoRedirectMedio',
            'sondaResultado', 'sondaSW', 'sondaOk',
          ],
          guardar,
        );
      });
    };

    const alError = (ev) => {
      const d = (ev && ev.detail) || {};
      if (d.id !== id) return;
      cerrar({ ok: false, motivo: String(d.motivo || 'error'), etiqueta: String(d.etiqueta || '') });
    };

    // ⚠️ EL TIMEOUT ES SU PROPIO MOTIVO, Y NO 'sesion'.
    //
    // Decía 'sesion', o sea que «nadie contestó» se convertía en la afirmación
    // «no iniciaste sesión» — sobre alguien que estaba logueada, mirando su
    // propio tablero, con la pestaña abierta. La reportó el dueño así: «Leila no
    // puede generar porque dice que MaKo no está conectado».
    //
    // Y la causa era otra: el enlace que contesta este pedido vivía adentro de
    // una vista de /video-generator, así que en cualquier otra pantalla de MaKo
    // no había nadie escuchando. El remedio de eso es RECARGAR la pestaña, que
    // no tiene nada que ver con iniciar sesión: mandarla a loguearse la manda a
    // arreglar algo que estaba bien.
    //
    // Es la regla de la casa: «no pude hacer X con este dato» no es «este dato es
    // falso», y un mensaje que sale solo no puede afirmar lo que no verificó.
    const reloj = setTimeout(() => cerrar({ ok: false, motivo: 'sin_enlace' }), ESPERA_MS);

    window.addEventListener('MAKO_PUENTE_TOKEN', alToken);
    window.addEventListener('MAKO_PUENTE_TOKEN_ERROR', alError);
    window.dispatchEvent(new CustomEvent('MAKO_PUENTE_PIDO_TOKEN', {
      detail: { id, forzar: !!forzar, etiqueta: navegador() },
    }));
  });
}

/** Un nombre que la persona reconozca en «ya hay otro navegador conectado». */
function navegador() {
  const ua = navigator.userAgent;
  const cual = /Edg\//.test(ua) ? 'Edge'
    : /OPR\//.test(ua) ? 'Opera'
      : /Brave/.test(ua) ? 'Brave'
        : /Chrome\//.test(ua) ? 'Chrome'
          : 'Navegador';
  const so = /Windows/.test(ua) ? 'Windows'
    : /Mac OS X/.test(ua) ? 'Mac'
      : /Linux/.test(ua) ? 'Linux'
        : '';
  return so ? `${cual} en ${so}` : cual;
}

chrome.runtime.onMessage.addListener((msg, _sender, responder) => {
  if (msg && msg.tipo === 'EMPAREJAR') {
    // ⚠️ El script corre en `document_start`: si la página todavía no hidrató,
    // `PuenteEnlace` no existe y nadie escucha el pedido. Por eso se espera a que
    // el enlace avise que está montado, con el mismo tope que el pedido — y si no
    // avisa se intenta igual, porque una pestaña ya hidratada antes de que este
    // script escuchara no va a volver a avisar nunca.
    void esperarEnlace().then(() => pedirToken(msg.forzar)).then(responder);
    return true;
  }
  return false;
});

// ── «Hay trabajo»: la pagina despierta al puente ────────────────────────────
// El sentido contrario al del emparejado. MaKo encola un trabajo y avisa en el
// acto, en vez de que la extension lo descubra en su proxima alarma — que es
// hasta medio minuto de loader sobre algo que ya estaba listo para empezar.
//
// Se ignora cualquier evento que no venga de esta misma pagina: `postMessage`
// lo puede disparar un iframe ajeno, y aunque lo unico que consigue es que el
// puente le pregunte a MaKo por trabajo suyo —con el token de este navegador y
// nada mas—, no hay razon para escuchar a un tercero.
//
// El estrangulador no es prolijidad: sin el, una pantalla que encola siete
// tomas de una manda siete avisos en el mismo tick. `ciclo()` ya es idempotente
// por `corriendo`, asi que serian seis mensajes al vacio.
let ultimoAviso = 0;

window.addEventListener('MAKO_PUENTE_HAY_TRABAJO', (ev) => {
  if (ev && ev.target !== window) return;
  const ahora = Date.now();
  if (ahora - ultimoAviso < 1500) return;
  ultimoAviso = ahora;
  try {
    chrome.runtime.sendMessage({ tipo: 'DESPERTAR' }, () => {
      // Leer `lastError` es lo que evita el «Unchecked runtime.lastError» en la
      // consola del cliente cuando el service worker todavia no desperto. No hay
      // nada que hacer con el error: el ciclo de la alarma lo cubre igual.
      void chrome.runtime.lastError;
    });
  } catch { /* la extension se recargo: la alarma lo cubre */ }
});

let enlaceListo = false;
window.addEventListener('MAKO_PUENTE_ENLACE_LISTO', () => { enlaceListo = true; });

function esperarEnlace() {
  // ⚠️ SIN `|| document.readyState === 'complete'`. Una página CARGADA no es una
  // página HIDRATADA: `complete` sólo dice que los recursos bajaron, y el enlace
  // lo monta React después. Con esa condición, en una pestaña ya cargada se
  // dejaba de esperar en el acto y se preguntaba al vacío.
  //
  // No se pierde nada: el `setTimeout(resolve, 4000)` de abajo ya cubre el caso
  // de una pestaña que se hidrató ANTES de que este script escuchara —esa no va a
  // volver a avisar nunca—. La diferencia es que ahora se le dan cuatro segundos
  // en vez de cero.
  if (enlaceListo) return Promise.resolve();
  return new Promise((resolve) => {
    const t = setTimeout(resolve, 4000);
    window.addEventListener('MAKO_PUENTE_ENLACE_LISTO', () => { clearTimeout(t); resolve(); }, { once: true });
  });
}
