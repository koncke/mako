// =============================================================================
// El puente: pide trabajo a MaKo, lo ejecuta contra Flow, devuelve el resultado
// =============================================================================
// Corre en el navegador del CLIENTE, con SU cuenta de Google y SUS créditos. Por
// eso los medios no salen del presupuesto de MaKo y no hay una cuenta central
// que se pueda quemar.
//
// ⚠️ LO QUE ESTA EXTENSIÓN NO HACE, Y ES DELIBERADO
//
// FlowKit —de donde salió el protocolo— incluye un `sendTelemetry()` que cada
// 45-120 s le manda a Google eventos de uso INVENTADOS (latencias, scroll,
// aperturas de proyecto) con el comentario textual «to mimic normal browser
// behavior». Eso no es usar el mecanismo: es fabricar señales para que la
// detección de bots no vea la automatización.
//
// Acá no se replica. La contención es el RITMO, y lo dicta el server: MaKo manda
// `cooldownMs` en cada respuesta y esto lo respeta. A pulso de persona no hay
// nada que disimular.
//
// ⚠️ EL BEARER NUNCA SALE DE ESTA MÁQUINA. Se usa para llamar a Google y se
// guarda en `chrome.storage.local`. A MaKo solo le viaja el RESULTADO.

const MAKO = 'https://hola-mako.com';

const FLOW_BASE = 'https://aisandbox-pa.googleapis.com';
const SITE_KEY = '6LdsFiUsAAAAAIjVDZcuLhaHiDn5nnHVXVRQGeMV';

/**
 * Un id de proyecto de Flow.
 *
 * Se valida antes de meterlo en una URL: el `projectId` sale de mirar el trafico
 * al pasar, asi que puede venir vacio o a medio leer — y armar
 * `flow.google.com/project/<basura>` manda a la persona a un 404 que se lee como
 * que MaKo perdio su proyecto.
 */
const ES_UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** Lo pisa el server en cada respuesta. Este es solo el arranque. */
let cooldownMs = 10000;
let bearer = null;
let projectId = '';
let apiKey = '';
let corriendo = false;

// ⚠️ CUANTOS TRABAJOS SE PIDEN POR LATIDO, y por que no es 1.
//
// Era 1, y eso hacia que CADA trabajo costara un latido entero. Un clip no es un
// trabajo: son ~9 —generarlo, preguntar 7 veces como va, y pedir el enlace—, o
// sea nueve esperas de 15 s que nadie ve trabajando. Medido en produccion sobre
// 348 trabajos: la mediana esperaba 13,6 s en la cola —la mitad de un latido, que
// es exactamente lo que predice pedir de a uno— y el p90 de las consultas de
// estado llegaba a 357 s.
//
// Subirlo NO afloja ninguna guarda:
// · el server ya topea en `LIMITES.concurrencia` (5) y el RPC toma con
//   `FOR UPDATE SKIP LOCKED`, asi que dos pestanas no se llevan el mismo trabajo;
// · los trabajos se siguen ejecutando DE A UNO y con el `cooldownMs` entre medio,
//   que es la guarda de verdad contra el PUBLIC_ERROR_UNUSUAL_ACTIVITY. Lo que
//   cambia es cuantos se traen por viaje, no cada cuanto se le habla a Google.
const LOTE = 5;

/**
 * Latidos seguidos que el ciclo puede encadenar solo, sin esperar a la alarma.
 *
 * Existe para que una tanda no se pague a 15 s por trabajo. El tope es la
 * baranda: un trabajo que falla y se reencola para siempre giraria sin fin.
 */
const CADENA_MAX = 20;
let cadena = 0;

/**
 * Cuándo se le habló a Flow por última vez. En `storage` y no en un global.
 *
 * ⚠️ EL SERVICE WORKER MV3 SE MUERE, y con él cualquier variable. Un piso de
 * ritmo guardado en memoria se reinicia cada vez que Chrome apaga el worker
 * —o sea seguido— y entonces la primera llamada del worker nuevo sale sin
 * esperar nada. Un guard que se olvida de lo que pasó hace diez segundos no es
 * un guard: es un guard el 80% de las veces, que es justo el que no sirve
 * cuando lo que está del otro lado es un detector de actividad automática.
 */
async function ultimaLlamadaFlow() {
  const v = await chrome.storage.local.get('ultimaLlamadaFlow');
  const t = Number(v && v.ultimaLlamadaFlow);
  return Number.isFinite(t) ? t : 0;
}

async function marcarLlamadaFlow() {
  await chrome.storage.local.set({ ultimaLlamadaFlow: Date.now() });
}

chrome.storage.local.get(['bearer', 'projectId', 'apiKey'], (v) => {
  bearer = v.bearer || null;
  projectId = v.projectId || '';
  apiKey = v.apiKey || '';
});

// ── Capturar el token de la sesión ───────────────────────────────────────────
// No se "roba" nada: es el mismo Authorization que la página ya manda cuando el
// usuario aprieta generar en Flow. Se lee al pasar y se guarda para poder
// repetir la llamada sin que el usuario esté mirando.

chrome.webRequest.onBeforeSendHeaders.addListener(
  (det) => {
    for (const h of det.requestHeaders || []) {
      if (h.name.toLowerCase() !== 'authorization') continue;
      const v = h.value || '';
      if (!v.startsWith('Bearer ya29.')) continue;
      const nuevo = v.slice('Bearer '.length);
      if (nuevo !== bearer) {
        bearer = nuevo;
        chrome.storage.local.set({ bearer });
      }
    }
    // Y de paso, el projectId sale de la propia URL de las llamadas de imagen.
    const m = det.url.match(/\/v1\/projects\/([^/]+)\//);
    if (m && m[1] && m[1] !== projectId) {
      projectId = m[1];
      chrome.storage.local.set({ projectId });
    }

    // La API key del proyecto de Google, que Flow manda en el query de CADA
    // llamada (`?key=AIza…`). No es un secreto —viaja en la URL de una app web y
    // se ve en cualquier DevTools—, pero es OBLIGATORIA: sin ella `googleapis.com`
    // no sabe a qué proyecto atribuir el pedido y lo manda al bucket de tráfico no
    // identificado, que contesta la página de bloqueo. Ese fue el bug: se llamaba
    // a `/v1/credits` pelado porque el path salió de la documentación de useapi y
    // nunca se comparó contra el tráfico REAL de Flow.
    //
    // Se lee al pasar en vez de hardcodearla: si Google la rota, el que la tiene
    // al día es el navegador del cliente, no nuestro código.
    const k = det.url.match(/[?&]key=(AIza[A-Za-z0-9_-]{20,})/);
    if (k && k[1] && k[1] !== apiKey) {
      apiKey = k[1];
      chrome.storage.local.set({ apiKey });
    }
  },
  { urls: ['https://aisandbox-pa.googleapis.com/*', 'https://labs.google/*', 'https://flow.google.com/*'] },
  ['requestHeaders'],
);

/**
 * A DONDE redirige el pedido de un medio.
 *
 * ⚠️ ES LA UNICA FORMA QUE QUEDA DE SABERLO, y no cuesta ningun permiso nuevo.
 *
 * Medido hoy: `getMediaUrlRedirect?name=<id>` redirige al archivo, y ese destino
 * no manda CORS. Asi que el redirect no se puede seguir ni leer con `fetch` —ni
 * desde la pagina («Failed to fetch») ni desde el service worker (lo mismo, y en
 * modo manual devuelve un `opaqueredirect` con el `Location` ilegible)—. Un
 * <video> lo carga igual, porque los elementos de medio no piden CORS: el archivo
 * esta ahi y el problema es solo LEERLO.
 *
 * `webRequest` mira el trafico desde afuera del modelo de CORS, y ya esta en el
 * manifest desde el primer dia —se usa para aprender la api key—. Su
 * `onBeforeRedirect` trae el `redirectUrl` completo.
 *
 * Y eso contesta la pregunta que decide todo: si el destino es una url FIRMADA,
 * el servidor la baja el mismo y la extension no tiene que mover un byte.
 */
const redirectsDeMedios = new Map();
chrome.webRequest.onBeforeRedirect.addListener(
  (det) => {
    try {
      const m = det.url.match(/[?&]name=([0-9a-f-]{8,})/i);
      if (!m) return;
      redirectsDeMedios.set(m[1], { url: det.redirectUrl, cuando: Date.now() });
      // Se guarda tambien en disco: el service worker se duerme y con el se va el Map.
      chrome.storage.local.set({ ultimoRedirectMedio: JSON.stringify({ mediaId: m[1], url: det.redirectUrl }) });
    } catch { /* mirar nunca puede romper nada */ }
  },
  // ⚠️ SE NOMBRA EL ENDPOINT, NO LA RUTA. En labs.google el tRPC cuelga de
  // /fx/api/trpc/; en flow.google.com no lo medimos, y adivinar un prefijo es como
  // se pierde trafico en silencio. Lo que SI sabemos es como se llama el endpoint,
  // que sale del codigo de la propia app y no cambio con la mudanza. El handler ya
  // se guarda solo: sin `name=<hex>` en la url sale sin hacer nada.
  { urls: [
    'https://labs.google/fx/api/trpc/media.getMediaUrlRedirect*',
    'https://flow.google.com/*getMediaUrlRedirect*',
  ] },
);

// ── El captcha ───────────────────────────────────────────────────────────────
// Se pide a la PÁGINA de Flow, que ya tiene el widget cargado. No hay ningún
// servicio de resolución de por medio: el token lo emite Google evaluando esta
// sesión, y si el comportamiento parece automatizado devuelve 403 — que es
// exactamente lo que tiene que pasar.

// ── DONDE VIVE FLOW ─────────────────────────────────────────────────────────
//
// ⚠️ GOOGLE MUDO FLOW A SU PROPIO DOMINIO, Y ESO APAGO LA EXTENSION ENTERA.
//
// Estaba escrito `https://labs.google/fx/*tools/flow*` y la pestana de un cliente
// medida el 04/09/2026 es `https://flow.google.com/project/<uuid>`. No matchean, asi
// que `chrome.tabs.query` devuelve vacio, `hayFlow` queda en false y el popup dice
// «Abre Google Flow» — con Flow abierto y cargado en la pestana de al lado.
//
// Y se muerde la cola: el boton «Abrir Google Flow» navegaba a labs.google, Google
// deja a la persona en el dominio nuevo, y la extension pierde de vista la pestana
// que ella misma acaba de abrir. Por eso no fallaba a veces: fallaba SIEMPRE.
//
// ⚠️ Y ESTE MISMO SINTOMA YA SE HABIA INVESTIGADO. El 02/09 se reporto textual —«ya
// abrimos Flow y no funciono, no deja de salir el boton de abrir Flow»— y se
// encontro una causa VERDADERA: el filtro `discarded` convertia «hay una durmiendo»
// en «no hay ninguna». Ese arreglo esta abajo y sigue siendo correcto. Pero una
// causa verdadera puede no ser LA causa, y la de abajo tapo a la de arriba.
//
// Van los DOS dominios y no uno: no sabemos si Google migro a todo el mundo, asi
// que reconocer los dos anda en las dos direcciones. El unico lugar donde esta lista
// se repite es el manifest, que no puede importar nada.
const PATRONES_FLOW = [
  'https://labs.google/fx/*tools/flow*',
  'https://flow.google.com/*',
];

/** El origen de una pestana de Flow, para armarle URLs de su MISMO dominio. */
function origenDeFlow(tab) {
  try { return new URL(tab.url).origin; } catch { return 'https://flow.google.com'; }
}

/** Si una url es de Flow, con la MISMA lista que usa el `tabs.query`. */
function esUrlDeFlow(url) {
  const u = String(url || "");
  return /^https:\/\/labs\.google\/fx\/.*tools\/flow/.test(u)
    || u.startsWith("https://flow.google.com/");
}

/**
 * Si esa pestana es el Flow NUEVO, el de flow.google.com.
 *
 * ⚠️ NO ES EL MISMO PRODUCTO CON OTRA DIRECCION: Google lo reescribio.
 *
 * Medido el 04/09/2026 leyendo el trafico de una cuenta real, dentro de un proyecto
 * cargado. El Flow nuevo habla UNICAMENTE por BOQ/batchexecute:
 *
 *   POST https://flow.google.com/_/AiSandboxAngularFrontend/data/batchexecute
 *        ?rpcids=<id>&source-path=/project/<uuid>
 *        &bl=boq_labs-ai-sandbox-frontend_20260903.13_p0
 *
 * Cero llamadas a `aisandbox-pa.googleapis.com`. Cero `Authorization: Bearer ya29.`.
 * Cero `?key=AIza…`. Cero `/v1/projects/<id>/`. BOQ autentica con COOKIES.
 *
 * O sea que el protocolo entero que implementa este puente —capturar el bearer y la
 * apiKey al pasar, y despues repetir las llamadas REST desde el service worker— NO
 * TIENE CONTRAPARTE en el Flow nuevo. No es que falte un permiso ni un patron de
 * host: lo que capturamos ya no existe.
 *
 * Y no hay a donde volver: `labs.google/fx/tools/flow` dejo de ser la app y hoy es
 * una landing de marketing con un boton «Create with Google Flow».
 *
 * Esto NO se usa para decidir si el puente funciona —si funcionara, habria bearer y
 * no llegariamos a preguntarlo—. Se usa para poder DECIR LA VERDAD en vez de
 * mandar a iniciar sesion a alguien que ya inicio sesion.
 */
function esFlowNuevo(url) {
  return String(url || "").startsWith("https://flow.google.com/");
}

/**
 * Si esa pestana esta DENTRO de un proyecto, y no en la portada.
 *
 * ⚠️ ES LA DIFERENCIA ENTRE «no inicio sesion» Y «todavia no abrio un proyecto», y
 * hasta hoy las dos se mostraban con el mismo cartel.
 *
 * El bearer se ve al pasar, en el header `Authorization` de una llamada a la API
 * de Flow. En la portada —la lista de proyectos— la app no hace ninguna: pide sus
 * cosas con cookies. Asi que una persona perfectamente logueada, mirando su lista
 * de proyectos, no produce ni un bearer.
 *
 * Medido el 04/09/2026 con una clienta: pestana en `https://flow.google.com`, con su
 * avatar, su plan y su boton de «Salir» a la vista, y el popup diciendole «Inicia
 * sesion en Google Flow». Le pedia lo unico que ya estaba hecho — que es la regla de
 * la casa sobre errores, del reves.
 */
function enProyectoDeFlow(url) {
  return /\/project\//.test(String(url || ""));
}

async function pestanaDeFlow() {
  // ⚠️ «DORMIDA» NO ES «NO EXISTE», Y CONFUNDIRLAS ES UN CALLEJÓN SIN SALIDA.
  //
  // Esto era un solo `query({ url, discarded: false })`. El filtro es correcto
  // cuando hay varias —una dormida no tiene ningún script vivo adentro, así que
  // elegirla habiendo otra sana es elegir la muerta—, pero cuando la dormida es
  // la ÚNICA, el filtro convierte «hay una durmiendo» en «no hay ninguna».
  //
  // Y el mensaje que sale de ahí manda a ABRIR Google Flow. La persona la tiene
  // abierta, la está viendo, la abre otra vez, y el aviso no se va: Chrome duerme
  // las pestañas que no se miran, y mirar la de MaKo es justamente dejar de mirar
  // la de Flow. Reportado el 02/09/2026: «ya abrimos Flow y no funcionó, no deja
  // de salir el botón de abrir Flow».
  //
  // Así que primero se pregunta por TODAS y recién después se decide.
  const todas = await chrome.tabs.query({ url: PATRONES_FLOW });
  const sanas = todas.filter((t) => !t.discarded);
  // ⚠️ EL DOMINIO DESEMPATA, Y ANTES NO DESEMPATABA NADA.
  //
  // `PATRONES_FLOW` cubre los DOS dominios, asi que con una pestaña de cada uno
  // ganaba la que quedara primera por orden de ventana — y eso cambia entre latidos,
  // porque una pestaña recargando deja de ser `complete`.
  //
  // De esa eleccion cuelga QUE PROTOCOLO se juzga. Con una pestaña vieja de
  // labs.google abierta, un navegador ya migrado caia al camino REST, no se le
  // borraba el bearer fosil, y reportaba `listo` sin preguntar ni una vez si podia
  // filmar: exactamente el «listo = hay un bearer» que se acaba de sacar.
  //
  // Gana flow.google.com porque ES Flow: labs.google/fx/tools/flow dejo de ser la
  // app y hoy es una landing (medido el 04/09). Y ademas el ensayo y el envio pasan
  // a mirar la MISMA pestaña, que era otra forma de opinar distinto.
  const nuevas = sanas.filter((t) => esFlowNuevo(t.url));
  const cola = nuevas.length ? nuevas : sanas;
  const tab = cola.find((t) => t.status === "complete") || cola[0];
  if (tab) return tab;

  // Hay pestaña, pero Chrome la durmió. Se la despierta —`reload` es lo que
  // revive una descartada— y se avisa que hay que esperar un latido, en vez de
  // pedir que abran una que ya está abierta.
  if (todas.length) {
    try { await chrome.tabs.reload(todas[0].id); } catch { /* si no se puede, lo dice el error */ }
    throw new Error("FLOW_TAB_DORMIDA");
  }
  throw new Error("NO_FLOW_TAB");
}

/**
 * Acuna un token de reCAPTCHA para una accion.
 *
 * `medida` dice si esa accion salio de la TABLA (leida del bundle de Flow) o de
 * derivarla del path. La pagina lo necesita para saber si puede pisarla con lo
 * que vio acunar a Flow: una adivinada si, una medida NUNCA — ver el comentario
 * largo en injected.js.
 */
async function pedirCaptcha(tabId, action, medida) {
  const res = await chrome.tabs.sendMessage(tabId, { tipo: 'GET_CAPTCHA', action, siteKey: SITE_KEY, medida: !!medida });
  if (!res || !res.token) throw new Error(res?.error || 'CAPTCHA_FALLO');
  // Queda en la consola de la extension: si la clave de la pagina NO es la que
  // tenemos escrita, es la explicacion del 403 y hay que verla, no deducirla.
  if (res.siteKeyUsado && res.siteKeyUsado !== SITE_KEY) {
    console.warn(`[mako] el site key de la pagina es ${res.siteKeyUsado}, el nuestro era ${SITE_KEY}`);
  }
  // LA MEDICION que faltaba: con que acciones acuna Flow sus tokens. Queda
  // guardado para que viaje en el proximo latido y se pueda ver desde el server,
  // sin pedirle una captura de pantalla a nadie.
  if (Array.isArray(res.accionesDeFlow) && res.accionesDeFlow.length) {
    try { await chrome.storage.local.set({ accionesDeFlow: res.accionesDeFlow }); } catch { /* no es critico */ }
    if (!res.accionesDeFlow.includes(action)) {
      console.warn(`[mako] pedimos la accion "${action}" y Flow usa: ${res.accionesDeFlow.join(', ')}`);
    }
  }
  return res.token;
}


// ── El respaldo de plantillas ────────────────────────────────────────────────
//
// Las plantillas del espejo viven en la MEMORIA de la pestana de Flow. Un F5 las
// borra, y con ellas la posibilidad de generar: la tab pedia «abri Flow y genera
// algo a mano una vez» DESPUES DE CADA RECARGA. Para un producto eso no es un
// requisito, es una tab que no funciona.
//
// Asi que se guardan aca, en el storage de la extension, que sobrevive tanto al
// F5 como al reinicio del service worker.
//
// ⚠️ Lo que se guarda NO lleva credenciales: `injected.js` saca el `authorization`
// —que se repone fresco en cada pedido— y el token de reCAPTCHA, que se acuna en
// el momento y vencido no sirve. Guardar un token vencido seria cargar con una
// credencial sin ganar nada.
const CLAVE_PLANTILLAS = 'plantillas';

/**
 * La pestana de Flow que MaKo dejo lista, para poder devolverla a su lugar.
 *
 * ⚠️ EL PEDIDO DEL DUENO: «si detecta que toco algo de Google Flow, que vuelva a
 * redireccionar a la posicion correcta, al proyecto, y que le avise que no toque
 * nada».
 *
 * Y no es capricho: si la pestana se va del proyecto, el puente pierde de golpe el
 * unico lugar donde el trafico que necesita ocurre. Antes eso terminaba en un cartel
 * pidiendo volver a entrar — o sea, delegando en la persona el arreglo de algo que
 * ella no sabe que rompio.
 *
 * ⚠️ Se guarda la URL EXACTA y no solo el id: la gracia es devolverla al MISMO
 * proyecto. Con el id solo, «volver» seria adivinar a cual.
 */
const CLAVE_CUIDANDO = 'cuidandoFlow';

/**
 * Cuanto dura la guardia.
 *
 * ⚠️ TIENE QUE VENCER, o es una pestana secuestrada. Alguien que abrio Flow con MaKo
 * hace tres horas y ahora quiere navegar su propio Flow no esta cometiendo un error:
 * dejo de estar en la tarea. Media hora cubre una sesion de trabajo entera y no
 * convierte al navegador en algo que pelea con su dueno.
 */
const CUIDADO_MS = 30 * 60 * 1000;

/** Deja de cuidar: lo llama todo lo que significa «la tarea termino». */
async function soltarGuardia() {
  try { await chrome.storage.local.remove(CLAVE_CUIDANDO); } catch { /* nada que soltar */ }
}

/**
 * El catalogo de operaciones: la fuente unica de que sabe hacer el puente.
 *
 * ⚠️ GENERADO de lib/flow-operaciones.ts por scripts/sync-operaciones.mjs, y el
 * pre-push falla si quedo viejo. Los tokens de aca son el ancla que decide si una
 * generacion PAGADA se reconoce: desincronizados, al cliente se le cobra un clip y
 * el puente contesta que no aprendio.
 *
 * Vive en el service worker —que SI se actualiza con la extension— y no en
 * injected.js, que corre en el mundo de la pagina y queda congelado hasta un F5.
 * Esa distincion ya costo un dia entero: un arreglo correcto en injected.js no se
 * ejecutaba en la pestana que la persona tenia abierta.
 */
import { OPERACIONES, A_ENSENAR, A_PEDIR, SIN_DETECTAR, operacionDelCuerpo, operacionDeLaClase } from './operaciones.js';
import { reemplazarEnCuerpo, reponerCaptcha, renovarIdsDeCliente } from './boq-patch.js';
import { leerRespuestaBoq } from './boq-respuesta.js';
import { puedeFilmar, ensayarOperacion, elegirPlantilla } from './puede-filmar.js';
/**
 * Repite un pedido de generacion contra el Flow nuevo, con OTRO prompt.
 *
 * Es el circuito completo: se toma la plantilla que la persona nos enseno generando
 * un clip, se le cambia el prompt por el que MaKo quiere, y el pedido sale DESDE LA
 * PAGINA —que es donde estan las cookies y el `at` vivo—.
 *
 * ⚠️ NO SE PARSEA EL ARBOL DEL `f.req`. Es posicional y anidado; caminarlo seria
 * adivinar donde vive el prompt. Lo que NO es adivinanza es la frase de aprendizaje:
 * la persona la escribio exacta, asi que sabemos el string literal que Flow puso ahi.
 * Se busca ESE, con la codificacion con la que viajo, y se reemplaza.
 *
 * ⚠️ Y FALLA EN VEZ DE ADIVINAR. Si la frase no aparece, se devuelve `SIN_ANCLA` y no
 * se manda nada: mandar la plantilla sin parchear genera —y le cobra al cliente— un
 * cubo violeta girando sobre arena en vez de su anuncio.
 */
/**
 * Lo que se le dice a la persona cuando Google rechaza un pedido de BOQ.
 *
 * El detalle tecnico (`codigo 7 · PUBLIC_ERROR_UNUSUAL_ACTIVITY (ogiZ0b)`) queda en
 * la consola y en el log del server; a la pantalla va que puede hacer.
 */
function explicarFalloBoq(r) {
  const tecnico = String(r.porQue || r.error || '');
  if (tecnico) console.warn('[mako] BOQ rechazo el pedido:', tecnico);
  if (/UNUSUAL_ACTIVITY/.test(tecnico)) return 'Google rechazó el pedido por seguridad. Espera un momento y vuelve a intentar.';
  if (/^codigo 13\b/.test(tecnico)) return 'Google empezó a procesarlo y falló a mitad de camino. Vuelve a intentar.';
  if (/UNSAFE_GENERATION/.test(tecnico)) return 'El filtro de contenido de Google rechazó este pedido. Cambia el texto y vuelve a intentar.';
  if (/QUOTA/.test(tecnico)) return 'Se agotaron los créditos de tu cuenta de Google.';
  if (r.error === 'CAPTCHA_FALLO') return 'No se pudo verificar la sesión con Google. Recarga la pestaña de Flow y vuelve a intentar.';
  return tecnico ? 'Google no aceptó el pedido.' : 'Google no aceptó el pedido.';
}

async function repetirEnBoq(op, prompt) {
  const cat = OPERACIONES.find((o) => o.op === op);
  if (!cat || !cat.frase) return { error: 'OPERACION_SIN_ANCLA', op, salio: false };

  // ⚠️ LA ELIGE `elegirPlantilla`, LA MISMA QUE USA EL ENSAYO EN SECO.
  //
  // Aca habia un `find(p.op === op)` y en el ensayo habia OTRO igual: dos lugares
  // eligiendo por separado con la misma regla mala —la primera por orden de
  // insercion—. Un navegador que aprendio en labs.google y despues migro tiene DOS
  // plantillas para `generar_clip`, y la vieja REST pasa todos los chequeos menos el
  // ultimo: no tiene donde poner el `at`. El ensayo daba verde, se abrian las cuatro
  // compuertas, y el pedido moria cinco veces con la plantilla buena a una clave de
  // distancia.
  const guardadas = (await chrome.storage.local.get(CLAVE_PLANTILLAS))[CLAVE_PLANTILLAS] || {};
  const elegida = elegirPlantilla(guardadas, cat);
  // ⚠️ `salio: false` EXPLICITO. Todo lo que devuelve antes del envio SI puede
  // reintentarse sin cobrar de nuevo, y hay que decirlo: el default de abajo es no
  // reintentar, porque lo que no consta es que el credito NO se haya gastado.
  if (!elegida.clase) return { error: elegida.porQue.replace(/\(.*/, ''), op, salio: false };
  const pl = elegida.pl;

  const r = reemplazarEnCuerpo(pl.cuerpo, cat.frase, prompt);
  if (!r.ok) return { error: r.error, op, clase: elegida.clase, salio: false };

  let tab;
  try { tab = await pestanaDeFlow(); } catch { return { error: 'NO_FLOW_TAB', op, salio: false }; }
  if ((await asegurarContentScript(tab.id)) === 'mudo') return { error: 'PESTANA_MUDA', op, salio: false };

  // ⚠️ EL TOKEN DE reCAPTCHA SE ACUÑA FRESCO, O GOOGLE RECHAZA. El primer pedido
  // real por BOQ volvio con codigo 7 · PUBLIC_ERROR_UNUSUAL_ACTIVITY: el cuerpo
  // llevaba el token de cuando la persona ENSEÑO la frase, y un token de reCAPTCHA
  // es de un solo uso y ata la accion. Se pide a la pagina uno nuevo con la accion
  // MEDIDA del bundle (la misma tabla que usa el camino REST) y se repone donde
  // el cuerpo traia el viejo — su forma esta medida en las dos plantillas reales.
  //
  // Si la plantilla no traia ningun token, no se inventa uno: se manda como vino y
  // se deja escrito en el log, que es lo que hay que leer si Google rechaza.
  let cuerpoFinal = r.cuerpo;
  if (cat.captcha) {
    const accion = ACCION_CAPTCHA[op] || accionDeCaptcha(op, pl.url);
    let token;
    try { token = await pedirCaptcha(tab.id, accion, !!ACCION_CAPTCHA[op]); } catch (e) {
      return { error: 'CAPTCHA_FALLO', detalle: String((e && e.message) || e), op, clase: elegida.clase, salio: false };
    }
    const rc = reponerCaptcha(r.cuerpo, token);
    if (!rc.cuantos) console.warn(`[mako] la plantilla de ${op} no traia token de captcha: se manda como vino`);
    cuerpoFinal = rc.cuerpo;
  }

  // ⚠️ IDS DE CLIENTE FRESCOS EN CADA REPLAY. El segundo pedido real volvio con
  // codigo 13 (INTERNAL) a los 21 segundos: el captcha ya habia pasado y el
  // backend proceso el pedido y murio adentro. El cuerpo repetia los UUID de lote
  // y de request de la generacion con la que se enseño — los mismos que el camino
  // REST regeneraba con randomUUID() en cada pedido. El proyecto (minusculas) no
  // se toca; los de cliente (MAYUSCULAS, medido en los dos cuerpos reales) si.
  const ids = renovarIdsDeCliente(cuerpoFinal);
  if (!ids.cuantos) console.warn(`[mako] la plantilla de ${op} no traia ids de cliente que renovar`);
  cuerpoFinal = ids.cuerpo;

  const res = await chrome.tabs.sendMessage(tab.id, {
    tipo: 'BOQ_PEDIDO', url: pl.url, cuerpo: cuerpoFinal,
  });
  if (!res || res.error) return { ...res, op, clase: elegida.clase };

  // ⚠️ UN 200 NO ES UN EXITO, Y DECIRLO ASI YA MINTIO UNA VEZ.
  //
  // BOQ contesta 200 con el fallo ADENTRO del cuerpo. Mirando `res.ok` el popup
  // dijo «Listo, lo veras en tu Flow» sobre un pedido que no creo nada, y la
  // persona fue a buscar un video que nunca se pidio.
  //
  // Es la regla que este repo ya tenia escrita, medida antes con Meta y con
  // Evolution. Tercera vez, tercer proveedor.
  const rpcid = (/[?&]rpcids=([^&,]+)/.exec(pl.url || '') || [])[1];
  const dice = leerRespuestaBoq(res.texto, rpcid);
  return {
    ...res,
    ok: dice.ok,
    motivo: dice.ok ? null : dice.motivo,
    porQue: dice.ok ? null : dice.detalle,
    payload: dice.ok ? dice.payload : null,
    op, clase: elegida.clase, donde: r.donde, cuantas: r.cuantas,
  };
}

async function guardarPlantillas(tabId) {
  try {
    const r = await chrome.tabs.sendMessage(tabId, { tipo: 'GUARDAR_PLANTILLAS' });
    const lista = (r && r.plantillas) || [];
    if (!lista.length) return;
    const previas = (await chrome.storage.local.get(CLAVE_PLANTILLAS))[CLAVE_PLANTILLAS] || {};
    const mapa = { ...previas };
    // La mas nueva gana. Y una plantilla vieja NO se borra porque hoy no se haya
    // visto: es justo el caso que esto viene a arreglar.
    for (const p of lista) {
      const antes = mapa[p.clase];
      // ⚠️ LA SENTINELA NO SE PISA CON `null`, Y ASI SE DES-APRENDIA SOLA.
      //
      // El espejo reescribe la entrada de la clase en CADA pedido, asi que la
      // siguiente generacion —que no lleva la frase— traia `sentinela: null`, y este
      // `{ ...p }` reemplaza el objeto ENTERO: el `sentinela` que costo un clip
      // pagado se borraba en silencio. El comentario de arriba prometia lo contrario,
      // pero eso solo valia a nivel de CLASE, nunca de campo.
      //
      // Se descubre UNA vez y no cambia. Tres fuentes, de la mas fresca a la mas vieja:
      // lo que mando el espejo, lo que se puede leer del cuerpo acá mismo (que es lo
      // que salva a las pestanas con el injected.js viejo), y lo que ya sabiamos.
      // ⚠️ SE ETIQUETA POR OPERACION, NO SOLO «TIENE SENTINELA».
      //
      // Con dos operaciones que se aprenden por ancla —generar video y generar
      // imagen— saber que HAY una sentinela ya no alcanza: hay que saber CUAL. Un
      // booleano global diria que el puente sabe filmar despues de que la persona
      // genero una imagen, y eso se descubre cuando el pedido sale y Google
      // contesta 400, con el trabajo ya encolado.
      //
      // Se DERIVA del cuerpo, aca en el worker: es lo que hace que funcione con el
      // injected.js viejo de una pestana que nadie recargo.
      const hallado = operacionDelCuerpo(p.cuerpo);
      // ⚠️ UN CUERPO CON ANCLA NO SE PISA CON UNO SIN ANCLA — tambien aca.
      //
      // El espejo ya lo cuida en memoria, pero un injected.js VIEJO (los scripts
      // de MAIN world sobreviven a la actualizacion de la extension) sigue pisando
      // en su mapa y manda el cuerpo pisado. Esta es la copia durable: si lo que
      // hay guardado ensena y lo que llega no, lo que llega no entra.
      if (antes && antes.cuerpo && operacionDelCuerpo(antes.cuerpo) && !hallado) continue;
      // ⚠️ Y POR RPCID, para las que no llevan prompt.
      //
      // Leer el saldo y sondear el estado no escriben ningun texto nuestro, asi que no
      // hay ancla que buscarles — y en BOQ todos los pedidos comparten path. Lo unico
      // que las distingue es su rpcid, que esta MEDIDO.
      //
      // Va DESPUES del ancla a proposito: un rpcid rota y el ancla no. Si alguna vez las
      // dos contestan, gana la que no puede confundirse.
      const op = p.op || (hallado && hallado.op) || operacionDeLaClase(p.clase) || (antes && antes.op) || null;
      const sentinela = p.sentinela || (hallado && hallado.donde) || (antes && antes.sentinela) || null;
      mapa[p.clase] = { ...p, op, sentinela, cuando: Date.now() };
    }
    await chrome.storage.local.set({ [CLAVE_PLANTILLAS]: mapa });
  } catch { /* si la pestana no responde, no hay nada que guardar */ }
}

/**
 * Lo que este navegador puede contar de si mismo.
 *
 * ⚠️ NUNCA TIRA. Un diagnostico que falla y corta el latido convierte una falta de
 * informacion en una falta de servicio — y este dato existe justamente para los
 * momentos en que algo anda mal.
 */
async function armarDiagnostico(plantillas, estado) {
  const manifest = chrome.runtime.getManifest().version;
  let espejo = '';
  let dominio = '';
  let enProyecto = false;
  try {
    const tab = await pestanaDeFlow();
    try { dominio = new URL(tab.url).host; } catch { /* sin dominio legible */ }
    enProyecto = enProyectoDeFlow(tab.url);
    // La version del espejo de ESTA pestana. Un espejo anterior al versionado no
    // contesta, y ese '' es la respuesta: quedo viejo y hace falta un F5.
    try {
      const r = await chrome.tabs.sendMessage(tab.id, { tipo: 'VER_VERSION_ESPEJO' });
      espejo = (r && r.version) || '';
    } catch { /* la pestana no contesta: se reporta vacio */ }
  } catch { /* sin pestana de Flow, el resto del diagnostico igual sirve */ }

  const ops = plantillas.map((p) => p.op).filter(Boolean);
  const faltan = A_ENSENAR.filter((o) => !ops.includes(o.op)).map((o) => o.op);
  return {
    cuando: Date.now(),
    manifest,
    espejo,
    dominio,
    enProyecto,
    clases: plantillas.map((p) => p.clase),
    ops,
    faltan,
    estado: estado || '',
  };
}

/**
 * Todo lo guardado, para mandarselo al servidor.
 *
 * Sin esto, lo que el navegador aprendio de Flow muere con el perfil — y la app
 * vuelve a pedir «genera UNA imagen a mano» sobre algo que el cliente ya hizo
 * decenas de veces. El dueno lo pregunto con todas las letras.
 */
async function todasLasPlantillas() {
  try {
    const mapa = (await chrome.storage.local.get(CLAVE_PLANTILLAS))[CLAVE_PLANTILLAS] || {};
    return Object.entries(mapa).map(([clase, p]) => ({ ...p, clase }));
  } catch {
    return [];
  }
}

/**
 * Guarda las que mando el servidor, para las clases que ACA no hay.
 *
 * ⚠️ Nunca pisa una local. La local es de esta maquina y de esta sesion; la del
 * servidor puede ser de otro dia. Se usa para llenar huecos, no para sincronizar.
 */
async function sembrarPlantillas(lista) {
  try {
    if (!Array.isArray(lista) || !lista.length) return 0;
    const previas = (await chrome.storage.local.get(CLAVE_PLANTILLAS))[CLAVE_PLANTILLAS] || {};
    const mapa = { ...previas };
    let n = 0;
    for (const p of lista) {
      if (!p || !p.clase) continue;
      const local = mapa[p.clase];
      // ⚠️ SI LA LOCAL PERDIO EL ANCLA Y LA DEL SERVER LA TIENE, la del server la
      // REPARA. «Nunca pisa una local» era la regla, y sigue valiendo para todo lo
      // demas: pero una local sin ancla es una plantilla que no sirve para
      // generar, y el respaldo existe exactamente para este caso.
      if (local && !(operacionDelCuerpo(p.cuerpo) && !operacionDelCuerpo(local.cuerpo))) continue;
      mapa[p.clase] = { ...p, cuando: p.cuando || Date.now(), delServidor: true };
      n++;
    }
    if (n) await chrome.storage.local.set({ [CLAVE_PLANTILLAS]: mapa });
    return n;
  } catch {
    return 0;
  }
}

async function respaldoDe(clase) {
  try {
    const mapa = (await chrome.storage.local.get(CLAVE_PLANTILLAS))[CLAVE_PLANTILLAS] || {};
    return mapa[clase] || null;
  } catch {
    return null;
  }
}

// ── Ejecutar un trabajo contra Flow ──────────────────────────────────────────

/**
 * Los trabajos que solo LEEN. No llevan cuerpo, no llevan captcha, y si la página
 * ya preguntó lo mismo hace poco se contestan con su respuesta, sin tráfico.
 */
/**
 * Los trabajos que NO necesitan acunar un captcha.
 *
 * ⚠️ SE LLAMA POR LO QUE HACE, y el nombre viejo —`SOLO_LECTURA`— es la razon de
 * que este bug se repitiera TRES veces. «Solo lectura» suena a una propiedad del
 * pedido, asi que fue significando, una tras otra, tres cosas distintas:
 *
 *   1. «no necesita captcha»          ← lo unico que decide de verdad
 *   2. «no manda cuerpo»              ← rompio la consulta de estado la 1ra vez
 *   3. «no necesita clientContext»    ← la rompio la 3ra, con un 400 identico
 *
 * Cada una se descubrio por separado, con dias de diferencia, sobre el mismo
 * `if`. Un nombre que describe una CATEGORIA invita a colgarle comportamientos;
 * uno que describe UNA decision, no.
 *
 * (En el mensaje al mundo de la pagina el campo sigue llamandose `soloLectura`,
 * porque alli decide otra cosa —si una respuesta cacheada puede contestar— y
 * renombrarlo obligaria a que las dos puntas se actualicen a la vez.)
 */
// ⚠️ `subir_imagen` esta aca aunque ESCRIBA. El pedido real de Flow —medido— no
// lleva `recaptchaContext`, y agregarle un token que la app no manda es inventar
// un campo: exactamente lo que produjo los dos HTTP 400 de esta noche.
const SIN_CAPTCHA = new Set(['creditos', 'estado_clips', 'subir_imagen']);

/**
 * El nombre de la accion con la que se acuna el token de reCAPTCHA.
 *
 * ⚠️ NO es decorativo y NO es libre: reCAPTCHA Enterprise ATA el token a la
 * accion. Si Flow acuna el suyo con `batchAsyncGenerateVideoReferenceImages` y
 * nosotros mandamos uno acunado con `batchAsyncGenerateVideo`, Google contesta
 * 403 «reCAPTCHA evaluation failed» — y ese error se lee como sesion quemada
 * cuando en realidad es un nombre mal puesto de nuestro lado. Paso el 29/08 con
 * el primer clip del Video Generator.
 *
 * Por eso ya NO sale de una tabla por TIPO de trabajo: sale del ENDPOINT que se
 * va a llamar. Un tipo de trabajo puede pegarle a varios endpoints —generar un
 * clip desde referencias no es lo mismo que encadenarlo por frames— y la tabla
 * por tipo solo podia acertarle a uno.
 */
/**
 * Las acciones que Flow usa DE VERDAD. Medidas, no derivadas.
 *
 * ⚠️ Salieron de decodificar el bundle de Flow: la tabla de strings del
 * ofuscador, indice 0x13d8, despues de aplicar la rotacion que el propio bundle
 * hace al cargar. La linea donde la app acuna su token es
 *
 *     recaptchaContext: { token: await hw('VIDEO_GENERATION'), applicationType: ... }
 *
 * Antes se DERIVABA del path —`batchAsyncGenerateVideoReferenceImages`— con un
 * comentario que afirmaba que era «exactamente lo que la app pone en su propio
 * execute()». Era falso, y costo un dia: reCAPTCHA Enterprise ATA el token a la
 * accion, asi que cada pedido volvia 403 «reCAPTCHA evaluation failed» — el mismo
 * cuerpo que devuelve un token con score bajo, y por eso se confundio con una
 * sesion quemada durante horas.
 *
 * Y NO se pudo medir desde la pagina: se envolvio `grecaptcha.enterprise.execute`
 * y no capturo nada en dos intentos, porque Flow lo llama desde un contexto que
 * el espejo no alcanza. Cuando el espejo no llega, se lee el codigo.
 */
const ACCION_CAPTCHA = {
  generar_clip: 'VIDEO_GENERATION',
  generar_imagen: 'IMAGE_GENERATION',
};

function accionDeCaptcha(tipo, path) {
  if (ACCION_CAPTCHA[tipo]) return ACCION_CAPTCHA[tipo];
  // Fallback para lo que todavia no se midio: el metodo del endpoint. No es lo
  // que Flow usa —ahora lo sabemos— pero es lo unico inferible sin medir.
  const ultimo = String(path || '').split('?')[0].split('/').filter(Boolean).pop() || '';
  const metodo = ultimo.includes(':') ? ultimo.split(':').pop() : ultimo;
  return metodo || 'generate';
}

/**
 * Se reinicia sola cuando el server dice que hay una version mas nueva.
 *
 * ── Por que existe ────────────────────────────────────────────────────────
 * Esta extension se instala DESCOMPRIMIDA, y a una instalacion descomprimida
 * Chrome no la actualiza nunca: el boton «Recargar» de chrome://extensions
 * vuelve a leer LA MISMA CARPETA. Si esa carpeta no cambio, recargar no puede
 * cambiar nada — y desde afuera se ve identico a un boton que no funciona.
 *
 * Ya costo dos veces el mismo dia. La primera se diagnostico mal (se creyo que
 * era el zip viejo que servia produccion, que era cierto y no era la causa); la
 * segunda, el dueno recargo y contesto «no funciono», con razon.
 *
 * `chrome.runtime.reload()` SI vuelve a leer los archivos del disco. Asi que en
 * cuanto la carpeta esta al dia, esto cierra el circulo solo.
 *
 * ── Las tres guardas, y las tres importan ─────────────────────────────────
 * 1. Solo en instalaciones descomprimidas. Chrome le agrega `update_url` al
 *    manifest de lo que viene de la tienda, y ahi el que actualiza es Chrome:
 *    reiniciar no traeria nada nuevo.
 * 2. UN intento por version de destino. Si la carpeta sigue vieja, el reinicio
 *    no cambia nada y sin esta guarda quedaria reiniciandose cada 15 segundos
 *    para siempre. Un bucle de reinicio es peor que estar desactualizado: mata
 *    la pestana de trabajo y no deja rastro de por que.
 * 3. Nunca en el medio de un trabajo. Reiniciar con un clip a mitad de camino
 *    pierde el resultado y deja al cliente mirando «generando…» sobre algo que
 *    ya termino.
 */
/** `a` es anterior a `b`. Gemela de `esMasVieja` en app/video-generator/PuentePanel.tsx. */
function esMasVieja(a, b) {
  const na = String(a || '').split('.').map(Number);
  const nb = String(b || '').split('.').map(Number);
  for (let i = 0; i < Math.max(na.length, nb.length); i++) {
    const x = na[i] || 0;
    const y = nb[i] || 0;
    if (x !== y) return x < y;
  }
  return false;
}

/**
 * Anota que version sirve produccion, para que el popup pueda frenar.
 *
 * ⚠️ ANTES ESTO REINICIABA LA EXTENSION, Y ERA UN AUTOGOL. `chrome.runtime.reload()`
 * vuelve a leer LA MISMA CARPETA: en una instalacion descomprimida no baja nada,
 * asi que no puede actualizar nada — y el `if (manifest.update_url) return` de
 * abajo hace que el reinicio corriera SOLO en instalaciones descomprimidas. O sea
 * que se reiniciaba unicamente en el unico caso donde reiniciar no sirve.
 *
 * Y no era gratis. Un `runtime.reload()` mata al service worker y **se lleva la
 * alarma**; si Chrome no lo vuelve a levantar —MV3 no arranca el worker hasta que
 * llegue un evento, y la alarma era el evento— el puente se apaga PARA SIEMPRE.
 * Es la causa mas probable del caso medido el 01/09/2026: una clienta con la
 * 0.37.1 instalada mientras produccion servia la 0.37.3, cuyo puente dejo de
 * latir y no volvio nunca.
 *
 * Lo que corresponde no es automatizar la recarga: es DECIR que hay que
 * reemplazar los archivos. Eso lo hace el popup, con el paso a paso, y hasta que
 * no este al dia no deja seguir.
 */
async function anotarVersionEsperada(esperada) {
  try {
    if (!esperada) return;
    await chrome.storage.local.set({ versionEsperada: String(esperada) });
  } catch { /* saber la version nunca puede romper al que ya funciona */ }
}

/**
 * AL DIA CON SU CARPETA (26/10/2026, 0.71.1). Una instalacion DESCOMPRIMIDA no se actualiza sola: reemplazar los archivos de
 * la carpeta no cambia nada hasta tocar «Recargar» en chrome://extensions. El 25/10 la 0.71.0 quedo COPIADA en la carpeta de
 * Martin y su Chrome siguio con la 0.70.0 toda la noche, porque Martin no estaba para tocarlo (y chrome://extensions no se
 * puede manejar desde afuera). Esto mira el manifest de la CARPETA (un `fetch` de un recurso propio lee el disco en una
 * instalacion descomprimida) y, si es MAS NUEVO que el que corre, se recarga UNA vez por version.
 * ⚠️ NO ES EL REINICIO VIEJO de arriba (01/09/2026): aquel comparaba contra lo que servia produccion y se reiniciaba aunque la
 * carpeta no hubiera cambiado, que es justo cuando reiniciar no sirve. Este se recarga solo si la carpeta YA trae otra
 * version; y la alarma se rearma sola al volver (`onInstalled` y el `asegurarAlarma` de arriba del archivo).
 * Guardas: nunca de la tienda (ahi actualiza Chrome), nunca con un trabajo de Flow o una lectura de fichas en curso, y una
 * sola vez por version de la carpeta (si la recarga no la levanta, no queda en bucle).
 */
let fichasEnVuelo = 0;
async function hayTrabajoEnCurso() {
  // ⚠️ UN CICLO ANDANDO TAMBIEN ES TRABAJO (26/10/2026, la revision adversarial de tren-l). La alarma corre
  // `ciclo().then(alDiaConSuCarpeta)`, y si ya habia un ciclo (un DESPERTAR, el onUpdated de Flow, el encadenado o un
  // REVISAR_CARPETA), `ciclo()` vuelve en el acto y la recarga corria EN PARALELO: cortaba el POST a /api/flow/puente despues
  // de que el server tomara los trabajos y antes de que se abriera su registro, y el cliente veia «generando…» diez minutos.
  // Asi la recarga espera a la proxima alarma (`recargaPorCarpeta` todavia no se escribio).
  if (corriendo) return true;
  if (fichasEnVuelo > 0) return true;
  try { return (await registrosInterfaz()).some((r) => FASES_EN_CURSO.includes(r.fase)); } catch { return true; }
}
async function alDiaConSuCarpeta() {
  try {
    const corre = chrome.runtime.getManifest();
    if (corre.update_url) return;
    const r = await fetch(chrome.runtime.getURL('manifest.json'), { cache: 'no-store' });
    const enCarpeta = String((await r.json()).version || '');
    if (!enCarpeta || !esMasVieja(corre.version, enCarpeta)) return;
    const { recargaPorCarpeta } = await chrome.storage.local.get('recargaPorCarpeta');
    if (recargaPorCarpeta === enCarpeta) return;
    if (await hayTrabajoEnCurso()) return;
    await chrome.storage.local.set({ recargaPorCarpeta: enCarpeta });
    console.log(`[mako] la carpeta trae la ${enCarpeta} y corre la ${corre.version}: recargando para leerla`);
    chrome.runtime.reload();
  } catch { /* actualizarse nunca puede romper al que ya funciona */ }
}

/** Sin llamadores desde el 01/09/2026. Se deja el porque arriba, no el codigo. */
async function quizasReiniciarNoUsar(esperada, hayTrabajoEnCurso) {
  try {
    if (!esperada || hayTrabajoEnCurso) return;
    const manifest = chrome.runtime.getManifest();
    // ORDENADA, no `===`. Una igualdad dispara TAMBIEN cuando la instalada va
    // ADELANTE de lo que sirve produccion —la maquina de desarrollo, los minutos
    // entre el push y el deploy, y para siempre si el build fallo— y cada uno de
    // esos reinicios deja la pestana muda hasta el latido siguiente. Es la misma
    // leccion que la pantalla ya aprendio en PuentePanel.tsx (`esMasVieja`); si se
    // cambia una, se cambia la otra: la extension no tiene bundler y no puede
    // importar de `app/`.
    if (!esMasVieja(manifest.version, esperada)) {
      // Al dia: se limpia la marca para que un salto futuro pueda volver a intentar.
      await chrome.storage.local.remove('reinicioIntentado');
      return;
    }
    // De la tienda: el que actualiza es Chrome, no nosotros.
    if (manifest.update_url) return;

    const { reinicioIntentado } = await chrome.storage.local.get('reinicioIntentado');
    if (reinicioIntentado === esperada) return;
    await chrome.storage.local.set({ reinicioIntentado: esperada });
    console.log(`[mako] ${manifest.version} -> ${esperada}: reiniciando para leer los archivos nuevos`);
    chrome.runtime.reload();
  } catch { /* actualizarse nunca puede romper al que ya funciona */ }
}

/**
 * Repone el puente de una pestana de Flow que quedo sin content script.
 *
 * CHROME NO REINYECTA HACIA ATRAS. Ni despues de un `chrome.runtime.reload()`,
 * ni en una pestana que ya estaba abierta cuando se instalo la extension, ni en
 * una navegacion por pushState adentro de la SPA de Flow. Los tres dejan el
 * script HUERFANO: sigue vivo en la pagina, pero el listener que registro
 * pertenece al contexto viejo y el service worker nuevo no lo ve.
 *
 * El sintoma es el error literal de Chrome «Receiving end does not exist», y
 * hasta hoy la unica salida era que una persona apretara F5 — y nadie se lo
 * pedia, porque el puente seguia diciendo que estaba listo.
 *
 * `injected.js` va PRIMERO y va SIEMPRE: si la pestana es de las que nunca lo
 * tuvieron, reponer solo content.js cambia un error claro por 25 segundos de
 * espera y un timeout de captcha. Re-ejecutarlo cuando ya esta vivo es gratis
 * —tiene su guarda de idempotencia— y conserva sus plantillas en memoria, que es
 * justo lo que no se puede perder.
 *
 * Devuelve 'ok' | 'repuesto' | 'mudo'.
 */
const reparadasEnEstaVuelta = new Set();

async function pingContent(tabId) {
  try {
    const r = await chrome.tabs.sendMessage(tabId, { tipo: 'PING' });
    return !!(r && r.ok);
  } catch { return false; }
}

async function asegurarContentScript(tabId) {
  if (await pingContent(tabId)) return 'ok';
  // UN intento por vuelta del ciclo: si inyectar no alcanzo, insistir cada 15 s
  // sobre la misma pestana no la va a arreglar y si puede tapar el diagnostico.
  if (reparadasEnEstaVuelta.has(tabId)) return 'mudo';
  reparadasEnEstaVuelta.add(tabId);
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['injected.js'], world: 'MAIN' });
    await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
  } catch (e) {
    console.warn('[mako] no se pudo reponer el puente:', e);
    return 'mudo';
  }
  return (await pingContent(tabId)) ? 'repuesto' : 'mudo';
}

async function ejecutar(trabajo) {
  // ── EL FLOW NUEVO: SE REPITE EL PEDIDO QUE LA PERSONA NOS ENSENO ─────────
  //
  // Entra por acá, que es la cola REAL, y no por un boton de prueba. La persona
  // no quiere «un video de prueba»: quiere su anuncio. El primer anuncio de
  // verdad ES la prueba, y si falla el error lo dice.
  //
  // Solo si HAY plantilla de BOQ para este tipo: si no, cae al camino viejo, que
  // sigue andando para quien todavia este en labs.google.
  {
    const cat = OPERACIONES.find((o) => o.tipo === trabajo.tipo);
    if (cat && cat.frase) {
      const guardadas = (await chrome.storage.local.get(CLAVE_PLANTILLAS))[CLAVE_PLANTILLAS] || {};
      const hay = Object.values(guardadas).some((p) => p && p.op === cat.op && p.cuerpo);
      if (hay) {
        const prompt = String((trabajo.pedido && (trabajo.pedido.prompt || trabajo.pedido.texto)) || '');
        if (!prompt) {
          return {
            id: trabajo.id, ok: false, motivo: 'permanente',
            error: 'El trabajo no trae texto para filmar.', reintentable: false,
          };
        }
        const r = await repetirEnBoq(cat.op, prompt);
        // ⚠️ LA CLAVE ES `data`, NO `datos`. La lee `app/api/flow/puente/route.ts`
        // (`r.data ?? null`): con cualquier otro nombre el trabajo se resuelve OK y
        // con el resultado en null, que es un exito vacio — la misma familia de
        // mentira que acabamos de sacar del popup, una capa mas abajo.
        //
        // ⚠️ Y SE PARSEA. `mediaDeFlow` recorre el ARBOL buscando el nodo del medio;
        // un string JSON sin parsear es una hoja y la busqueda no entra.
        //
        // ⚠️ LO QUE TODAVIA NO ESTA MEDIDO: la FORMA del payload de BOQ. Es un array
        // posicional, no un objeto con `name` y `mediaGenerationStatus` como el REST
        // viejo, asi que hasta tener UNA respuesta real de generacion en la mano,
        // `mediaDeFlow` va a devolver null sobre esto. La respuesta la captura el
        // espejo sola (`respuestas` en injected.js) en cuanto haya una generacion de
        // verdad: se mide de ahi y recien entonces se escribe el mapeo. Escribirlo
        // antes seria adivinar la forma de algo que nadie vio.
        if (r.ok) {
          let data = r.payload;
          try { data = JSON.parse(r.payload); } catch { /* se manda crudo */ }
          return { id: trabajo.id, ok: true, data };
        }
        // ⚠️ `salio` DECIDE SI SE PUEDE REINTENTAR. Si el pedido llego a salir, el
        // credito ya se gasto: reintentar es cobrarle dos veces por un video.
        // ⚠️ EL DEFAULT ES **NO REINTENTAR**, Y ESA ASIMETRIA ES A PROPOSITO.
        //
        // Era `reintentable: !r.salio`, o sea que un `salio` AUSENTE se leia como
        // «no salio» y se reintentaba. Y ausente es justo lo que mandaban los dos
        // caminos donde el pedido SI habia salido: el timeout de 120 s y el catch
        // de afuera del espejo. Cinco intentos = cinco creditos por un video, y el
        // cliente con cinco clips iguales en su Flow.
        //
        // Ahora se reintenta SOLO con un `salio === false` explicito, que es una
        // afirmacion de que el pedido nunca viajo. Lo peor de este default es que
        // alguien tenga que apretar de nuevo; lo peor del otro era cobrarle.
        return {
          id: trabajo.id, ok: false,
          motivo: r.salio === false ? 'transitorio' : 'permanente',
          // ⚠️ NO PASA POR `clasificarFalla` DEL SERVER, A PROPOSITO. Ahi
          // `PUBLIC_ERROR_UNUSUAL_ACTIVITY` significa «sesion marcada» y PAUSA el
          // puente entero — correcto para el camino REST, donde lo dispara el ritmo.
          // Aca la causa mas probable es un token nuestro, y pausar todo por eso es
          // el diagnostico equivocado que ya costo un dia una vez.
          error: explicarFalloBoq(r),
          reintentable: r.salio === false,
        };
      }
    }
  }

  // ── EL ENLACE FIRMADO NO PASA POR EL ESPEJO ──────────────────────────────
  //
  // Es el unico trabajo asi, y la razon esta medida: el enlace de un clip no vive
  // en ninguna respuesta. `getMediaUrlRedirect?name=<id>` REDIRIGE al archivo, y
  // ese redirect no se puede leer con `fetch` ni desde la pagina ni desde el
  // service worker —CORS lo corta en las dos, y en modo manual el `Location` viene
  // ilegible—. Un <video> lo carga igual, porque los elementos de medio no piden
  // CORS.
  //
  // Asi que el trabajo es: PROVOCAR el pedido con un <video> suelto y leer a donde
  // fue, que es lo que `webRequest` ve desde afuera del modelo de CORS.
  //
  // El destino es una url firmada de flow-content.google que anda SIN cookies y
  // dura ~6 h, asi que con eso el servidor baja el archivo el mismo.
  if (trabajo.tipo === 'enlace_clip') {
    const mediaId = String((trabajo.pedido && trabajo.pedido.mediaId) || '');
    if (!mediaId) {
      return { id: trabajo.id, ok: false, motivo: 'transitorio', error: 'enlace_clip sin mediaId', reintentable: false };
    }
    const tabE = await pestanaDeFlow();
    if ((await asegurarContentScript(tabE.id)) === 'mudo') throw new Error('PUENTE_MUDO');
    redirectsDeMedios.delete(mediaId);
    const carga = await chrome.tabs.sendMessage(tabE.id, { tipo: 'PEDIR_ENLACE', mediaId });
    // Un instante: `onBeforeRedirect` corre en su propio hilo de eventos.
    await new Promise((r) => setTimeout(r, 400));
    const visto = redirectsDeMedios.get(mediaId);
    if (!visto || !visto.url) {
      return {
        id: trabajo.id, ok: false, motivo: 'transitorio',
        error: 'No se vio el redirect del medio (' + ((carga && carga.estado) || 'sin carga') + ')',
        reintentable: true,
      };
    }
    return { id: trabajo.id, ok: true, data: { url: visto.url, mediaId } };
  }

  const { path, body: pedidoOriginal, parches: parchesDelPedido } = trabajo.pedido || {};
  let parches = parchesDelPedido;
  if (typeof path !== 'string' || !path.startsWith('/v1')) {
    return { id: trabajo.id, ok: false, motivo: 'transitorio', error: 'pedido sin path válido', reintentable: false };
  }

  const tab = await pestanaDeFlow();

  // Reponer ANTES de gastar el trabajo. Un pedido que muere por un content
  // script ausente queda `puente_dormido`, que NO se reintenta: es un trabajo
  // quemado por algo que se arreglaba una linea antes.
  if ((await asegurarContentScript(tab.id)) === 'mudo') throw new Error('PUENTE_MUDO');

  // Los pedidos de LECTURA no llevan cuerpo, así que no llevan `recaptchaContext`
  // — y por lo tanto no hay que minar un token para ellos. Medido: `/v1/credits`
  // es un GET pelado. Pedir un `grecaptcha.execute()` cada 15 s sin que nadie
  // toque nada es, además, una señal de automatización por sí sola; hacerlo para
  // algo que ni siquiera lo usa era gratis en riesgo y caro en score.
  const sinCaptcha = SIN_CAPTCHA.has(trabajo.tipo);

  // ⚠️ `soloLectura` mezclaba DOS conceptos y eso rompio la consulta de estado.
  //
  // Significaba a la vez «no necesita captcha» y «no manda cuerpo». Para el saldo
  // las dos son ciertas. Para preguntar por un clip, la primera es cierta y la
  // segunda NO: la lista de operaciones por las que se pregunta VA en el cuerpo.
  //
  // Como el cuerpo no viajaba, Google contestaba los medios recientes del
  // proyecto en vez de los nuestros — y como ademas la respuesta se servia de la
  // CACHE de la propia pagina, lo que volvia eran los videos que el dueno habia
  // generado a mano. Medido: 24 consultas y NINGUNA mencionaba nuestra operacion,
  // mientras la pantalla decia «generando» para siempre.
  //
  // Ahora: el cuerpo va siempre que lo haya; el captcha, solo cuando hace falta.
  // Un body VACIO no es un body: `{}` es truthy y apagaba la cache de `creditos`,
  // que es justo el pedido que si conviene cachear porque no depende de nada
  // nuestro.
  // ⚠️ UN CUERPO CON `operations` SE CONVIERTE EN PARCHE, SIEMPRE.
  //
  // Medido el 31/08/2026: con el arreglo desplegado hacia media hora, produccion
  // SEGUIA encolando la consulta de estado con `body`, porque la pestana abierta
  // del cliente le habla al deploy con el que se cargo. O sea: el servidor se
  // arregla y el cliente sigue mandando la forma vieja durante todo lo que dure
  // esa pestana — y cada uno de esos pedidos se come un HTTP 400.
  //
  // El espejo es el unico lugar que SABE por que esa forma esta mal: `fundir()`
  // reemplaza los arrays enteros, asi que un `operations` nuestro TIRA el de
  // Flow con todo lo que lleva al lado. Traducirlo aca lo arregla para cualquier
  // version del servidor, vieja o nueva, sin esperar a nadie.
  //
  // Es acotado a proposito: SOLO `operations`, que es el unico array que un
  // pedido nuestro manda hoy. Convertir cualquier array a parches a ciegas seria
  // inventar una regla para casos que no existen.
  // ⚠️ Y `operations` NO ES EL CAMPO. Medido el 31/08/2026 sobre el pedido que
  // hace la propia pagina de Flow: el cuerpo real es
  // `{"media":[{"name":…,"projectId":…}]}`. `operations` no existe, y por eso
  // Google contestaba «Request contains an invalid argument».
  //
  // Un servidor viejo puede seguir mandando la forma equivocada durante todo lo
  // que dure una pestana abierta, asi que la traduccion vive aca: se saca el
  // nombre de donde estaba y se escribe donde va.
  let body = pedidoOriginal;
  if (body && Array.isArray(body.operations)) {
    const parchesDelCuerpo = {};
    body.operations.forEach((op, i) => {
      const nombre = op && (op.name || (op.operation && op.operation.name));
      if (nombre) parchesDelCuerpo[`media.${i}.name`] = nombre;
    });
    if (Object.keys(parchesDelCuerpo).length) {
      // Los del pedido ganan: son mas especificos que esta traduccion.
      parches = { ...parchesDelCuerpo, ...(parches || {}) };
      const { operations, ...resto } = body;
      body = Object.keys(resto).length ? resto : null;
      console.log('[mako] cuerpo viejo con `operations` traducido a `media` (servidor viejo)');
    }
  }

  const tieneCuerpo = !!body && Object.keys(body).length > 0;
  let cuerpo = tieneCuerpo ? { ...body } : null;

  // ⚠️ ACA HUBO UN clientContext INVENTADO, Y DURO UN COMMIT.
  //
  // Se agrego razonando que `estado_clips` era el unico tipo con parametros que
  // no lo recibia de nadie. El razonamiento era correcto y la conclusion no: el
  // cuerpo MEDIDO de este pedido es `{"media":[…]}` y NO LLEVA clientContext.
  // Agregarselo era exactamente el antipatron que el espejo existe para evitar —
  // nuestro dato inventado ganandole al copiado— y habria sido un segundo campo
  // que Google no reconoce encima del primero.
  //
  // Lo que quedo es el nombre del flag, que si valia la pena: `SIN_CAPTCHA` dice
  // la unica decision que toma, en vez de invitar a colgarle comportamientos.
  // ⚠️ `soloLectura` MEZCLABA DOS CONCEPTOS, Y ESO ROMPIO ESTA MISMA CONSULTA.
  //
  // Significa «no necesita captcha». Y de hecho significaba tambien «no manda
  // cuerpo» —eso ya se arreglo una vez, con su comentario— y ahora resulta que
  // significaba ademas «no necesita clientContext». `estado_clips` era el UNICO
  // tipo con parametros que no recibia `clientContext` de nadie: ni de aca,
  // porque este bloque se salteaba entero, ni de la plantilla, si la plantilla
  // quedo sin cuerpo.
  //
  // MEDIDO el 31/08/2026, y es lo que cierra el caso: con el pedido ya saliendo
  // por PARCHES —o sea sin pisar el array de Flow— el 400 siguio igual (#247).
  // Eso descarta la primera causa y deja esta: el pedido viajaba sin projectId,
  // sin tool y sin sessionId, que es exactamente un «argumento invalido».
  //
  // El `projectId` sale de las URLs que Flow hace de verdad y `tool: 'PINHOLE'`
  // esta MEDIDO en el cuerpo de `v1:checkAppAvailability`. No se inventa nada: lo
  // que no sabemos lo sigue poniendo la plantilla, porque `fundir` mezcla campo
  // por campo y lo nuestro solo gana en las dos claves que ponemos.
  if (!sinCaptcha) {
    const captcha = await pedirCaptcha(
      tab.id,
      accionDeCaptcha(trabajo.tipo, path),
      !!ACCION_CAPTCHA[trabajo.tipo],
    );
    cuerpo = { ...(body || {}) };
    // ⚠️ `projectId` solo viaja si lo SABEMOS. Iba siempre, y cuando estaba vacio
    // —que es casi siempre: solo se aprende de URLs con forma `/v1/projects/<id>/`
    // y ninguna de las que Flow hace de verdad la tiene— `fundir()` PISABA con ''
    // el projectId real que traia la plantilla. Un pedido de generacion que
    // declara no tener proyecto, con un bearer que si pertenece a uno, es una
    // incoherencia adentro del mismo request.
    //
    // Es el antipatron que el espejo existe para evitar: nuestro dato inventado
    // ganandole al copiado.
    cuerpo.clientContext = {
      ...(projectId ? { projectId } : {}),
      tool: 'PINHOLE',
      ...(cuerpo.clientContext || {}),
      recaptchaContext: { token: captcha },
    };
  }

  // ⚠️ EL PEDIDO NO SALE DE ACÁ, Y NO LO ARMAMOS NOSOTROS.
  //
  // Lo hace la PÁGINA de Flow, calcado del último pedido de la misma clase que la
  // propia app hizo (ver extension/injected.js). Dos razones, y las dos costaron:
  //
  //   1. Un `fetch` desde el service worker viaja con `Origin:
  //      chrome-extension://<id>` y sin las cookies del sitio. Google le contesta
  //      su página de bloqueo mientras la misma persona genera a mano sin problema:
  //      lo que rechaza tiene la forma exacta de un token robado.
  //   2. Reconstruir el pedido a mano es adivinar. El contrato salió de la doc de
  //      un tercero y le faltaba el `?key=` del proyecto; los headers que NO
  //      sabemos que faltan son peores, porque no hay a quién preguntarle.
  //
  // Con la plantilla se manda lo mismo que manda Flow. La `clase` es cómo se
  // encuentra: sale del último tramo del path (`/v1/credits` → `credits`).
  // ⚠️ Ya NO se arma la URL acá. La arma injected.js a partir de la plantilla: de
  // ahí salen el origen, el query (`?key=` incluido, y solo donde Flow lo manda) y
  // el método. Armarla acá y pasarla hecha fue el agujero de la primera versión
  // del espejo: se copiaba todo menos lo único que importaba.
  const clase = path.split('?')[0].split('/').filter(Boolean).pop() || '';
  const r = await chrome.tabs.sendMessage(tab.id, {
    tipo: 'HACER_FETCH', clase, path: path.split('?')[0], cuerpo, parches, soloLectura: sinCaptcha, bearer,
    // Por si la pestana se recargo y todavia no vio pasar este pedido.
    respaldo: await respaldoDe(clase),
  });
  if (!r || r.error) throw new Error(r?.error || 'FETCH_FALLO');

  const texto = String(r.texto || '');
  const res = { ok: r.status >= 200 && r.status < 300, status: r.status };
  let data = null;
  try { data = texto ? JSON.parse(texto) : null; } catch { /* lo trata el server */ }

  // ⚠️ La extensión NO clasifica el fallo: manda el crudo y el status. Quien
  // decide si se reintenta es el server (`clasificarFalla`), porque es quien
  // sabe cuántos créditos hay en juego. Si el navegador pudiera decidirlo,
  // estaría decidiendo cuántas veces le pegamos a Google.
  if (!res.ok || (data && (data.error || (data.data && data.data.error)))) {
    // ⚠️ UN 401 DICE QUE EL BEARER YA NO SIRVE, Y HAY QUE CREERLE.
    //
    // `bearer` se guardaba y no se invalidaba nunca: era un «alguna vez», no un
    // «ahora» — la misma familia que `puente.estado`, que hoy se arregló
    // agregándole el latido. Con el token vencido, `if (!bearer)` seguía dando
    // falso y los cinco reintentos salían con la credencial muerta, cada uno
    // acuñando su reCAPTCHA contra la sesión de la persona. Cinco pedidos
    // rechazados es exactamente la forma del tráfico que Google marca.
    //
    // No hace falta medir cuánto dura un `ya29.` para esto: el 401 ES la medición.
    // Borrarlo hace que el próximo ciclo lo tome del tráfico real de Flow, que es
    // de donde sale, en vez de reusar el que ya se sabe muerto.
    if (res.status === 401) {
      bearer = '';
      try { await chrome.storage.local.remove('bearer'); } catch { /* el ciclo lo repone */ }
    }
    return { id: trabajo.id, ok: false, status: res.status, data, error: texto.slice(0, 400) };
  }
  return { id: trabajo.id, ok: true, data };
}

// ── EL MOTOR POR INTERFAZ ────────────────────────────────────────────────────
//
// Generar video, generar imagen y subir la foto se hacen apretando los botones
// reales de Flow en la pestaña de la persona (`flow-interfaz.js`). El porqué está
// en la cabecera de ese archivo y en docs/hallazgos-generativa.md.
//
// ⚠️ UN TRABAJO DE INTERFAZ NO DEVUELVE SU RESULTADO EN EL MISMO CICLO. Un video
// tarda minutos, y este ciclo no puede quedarse esperando: el latido es lo que le
// dice a MaKo que el navegador está vivo (`VIVO_MS`, dos minutos). Así que:
//
//   · al llegar, el trabajo se anota en storage (`interfaz:<id>`, fase `espera`)
//     y queda TOMADO del lado del server;
//   · cada latido manda `enCurso` y el server le renueva el `tomado_at`, para que
//     el rescate de diez minutos no lo reparta de nuevo mientras se trabaja;
//   · de a UNO por vez, la pestaña lo corre y escribe en storage cómo va;
//   · cuando termina, el latido siguiente manda el resultado con el id ORIGINAL.
//
// De a uno porque un video en reposo no tiene id en la grilla: se lo reconoce
// por haberlo visto nacer arriba, y con dos en vuelo no se sabría cuál es cuál.

const TIPO_INTERFAZ = { generar_clip: 'video', generar_imagen: 'imagen', subir_imagen: 'subida' };
const CLAVE_INTERFAZ_IDS = 'interfazIds';
const claveInterfaz = (id) => `interfaz:${id}`;
const FASES_EN_CURSO = ['espera', 'preparando', 'enviado', 'generando'];
/** Un trabajo que no pudo ni empezar en este rato se devuelve: no gastó nada. */
const ESPERA_MAX_MS = 5 * 60 * 1000;
/** Los registros cerrados se guardan un día, por si el server reparte de nuevo. */
const REGISTRO_MAX_MS = 24 * 60 * 60 * 1000;
let mudoSeguidas = 0;

function esDeInterfaz(trabajo) {
  return !!(trabajo && trabajo.pedido && trabajo.pedido.motor === 'interfaz' && TIPO_INTERFAZ[trabajo.tipo]);
}

async function registrosInterfaz() {
  const ids = (await chrome.storage.local.get(CLAVE_INTERFAZ_IDS))[CLAVE_INTERFAZ_IDS] || [];
  if (!ids.length) return [];
  const v = await chrome.storage.local.get(ids.map(claveInterfaz));
  return ids.map((id) => (v[claveInterfaz(id)] ? { ...v[claveInterfaz(id)], id } : null)).filter(Boolean);
}

async function guardarRegistro(id, cambios) {
  const k = claveInterfaz(id);
  const actual = (await chrome.storage.local.get(k))[k] || {};
  await chrome.storage.local.set({ [k]: { ...actual, ...cambios, cuando: Date.now() } });
  const ids = (await chrome.storage.local.get(CLAVE_INTERFAZ_IDS))[CLAVE_INTERFAZ_IDS] || [];
  if (!ids.includes(id)) await chrome.storage.local.set({ [CLAVE_INTERFAZ_IDS]: [...ids, id] });
}

/** Lo que le contesta a MaKo un registro cerrado, con el id del trabajo ORIGINAL. */
function resultadoDeRegistro(r) {
  if (r.fase === 'listo') {
    if (r.tipo === 'subida') return { id: r.id, ok: true, data: { motor: 'interfaz', media: { name: r.mediaId } } };
    if (r.tipo === 'imagen') {
      return { id: r.id, ok: true, data: { motor: 'interfaz', imagenes: [{ url: r.url || '', mediaId: r.mediaId || '' }], propio: !!r.propio } };
    }
    return { id: r.id, ok: true, data: { motor: 'interfaz', mediaId: r.mediaId || '', url: r.url || '', propio: !!r.propio } };
  }
  // ⚠️ SE REINTENTA SOLO CON `salio === false` EXPLÍCITO. Un registro que no lo
  // dice —uno de una versión vieja, uno cortado a la mitad— se trata como pagado.
  const salioNo = r.salio === false;
  return {
    id: r.id,
    ok: false,
    motivo: salioNo ? 'transitorio' : (r.motivo === 'contenido' ? 'contenido' : 'permanente'),
    error: r.error || 'Flow no pudo generarlo.',
    reintentable: salioNo && !r.noReintentar,
  };
}

/** Llega un trabajo de interfaz: se anota y queda tomado. NUNCA se corre dos veces. */
async function recibirDeInterfaz(trabajo) {
  const previo = (await chrome.storage.local.get(claveInterfaz(trabajo.id)))[claveInterfaz(trabajo.id)];
  if (previo) {
    // Ya lo tenemos. Si terminó y el server lo vuelve a repartir (el rescate de
    // colgados), se reenvía el resultado; si sigue en curso, no se hace nada.
    if (previo.fase === 'listo' || previo.fase === 'fallo') await guardarRegistro(trabajo.id, { reportado: false });
    return;
  }
  await guardarRegistro(trabajo.id, {
    trabajoTipo: trabajo.tipo,
    tipo: TIPO_INTERFAZ[trabajo.tipo],
    fase: 'espera',
    salio: false,
    desde: Date.now(),
    pedido: trabajo.pedido,
  });
}

async function hablarConInterfaz(tabId, msg) {
  try { return await chrome.tabs.sendMessage(tabId, msg); } catch { return null; }
}

/** Pone (o repone) el motor en la pestaña. Un script de una versión vieja no sirve. */
async function asegurarInterfaz(tabId) {
  const v = chrome.runtime.getManifest().version;
  const r = await hablarConInterfaz(tabId, { tipo: 'INTERFAZ_ESTADO' });
  if (r && r.version === v) return r;
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['flow-interfaz.js'] });
  } catch (e) {
    console.warn('[mako] no se pudo poner el motor de interfaz:', e);
    return null;
  }
  return hablarConInterfaz(tabId, { tipo: 'INTERFAZ_ESTADO' });
}

/** El estado del motor en la pestaña de Flow, para el juicio de «puede filmar». */
async function estadoInterfaz() {
  let tab;
  try { tab = await pestanaDeFlow(); } catch (e) {
    return { puede: false, porQue: String((e && e.message) || 'NO_FLOW_TAB') };
  }
  if (!esFlowNuevo(tab.url)) return { puede: false, porQue: 'INTERFAZ_FLOW_VIEJO' };
  return (await asegurarInterfaz(tab.id)) || { puede: false, porQue: 'INTERFAZ_MUDA' };
}

/**
 * La página de MAIN atrapa el `input.click()` del menú «Upload» y le entrega la
 * foto, sin abrir el diálogo del sistema. Va en MAIN porque el clic lo hace el
 * código de Flow, y ese no ve los prototipos del mundo aislado.
 */
function instalarAtrapaArchivo() {
  if (window.__makoAtrapaArchivo) return;
  window.__makoAtrapaArchivo = true;
  let pendiente = null;
  window.addEventListener('message', (ev) => {
    if (ev.source !== window || !ev.data || !ev.data.makoArchivo) return;
    pendiente = ev.data.makoArchivo;
    setTimeout(() => { pendiente = null; }, 20000);
  });
  const entregar = (input) => {
    const a = pendiente;
    pendiente = null;
    const bin = atob(a.b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    const dt = new DataTransfer();
    dt.items.add(new File([bytes], a.nombre, { type: a.tipo }));
    input.files = dt.files;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  };
  const click = HTMLInputElement.prototype.click;
  HTMLInputElement.prototype.click = function () {
    if (this.type === 'file' && pendiente) return entregar(this);
    return click.call(this);
  };
  const ver = HTMLInputElement.prototype.showPicker;
  if (ver) {
    HTMLInputElement.prototype.showPicker = function () {
      if (this.type === 'file' && pendiente) return entregar(this);
      return ver.call(this);
    };
  }
}

/** La misma url con `hl=en`: los rótulos que busca el motor son los de la interfaz en inglés. */
function enIngles(url) {
  try { const u = new URL(url); u.searchParams.set('hl', 'en'); return u.toString(); } catch { return url; }
}

/** Deja la pestaña lista para que el motor trabaje: despierta, en inglés y con el script. */
async function pestanaParaInterfaz() {
  const tab = await pestanaDeFlow();
  if (!esFlowNuevo(tab.url) || !enProyectoDeFlow(tab.url)) throw new Error('NO_FLOW_TAB');
  // Chrome duerme las pestañas que no se miran: la de Flow, mientras genera, no.
  try { await chrome.tabs.update(tab.id, { autoDiscardable: false }); } catch { /* no es grave */ }
  let est = await asegurarInterfaz(tab.id);
  if (est && est.idioma && !/^en\b/.test(est.idioma) && !est.ocupado) {
    await chrome.tabs.update(tab.id, { url: enIngles(tab.url) });
    await esperarCarga(tab.id);
    await new Promise((r) => setTimeout(r, 2500));
    est = await asegurarInterfaz(tab.id);
  }
  if (!est) throw new Error('PUENTE_MUDO');
  return { tab, est };
}

/**
 * Un paso del motor por latido: cierra lo que quedó huérfano o arranca el
 * siguiente. Nunca hay dos en vuelo.
 */
async function avanzarInterfaz({ arrancar = true } = {}) {
  const regs = await registrosInterfaz();
  const ahora = Date.now();

  // Limpieza: lo cerrado y reportado hace más de un día ya no lo va a pedir nadie.
  const viejos = regs.filter((r) => !FASES_EN_CURSO.includes(r.fase) && r.reportado && ahora - (r.cuando || 0) > REGISTRO_MAX_MS);
  if (viejos.length) {
    await chrome.storage.local.remove(viejos.map((r) => claveInterfaz(r.id)));
    const quedan = regs.filter((r) => !viejos.includes(r)).map((r) => r.id);
    await chrome.storage.local.set({ [CLAVE_INTERFAZ_IDS]: quedan });
  }

  const enVuelo = regs.find((r) => ['preparando', 'enviado', 'generando'].includes(r.fase));
  if (enVuelo) {
    // ¿Lo sigue alguien? Si la pestaña contesta y está libre, el script que lo
    // seguía murió (una recarga, la pestaña cerrada): se cierra el registro. Si
    // no contesta, se le dan tres latidos antes de darlo por perdido.
    let est = null;
    try { est = await hablarConInterfaz((await pestanaDeFlow()).id, { tipo: 'INTERFAZ_ESTADO' }); } catch { est = null; }
    if (est && est.ocupado === enVuelo.id) { mudoSeguidas = 0; return; }
    if (!est && ++mudoSeguidas < 3) return;
    mudoSeguidas = 0;
    if (ahora - (enVuelo.cuando || 0) < 20000) return;
    await guardarRegistro(enVuelo.id, enVuelo.salio === false
      ? { fase: 'fallo', motivo: 'transitorio', error: 'La pestaña de Flow se cerró antes de empezar.' }
      : { fase: 'fallo', motivo: 'permanente', codigo: 'RECARGADA', error: 'La pestaña de Flow se recargó mientras generaba. Lo pedido quedó en tu proyecto de Flow y MaKo no lo volvió a pedir.' });
    return;
  }

  const espera = regs.filter((r) => r.fase === 'espera').sort((a, b) => (a.desde || 0) - (b.desde || 0));
  if (!espera.length) return;
  const r = espera[0];
  if (ahora - (r.desde || ahora) > ESPERA_MAX_MS) {
    // No gastó nada: se devuelve para que lo tome otro latido (o se reintente).
    await guardarRegistro(r.id, { fase: 'fallo', motivo: 'transitorio', error: 'No hubo una pestaña de Google Flow lista para hacerlo.' });
    return;
  }
  // Con la sesión marcada o la pestaña sin poder filmar no se arranca nada: sólo
  // se cierra lo que venció, que es lo que evita un «encolado» para siempre.
  if (!arrancar) return;
  // El ritmo de una persona: entre una generación y la siguiente, el cooldown
  // del server y unos segundos más, que no son siempre los mismos.
  const pausa = cooldownMs + 3000 + Math.floor(Math.random() * 9000);
  if (ahora - (await ultimaLlamadaFlow()) < pausa) return;

  let lista;
  try { lista = await pestanaParaInterfaz(); } catch { return; }
  if (r.tipo === 'subida') {
    try {
      await chrome.scripting.executeScript({ target: { tabId: lista.tab.id }, world: 'MAIN', func: instalarAtrapaArchivo });
    } catch { /* el motor prueba con el input directo */ }
  }
  const pedido = { ...(r.pedido || {}), trabajoId: r.id, tipo: r.tipo };
  const resp = await hablarConInterfaz(lista.tab.id, { tipo: 'INTERFAZ_CORRER', pedido });
  if (!resp || !resp.aceptado) return;
  // El pedido ya está en la pestaña: no se guarda dos veces (la foto pesa).
  await guardarRegistro(r.id, { fase: 'preparando', pedido: null });
  await marcarLlamadaFlow();
}

/** Lo que el latido le cuenta a MaKo del motor: lo terminado y lo que sigue en curso. */
async function cosecharInterfaz() {
  const regs = await registrosInterfaz();
  const cerrados = regs.filter((r) => (r.fase === 'listo' || r.fase === 'fallo') && !r.reportado);
  return {
    resultados: cerrados.map(resultadoDeRegistro),
    ids: cerrados.map((r) => r.id),
    enCurso: regs.filter((r) => FASES_EN_CURSO.includes(r.fase)).map((r) => r.id),
  };
}

async function marcarReportados(ids) {
  for (const id of ids) await guardarRegistro(id, { reportado: true });
}

// ── El ciclo ─────────────────────────────────────────────────────────────────

async function ciclo() {
  if (corriendo) return;
  corriendo = true;
  // ⚠️ EL RASTRO DEL LATIDO, y se escribe en TODAS las salidas.
  //
  // Es lo unico de lo que el popup puede pintar: sin esto no tiene forma de
  // distinguir «MaKo dijo que la sesion esta marcada» de «no pude ni hablar con
  // MaKo». Y va en un acumulador con `finally` y no «al final del ciclo» porque
  // este ciclo tiene CUATRO salidas tempranas (sin token, res.ok falso, el catch,
  // y el return de pausado): escribiendolo al final, un 404 o una caida de red
  // nunca se registrarian y el popup pintaria el ultimo latido bueno para
  // siempre — que es el modo de falla mas caro, porque se lee como que anda.
  const latido = { ok: false, http: 0, estado: '', detalle: '', cuando: Date.now() };
  // ¿Este ciclo ejecuto algo? Decide si se encadena otro en el acto en vez de
  // esperar a la alarma. Va afuera del `try` por la misma razon que `latido`:
  // este ciclo tiene cuatro salidas tempranas.
  let hizoAlgo = false;
  try {
    // ⚠️ Y TAMPOCO SE GATEA CON TENER TOKEN DE MaKo, que es el gate de aca abajo.
    //
    // Mirar lo que Flow hace en la pestana de la persona no necesita NINGUNA
    // credencial nuestra. Pero `if (!token) return` corta el ciclo entero, asi que
    // una extension sin emparejar —token perdido, storage limpiado, instalacion
    // nueva— no aprende nunca, con Flow abierto y el clip ya generado. Mismo sintoma
    // exacto y ninguna linea de error.
    //
    // Va PRIMERO en el ciclo, antes de todo gate: es lo unico que no depende de nada.
    // ⚠️ APRENDER NO SE GATEA CON PODER TRABAJAR, Y ESTO LO TENIA AL REVES.
    //
    // `guardarPlantillas` vivia adentro del `if (estado === 'listo')` de abajo. Es
    // la unica linea que mueve lo que el espejo capturo desde la MEMORIA de la
    // pestana —que se vacia con cada F5— hasta el storage, que es de donde lo lee
    // todo el mundo.
    //
    // En el Flow nuevo `estado` NUNCA es `listo`: no hay bearer que capturar, asi
    // que la rama `if (!bearer)` de arriba escribe `sin_sesion` siempre. O sea que
    // ese gate hacia el guardado ESTRUCTURALMENTE INALCANZABLE justo ahi — y el
    // popup pedia generar el clip de prueba de nuevo por mas veces que la persona
    // pagara, porque lo que aprendia moria en la pestana.
    //
    // Reportado tres veces seguidas el 05/09/2026, la ultima con el cubo violeta a
    // la vista en la grilla y el popup diciendo «Ayudame a aprender».
    //
    // ⚠️ Y ES LA TRAMPA QUE ESTE REPO YA TIENE ESCRITA, palabra por palabra: «¿la
    // condicion que activa a mi arreglo puede ser falsa POR CULPA de lo que el
    // arreglo viene a arreglar?». Aca la respuesta era si, y en el peor sentido —
    // el aprendizaje existe PARA salir del estado que lo estaba bloqueando. Peor
    // aun: el comentario del bloque de abajo ya dice la regla correcta («no poder
    // MIRAR no es no poder trabajar») y el codigo hacia lo contrario.
    //
    // Va afuera, sin gate y con su propio try: fallar mirando no puede apagar nada,
    // y no tiene una sola via para cambiar `estado`.
    try {
      const tabAprender = await pestanaDeFlow();
      if ((await asegurarContentScript(tabAprender.id)) !== 'mudo') {
        await guardarPlantillas(tabAprender.id);
      }
    } catch { /* sin pestana no hay nada que aprender, y no es un fallo */ }

    const { token } = await chrome.storage.local.get('token');
    if (!token) { latido.estado = 'sin_token'; return; }

    // ⚠️ ACA SE DECIDE QUE SIGNIFICA `listo`, Y ES EL UNICO LUGAR QUE LO DECIDE.
    //
    // De este booleano cuelgan CUATRO compuertas duras: el boton de la web
    // (`disabled={!puedeCrear || !puenteAnda}`), la cola de esta misma extension
    // (`if (out.pausado || estado !== 'listo') return`), el reparto del server
    // (`estado === 'sin_sesion' ? [] : tomarTrabajos()`) y el guard de filmar en
    // `video-action.ts`. Los cuatro leen lo mismo, asi que este renglon abre o
    // cierra el producto entero.
    //
    // Y estuvo CERRADO PARA SIEMPRE. `listo` significaba «hay un bearer»; en
    // flow.google.com Google no emite ninguno —la app habla solo por BOQ, con
    // cookies— y este mismo ciclo lo BORRA a proposito al ver el dominio nuevo. O
    // sea que la condicion se negaba a si misma dos lineas mas abajo: nadie podia
    // apretar el boton, nadie repartia el trabajo, nadie lo corria.
    //
    // El sintoma que lo delato: el popup decia «MaKo ya puede hacer tus anuncios» y
    // el aviso de al lado, en la misma pantalla y el mismo segundo, decia «MaKo
    // todavia no puede filmar tus anuncios». Dos pantallas, el mismo hecho, y NI UN
    // insumo en comun.
    //
    // Ahora `listo` es un ENSAYO EN SECO: el camino de `repetirEnBoq` recorrido
    // hasta un paso antes de mandar. No gasta un credito, no toca la red, y no
    // puede mentir — es literalmente el mismo predicado que la ejecucion exige.
    let estado = 'listo';
    let detalle = '';
    let respuestasVistas = null;

    // Una sola consulta de la pestaña para las dos decisiones que dependen de ella.
    let enFlowNuevo = false;
    try {
      const tfl = await pestanaDeFlow();
      enFlowNuevo = esFlowNuevo(tfl.url);
      // ⚠️ EL PROYECTO SE APRENDE DE LA URL DE LA PESTAÑA. El unico lugar que lo
      // aprendia era el webRequest del protocolo viejo (`/v1/projects/<id>/`), que
      // en flow.google.com no existe: un navegador que empezo directo en el Flow
      // nuevo no sabia nunca su proyecto, y «Empezar» abria la portada.
      const mp = /\/project\/([0-9a-f-]{36})/i.exec(tfl.url || '');
      if (mp && mp[1] !== projectId) { projectId = mp[1]; await chrome.storage.local.set({ projectId }); }
    } catch { /* sin pestaña */ }

    // El bearer guardado en el Flow nuevo es un recuerdo del protocolo viejo: no se
    // puede refrescar ahi, asi que mientras siga puesto todo lo que pregunta «¿hay
    // bearer?» contesta que si. Se tira. (Es la regla de la casa: el estado se lee
    // vivo, no se recuerda.)
    if (bearer && enFlowNuevo) {
      bearer = '';
      await chrome.storage.local.remove('bearer');
    }

    if (enFlowNuevo) {
      const guardadas = (await chrome.storage.local.get(CLAVE_PLANTILLAS))[CLAVE_PLANTILLAS] || {};
      // Con el motor por interfaz, lo que decide es la PESTAÑA: ver `puedeFilmar`.
      const ensayo = puedeFilmar(guardadas, A_PEDIR, await estadoInterfaz());
      if (!ensayo.puede) {
        estado = 'sin_sesion';
        // ⚠️ DIAGNOSTICO, NO COPY. Termina en la base para quien lea buscando por
        // que algo no filma; la pantalla del cliente deriva su frase de un estado
        // cerrado. Este repo ya pago dos veces por pintar un campo libre en la
        // cara de alguien.
        detalle = 'FLOW_NUEVO ' + ensayo.porQue;
      }
    } else if (!bearer) {
      // El camino REST, que sigue vivo para quien todavia este en labs.google. Ahi
      // el bearer y la apiKey SI hacen falta: sin ellos el pedido va sin proyecto
      // atribuido y Google contesta su pagina de bloqueo.
      estado = 'sin_sesion';
      detalle = 'Abre Google Flow desde el ícono de MaKo e inicia sesión.';
    } else if (!apiKey) {
      // El bearer se ve en la PRIMERA llamada; la `key` tambien, pero si la sesion
      // venia guardada y el usuario no volvio a navegar Flow, puede haber bearer sin
      // key. Sin key el pedido llega sin proyecto atribuido: reportarlo como `listo`
      // seria un verde sobre algo que va a fallar.
      estado = 'sin_sesion';
      detalle = 'Recarga la pestaña de Google Flow para completar la conexión.';
    }


    // Qué pedidos vio la página. Viaja en `detalle` para que un fallo se pueda
    // diagnosticar mirando la base, sin pedirle a nadie otra captura de pantalla.
    // ⚠️ SE LIMPIA UNA VEZ POR CICLO, Y ESTABA ADENTRO DEL GATE.
    //
    // `reparadasEnEstaVuelta` evita reinyectar el content script dos veces en la
    // misma vuelta. Su `clear()` vivia adentro del `if (estado === listo)`, que en el
    // Flow nuevo es falso SIEMPRE — asi que no se limpiaba nunca y el Set duraba toda
    // la VIDA del service worker.
    //
    // Efecto: UN solo intento de reponer el puente por vida del worker. Si la primera
    // vez la pestana no estaba lista, `asegurarContentScript` contesta «mudo» para
    // siempre y el espia deja de mirar — sin un error que lo diga.
    // Lo que vio el espejo, para diagnosticar. NUNCA se muestra: va aparte de
    // `detalle`, que es lo que lee el cliente.
    let espia = '';

    reparadasEnEstaVuelta.clear();

    // Lo ya guardado, para saber que clases YA tienen operacion y mandarlas al final
    // del `detalle` — el recorte tiene que gastarse en lo que falta identificar.
    let guardadasParaOrden = {};
    try {
      guardadasParaOrden = (await chrome.storage.local.get(CLAVE_PLANTILLAS))[CLAVE_PLANTILLAS] || {};
    } catch { guardadasParaOrden = {}; }

    // ⚠️ EL ESPIA TAMBIEN SALE DEL GATE — quedo adentro cuando se saco el guardado,
    // y por eso `estado_detalle` llegaba VACIO desde el Flow nuevo.
    //
    // Es la mitad que faltaba del mismo arreglo: se movio `guardarPlantillas` y no
    // esto, asi que el servidor seguia sin recibir los CUERPOS. Y los cuerpos son lo
    // unico que permite identificar una operacion que no lleva prompt —subir una
    // imagen, leer el saldo— porque en BOQ todas comparten path.
    //
    // Un arreglo a medias sobre una causa entendida es peor que ninguno: deja el
    // sintoma vivo con el diagnostico dado por cerrado.
    try {
      const tabE = await pestanaDeFlow();
      const r = await chrome.tabs.sendMessage(tabE.id, { tipo: 'VER_ESPIA' });
      if (r && r.visto) {
        // ⚠️ EL PRESUPUESTO SE GASTA EN LO QUE NO SE CONOCE.
        //
        // El `detalle` se corta en 7500 caracteres, y con ~39 clases eso alcanza para
        // unas 14. Sin ordenar, las 14 que llegan son las alfabeticamente primeras —
        // o sea, cualquiera. Y lo unico que hace falta medir es justo lo que el
        // sistema TODAVIA NO SABE reconocer.
        //
        // Medido hoy: llegaron 14 clases y ninguna era la que faltaba identificar.
        // Un recorte que no prioriza tira exactamente el dato que se estaba buscando,
        // y no lo dice: se lee como «no estaba».
        const conocida = (clase) => !!operacionDeLaClase(clase)
          || Object.values(guardadasParaOrden).some((p) => p && p.clase === clase && p.op);
        const orden = Object.entries(r.visto)
          .sort((a, b) => (conocida(a[0]) ? 1 : 0) - (conocida(b[0]) ? 1 : 0));
        // ⚠️ VA EN SU PROPIO CAMPO, NUNCA EN `detalle`.
        //
        // `detalle` es el MENSAJE HUMANO que la app le muestra al cliente en su
        // pantalla (app/video-generator/puente-avisos.tsx lo pinta tal cual). Al
        // escribirle encima el JSON del espia, un cliente termino leyendo
        //   {"boq:cPZSdc":{"metodo":"POST","hayRespuesta":true,"url":"/_/AiSandbox…
        // en su propia pantalla, cortado a la mitad y pegado a una frase suelta.
        //
        // Son dos canales con dos publicos: uno lo lee una persona que quiere saber
        // que hacer, el otro lo leo yo para diagnosticar. Mezclarlos convierte cada
        // mejora del diagnostico en una regresion de la pantalla.
        espia = JSON.stringify(Object.fromEntries(orden)).slice(0, 7500);
      }
    } catch { /* no poder mirar no apaga nada */ }

    if (estado === 'listo') {
      try {
        const tab = await pestanaDeFlow();

        // ACA EL PUENTE DEJA DE MENTIR.
        //
        // `estado` se calculaba solo con el bearer y la apiKey, que viven en
        // chrome.storage y sobreviven a cualquier reinicio. O sea que decia
        // «listo» con la pestana muda — y el server, viendo verde, le seguia
        // repartiendo trabajo: cada uno moria terminal en el primer intento. Una
        // cola entera se vaciaba en fallos con el semaforo en verde.
        //
        // Este y `NO_FLOW_TAB` son los UNICOS dos caminos por los que este ciclo
        // apaga el puente. Cualquier otro fallo —espiar, guardar plantillas— NO
        // apaga nada: no poder MIRAR no es no poder trabajar.
        if ((await asegurarContentScript(tab.id)) === 'mudo') {
          estado = 'sin_sesion';
          detalle = 'La pestana de Google Flow esta abierta pero no responde, y no se pudo reponer el puente. Recargala (F5).';
          throw new Error('MUDO');
        }

        // El guardado de plantillas ya corrio ARRIBA, afuera de este gate. Ver el
        // bloque «APRENDER NO SE GATEA CON PODER TRABAJAR»: dejarlo aca lo hacia
        // inalcanzable en el unico caso en que hay algo nuevo que aprender.
        // Lo que Flow ya recibio, por su propio canal. Va aparte del `detalle`
        // porque ese tiene tope de 7500 y las clases que generan se lo comen.
        try {
          const r = await chrome.tabs.sendMessage(tab.id, { tipo: 'VER_RESPUESTAS' });
          if (r && r.respuestas) respuestasVistas = r.respuestas;
          // ⚠️ RE-ETIQUETADAS POR OPERACION. El server guarda respuestas por un
          // allowlist de claves, y una clase de BOQ (`boq:<rpcid>`) no puede estar
          // en ninguna lista: el rpcid rota. Con el `op` de la plantilla local, la
          // respuesta de la generacion viaja como `op:generar_clip` y por fin se
          // guarda — es lo unico que permite MEDIR la forma del payload sin gastar
          // otro credito.
          if (respuestasVistas && typeof respuestasVistas === 'object') {
            const mapaOps = (await chrome.storage.local.get(CLAVE_PLANTILLAS))[CLAVE_PLANTILLAS] || {};
            for (const [clase, v] of Object.entries(respuestasVistas)) {
              const op = mapaOps[clase] && mapaOps[clase].op;
              const texto = typeof v === 'string' ? v : (v && typeof v.texto === 'string' ? v.texto : null);
              if (op && texto && !respuestasVistas['op:' + op]) respuestasVistas['op:' + op] = texto;
              // Y por RPC concreto: una operacion puede tener dos clases (la que genera
              // y un intermedio que tambien lleva la frase), y con una sola clave la
              // que quedaba era la del intermedio. La del que genera es la que se mide.
              const rpcid = (/^boq:([^,]+)/.exec(clase) || [])[1];
              if (op && texto && rpcid) respuestasVistas['op:' + op + ':' + rpcid] = texto;
            }
          }
          // De donde salen los medios que la pagina esta mostrando.
          if (r && Array.isArray(r.fuentes) && r.fuentes.length) {
            respuestasVistas = { ...(respuestasVistas || {}), '__fuentes': r.fuentes.join('\n') };
          }
        } catch { /* no poder mirar no apaga nada */ }

        const espia = await chrome.tabs.sendMessage(tab.id, { tipo: 'VER_ESPIA' });
        if (espia && espia.visto) {
          const visto = { ...espia.visto };

          // ⚠️ EL ESPIA MIRABA SOLO LA MEMORIA DE LA PESTANA, y esa se vacia con
          // cada F5. Resultado: el reporte listaba las 8 clases que Flow pide al
          // cargar la pagina y NINGUNA de las que generan — que son justo las que
          // hay que leer para saber por que un pedido nuestro sale mal.
          //
          // Medido el 31/08/2026: con una consulta de estado fallando con
          // HTTP 400, el detalle que llegaba al servidor no tenia ni una linea
          // sobre esa clase, aunque su plantilla existia (el pedido salio y Google
          // lo contesto). Estaba en el respaldo, que nadie reportaba.
          //
          // Las de memoria GANAN: son de esta sesion. El respaldo solo rellena lo
          // que hoy no se vio, marcado como tal para no leerlo como reciente.
          try {
            const guardadas = (await chrome.storage.local.get(CLAVE_PLANTILLAS))[CLAVE_PLANTILLAS] || {};
            for (const [clase, p] of Object.entries(guardadas)) {
              if (visto[clase]) continue;
              visto[clase] = {
                metodo: p.metodo,
                hayRespuesta: false,
                deRespaldo: true,
                url: String(p.url || '').replace(/key=[^&]+/, 'key=<oculta>'),
                headers: Object.keys(p.headers || {}).sort(),
                tieneCuerpo: p.cuerpo != null,
                esCascara: p.cuerpo == null && p.metodo !== 'GET' && p.metodo !== 'HEAD',
                cuerpoMuestra: p.cuerpo
                  ? String(p.cuerpo).slice(0, /generat/i.test(clase) ? 4000 : 200)
                  : null,
                edadMs: Date.now() - (p.cuando || 0),
              };
            }
          } catch { /* sin respaldo se reporta lo de memoria, que es lo de antes */ }

          // Ordenado con lo que GENERA primero: el detalle se corta al guardarse, y
          // lo que se pierde tiene que ser lo que ya conocemos, no el contrato que
          // estamos tratando de leer.
          // `/generat/i` cubre tambien `...VideoGenerationStatus`, que con
          // `/generate/i` quedaba al final y se lo comia el corte de 7500.
          const orden = Object.entries(visto).sort(
            (a, b) => (/generat/i.test(b[0]) ? 1 : 0) - (/generat/i.test(a[0]) ? 1 : 0),
          );
          detalle = JSON.stringify(Object.fromEntries(orden)).slice(0, 7500);
        }
      } catch (e) {
        // Si la pestana esta muda, `estado` y `detalle` ya se escribieron arriba y
        // no se pisan. Lo demas —no poder espiar— no apaga nada.
        const causa = String((e && e.message) || e);
        if (causa === 'FLOW_TAB_DORMIDA') {
          // ⚠️ UN MENSAJE QUE PIDE ALGO YA HECHO ENSEÑA A IGNORAR TODOS LOS DEMÁS.
          // Acá la pestaña existe: lo que hay que decir es que se está
          // despertando, no que falta abrirla.
          estado = 'sin_sesion';
          detalle = 'La pestana de Google Flow estaba dormida. La desperte: espera unos segundos sin cerrarla.';
        } else if (causa === 'NO_FLOW_TAB') {
          estado = 'sin_sesion';
          detalle = 'No hay ninguna pestana de Google Flow abierta. Abrila desde el icono de MaKo y dejala abierta.';
        }
      }
    }

    const pendientes = (await chrome.storage.local.get('pendientes')).pendientes || [];
    // Lo que el motor por interfaz terminó, con el id del trabajo original, y lo
    // que sigue en curso (el server le renueva el `tomado_at`). Va aparte de
    // `pendientes` porque se marca como reportado recién con el latido bueno.
    const cosecha = await cosecharInterfaz().catch(() => ({ resultados: [], ids: [], enCurso: [] }));

    // Lo que este navegador aprendio de Flow, para que no se pierda con el perfil.
    // Se manda solo cuando CAMBIO: son decenas de KB y el latido es cada 15 s.
    // Lo que la sonda dejo listo en un latido anterior.
    const { sondaResultado, sondaSW } = await chrome.storage.local.get(['sondaResultado', 'sondaSW']);
    if (sondaResultado) {
      respuestasVistas = { ...(respuestasVistas || {}), __sonda: String(sondaResultado).slice(0, 1400) };
    }
    if (sondaSW) {
      respuestasVistas = { ...(respuestasVistas || {}), __sondaSW: String(sondaSW).slice(0, 1400) };
    }
    const { ultimoRedirectMedio } = await chrome.storage.local.get('ultimoRedirectMedio');
    if (ultimoRedirectMedio) {
      respuestasVistas = { ...(respuestasVistas || {}), __redirect: String(ultimoRedirectMedio).slice(0, 1400) };
    }

    const plantillasLocales = await todasLasPlantillas();
    const firma = plantillasLocales
      .map((p) => `${p.clase}:${(p.cuerpo || '').length}:${p.metodo}`)
      .sort()
      .join('|');
    const { firmaPlantillas } = await chrome.storage.local.get('firmaPlantillas');
    const mandarPlantillas = firma && firma !== firmaPlantillas;

    // El estado ya no cambia despues de esto: es lo que se le va a contar a MaKo
    // y es lo que el popup tiene que pintar.
    latido.estado = estado;
    latido.detalle = detalle;

    const res = await fetch(`${MAKO}/api/flow/puente`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-flow-token': token },
      // ⚠️ `plantillas` va solo cuando cambio; `clases` va SIEMPRE, porque es lo
      // que le permite al servidor contestar unicamente lo que falta.
      // ⚠️ `version` NO es telemetria: es la respuesta a «¿que codigo esta
      // corriendo alla?», que ya costo horas una vez —el cliente estuvo toda una
      // tarde con una copia vieja y nada lo mostraba— y volvio a costar hoy, al
      // no poder saber desde el server si el arreglo del captcha estaba puesto.
      //
      // Un artefacto que se distribuye COPIADO se desincroniza el mismo dia. Si
      // no dice su version, cada diagnostico arranca preguntando.
      body: JSON.stringify({
        token, projectId, estado, detalle, resultados: [...pendientes, ...cosecha.resultados], cuantos: LOTE,
        enCurso: cosecha.enCurso,
        version: chrome.runtime.getManifest().version,
        // La MEDICION del captcha. Vivia solo en la consola del service worker, o
        // sea que para leerla habia que pedirle a una persona que abriera DevTools
        // y copiara una linea — y si el navegador es de otro, ni eso. Un dato de
        // diagnostico que hay que pedir no es un dato: es una molestia.
        accionesCaptcha: ((await chrome.storage.local.get('accionesDeFlow')).accionesDeFlow || []).join(','),
        // Que clases tiene ESTE navegador. Es lo unico que el servidor necesita
        // para contestar solo lo que falta en vez de mandarlo todo cada 15 s.
        clases: plantillasLocales.map((p) => p.clase),
        // ⚠️ Y LOS ROLES. La clase de BOQ lleva un rpcid que rota, asi que sin esto el
        // servidor devuelve como «faltante» una operacion que este navegador YA sabe,
        // guardada bajo el rpcid de otro dia. Sembrarla deja una entrada muerta y el
        // conteo de «N de M» empieza a mentir.
        ops: plantillasLocales.map((p) => p.op).filter(Boolean),
        // ⚠️ EL DIAGNOSTICO VIAJA SIEMPRE, PASE LO QUE PASE CON EL ESTADO.
        //
        // Es la leccion mas cara del 05/09/2026: todo lo que el navegador contaba de
        // si mismo —las clases, el espia, el `detalle`— viajaba adentro de un
        // `if (estado === 'listo')` que en el Flow nuevo es falso SIEMPRE. Asi que el
        // servidor no recibia NADA con lo que diagnosticar, y no habia forma de
        // distinguir «el puente no aprendio» de «el puente no pudo contarme nada».
        //
        // Se razono a ciegas sobre el navegador de otra persona durante tres rondas y
        // una auditoria de 191 agentes, por un dato que cuesta esto.
        //
        // ⚠️ SIN CUERPOS Y SIN URLS: aca viaja lo que el navegador vio de una sesion
        // autenticada de Google. Un cuerpo de BOQ trae el `at`; una url trae el
        // `source-path` con el projectId. Nada de eso hace falta para contestar «que
        // sabe hacer este puente», que es lo unico que este dato existe para decir.
        diagnostico: await armarDiagnostico(plantillasLocales, latido.estado || estado),
        // El detalle por clase de lo que el espejo vio. Es para diagnosticar y NO se
        // muestra en ninguna pantalla — por eso viaja aparte de `detalle`.
        espia,
        // Lo que Flow ya recibio, para saber de donde sale el enlace de un video.
        ...(respuestasVistas ? { respuestas: respuestasVistas } : {}),
        ...(mandarPlantillas ? { plantillas: plantillasLocales } : {}),
      }),
    });
    latido.http = res.status;
    // ⚠️ Un 404 NO es un error de red: es «este token ya no existe», y pasa cada
    // vez que alguien conecta otro navegador (el upsert por workspace rota el
    // token). El popup lo distingue por el numero y ofrece volver a conectar, en
    // vez de mandar a revisar internet.
    if (!res.ok) return;

    latido.ok = true;
    const out = await res.json();
    // ⚠️ `pausado`, y NO un campo `estadoPuente` que no existe: la respuesta del
    // latido no trae el estado del puente, trae `pausado`, que el server calcula
    // como `guardado === 'marcada'`. Es el UNICO camino por el que la extension
    // puede enterarse de que Google marco la sesion — ella nunca lo dice, solo
    // sabe decir `listo` o `sin_sesion`.
    if (out && out.pausado) latido.estado = 'marcada';
    // Los resultados ya viajaron: recién ahora se limpian. Si la request falló,
    // quedan y se reintentan — perder un resultado deja al cliente mirando
    // «generando…» sobre algo que en realidad terminó.
    await chrome.storage.local.set({ pendientes: [] });
    await marcarReportados(cosecha.ids);

    if (typeof out.cooldownMs === 'number') cooldownMs = out.cooldownMs;

    // ⚠️ LA SONDA LA PIDE EL SERVIDOR Y CORRE UNA SOLA VEZ.
    //
    // Contesta cual variante de `mediaUrlType` trae el VIDEO. El enum no esta
    // documentado en ningun lado que tengamos, y probar valores contra produccion
    // de a uno —esperando un reporte del dueno entre cada intento— es exactamente
    // el bucle que costo esta noche.
    //
    // Tarda hasta 12 s por candidato, asi que NO puede correr en cada latido: se
    // anota el mediaId sondeado y no se repite. El resultado viaja con el latido
    // SIGUIENTE, que es lo que hace que esto no bloquee la cola.
    try {
      const pedido = out.sonda;
      if (pedido && pedido.mediaId) {
        // ⚠️ CLAVE NUEVA, Y NO ES CAPRICHO.
        //
        // La 0.26.0 escribia `sondaHecha` ANTES de sondear, asi que el primer
        // intento fallido dejo el marcador puesto para siempre. La 0.27.0 arreglo
        // el orden — y no sirvio de nada, porque el valor envenenado seguia en el
        // storage del navegador y hacia que el bloque se salteara entero.
        //
        // Un arreglo de logica no limpia el estado que dejo el error. Cuando una
        // guarda persistida se escribio mal aunque sea una vez, hay que cambiarle
        // el nombre o borrarla: si no, la version arreglada nunca llega a correr.
        //
        // `sondaOk` se escribe UNICAMENTE cuando la sonda contesto.
        const { sondaOk } = await chrome.storage.local.get('sondaOk');
        if (sondaOk !== pedido.mediaId + '|redir') {
          const tabS = await pestanaDeFlow();
          // El content script se repone ANTES: recargar la extension deja
          // huerfanos los de las pestanas abiertas, que es JUSTO el momento en que
          // esto corre por primera vez.
          await asegurarContentScript(tabS.id);
          const r = await chrome.tabs.sendMessage(tabS.id, {
            tipo: 'SONDA_MEDIO', mediaId: pedido.mediaId, variantes: pedido.variantes,
          });
          if (r && r.sonda) {
            // ⚠️ SE ANOTA DESPUES DE QUE CONTESTO, no antes.
            //
            // La version anterior marcaba «ya sondeado» y RECIEN despues sondeaba,
            // asi que el primer intento fallido —la pestana muda un segundo despues
            // de recargar la extension, que es exactamente cuando esto corre—
            // quemaba la sonda para siempre y en silencio. Una guarda de un solo
            // intento tiene que contar los intentos que SIRVIERON.
            // ⚠️ Y LA MISMA PREGUNTA, PERO DESDE EL SERVICE WORKER.
            //
            // Medido: desde la PAGINA el `fetch` tira «Failed to fetch» — el
            // endpoint es mismo origen pero redirige a un host que no manda CORS.
            // Un <video> lo carga igual (los elementos de medio no piden CORS),
            // asi que el archivo esta ahi y lo unico que falta es poder LEERLO.
            //
            // El service worker juega con otras reglas: para los hosts que estan
            // en `host_permissions` —labs.google lo esta— Chrome NO le aplica CORS.
            // La incognita es el salto siguiente, al host del archivo, que no
            // sabemos cual es. Se prueba y se anota; con la respuesta se decide si
            // alcanza con esto o si hay que sumar ese host al manifest.
            //
            // Se prueban las dos formas: siguiendo el redirect (si funciona, ya
            // tenemos los bytes) y frenando en el (si se puede leer el `Location`,
            // el servidor baja el archivo el mismo y no viaja nada por aca).
            const desdeSW = {};
            // ⚠️ La RUTA es la de labs.google y en flow.google.com NO esta medida: si
            // alla cuelga de otro prefijo, esta sonda falla — y eso esta bien, porque es
            // una sonda de diagnostico envuelta en try/catch, no el camino del producto.
            // El camino real lo copia el espejo de injected.js, que ahora reconoce la API
            // de la app por la RUTA /api/trpc/ y no por el host.
            //
            // Del MISMO origen que la pestana de Flow que encontramos: el endpoint es
            // de la app, asi que vive donde este servida la app. Clavarlo en
            // labs.google lo mandaba al dominio del que Google ya movio a la gente.
            const urlMedio = `${origenDeFlow(tabS)}/fx/api/trpc/media.getMediaUrlRedirect?name=`
              + encodeURIComponent(pedido.mediaId);
            try {
              const rr = await fetch(urlMedio, { credentials: 'include' });
              const bb = await rr.blob();
              desdeSW.follow = {
                ok: true, status: rr.status, tipo: rr.type,
                contentType: bb.type, tamano: bb.size,
                urlFinal: String(rr.url || '').slice(0, 200),
              };
            } catch (e) {
              desdeSW.follow = { ok: false, mensaje: String((e && e.message) || e).slice(0, 160) };
            }
            try {
              const rm = await fetch(urlMedio, { credentials: 'include', redirect: 'manual' });
              desdeSW.manual = {
                ok: true, status: rm.status, tipo: rm.type,
                location: String(rm.headers.get('location') || '(no legible)').slice(0, 200),
              };
            } catch (e) {
              desdeSW.manual = { ok: false, mensaje: String((e && e.message) || e).slice(0, 160) };
            }

            await chrome.storage.local.set({
              sondaOk: pedido.mediaId + '|redir',
              sondaSW: JSON.stringify(desdeSW).slice(0, 1200),
              sondaResultado: JSON.stringify({ mediaId: pedido.mediaId, r: r.sonda, bytes: r.bytes }),
            });
          }
        }
      }
    } catch (e) {
      // ⚠️ UN `catch` VACIO SOBRE EL INSTRUMENTO QUE SE CONSTRUYO PARA NO ESTAR
      // CIEGO. Estuvo ochenta latidos sin contestar y las cuatro causas posibles
      // —no hay pestana, el sendMessage rechaza, el content script no contesta, o
      // la respuesta viene vacia— se veian exactamente igual desde el servidor:
      // nada. Es el mismo modo de falla que costo la noche, montado encima de la
      // herramienta que venia a evitarlo.
      await chrome.storage.local.set({
        sondaResultado: JSON.stringify({ error: String((e && e.message) || e) }),
      });
    }

    // Lo que se mando quedo guardado del otro lado: se anota la firma para no
    // volver a mandarlo hasta que cambie.
    if (mandarPlantillas) await chrome.storage.local.set({ firmaPlantillas: firma });
    // ⚠️ SI EL SERVER PIDE, LA FIRMA SE BORRA Y SE REENVIA EN EL PROXIMO LATIDO. La
    // firma no incluye la url, asi que un respaldo que descarto por url relativa se
    // quedaba vacio para siempre con este navegador convencido de haberlo mandado.
    if (out.pedirPlantillas) await chrome.storage.local.remove('firmaPlantillas');
    // El proyecto que el server ya conoce: es lo que le permite a un navegador NUEVO
    // abrir el proyecto correcto sin que la persona lo busque en Flow.
    if (out.projectId && ES_UUID.test(String(out.projectId))) await chrome.storage.local.set({ projectIdServidor: String(out.projectId) });

    // Y lo que falta aca lo repone el servidor. Con esto, un F5, un perfil nuevo
    // o reinstalar la extension dejan de costar «genera uno a mano»: lo que este
    // navegador aprendio una vez sirve para siempre.
    const sembradas = await sembrarPlantillas(out.plantillas);
    if (sembradas) console.log(`[mako] ${sembradas} plantilla(s) repuestas desde el servidor`);

    // ⚠️ ANTES de tomar trabajo nuevo y solo si no hay nada en curso: es el unico
    // momento del ciclo en el que reiniciar no pierde nada.

    await anotarVersionEsperada(out.versionEsperada);

    if (out.pausado || estado !== 'listo') {
      try { await avanzarInterfaz({ arrancar: false }); } catch { /* sólo limpieza */ }
      return;
    }

    const cola = out.trabajos || [];
    const nuevos = [];
    /** Google frenó la sesión: no sale ni un pedido más de este lote. */
    let frenar = false;
    for (let i = 0; i < cola.length; i++) {
      const t = cola[i];
      // ⚠️ EL COOLDOWN ES UN PISO ENTRE LLAMADAS, NO UN SLEEP AL FINAL DEL BUCLE.
      //
      // Antes vivia como un `await sleep(cooldownMs)` en la cola del `for`, y eso
      // solo espaciaba a los trabajos de UN MISMO lote. Mientras cada latido
      // traia un trabajo y despues dormia 15 s de alarma, alcanzaba por
      // accidente: la alarma hacia de guarda sin que nadie lo dijera.
      //
      // Al encadenar ciclos, ese accidente se termina — y con el sleep al final
      // del bucle, el ultimo trabajo de un lote y el primero del siguiente
      // quedaban separados por un viaje a nuestro servidor: ~0,3 s. O sea que dos
      // cambios que por separado no tocan la guarda, JUNTOS la desarman. Lo cazo
      // un revisor adversario y no una prueba, porque no rompe nada visible:
      // simplemente se le habla a Google mas rapido de lo permitido, y la factura
      // llega como un PUBLIC_ERROR_UNUSUAL_ACTIVITY que bloquea la sesion del
      // cliente.
      //
      // Esperando ANTES de llamar y contra el reloj de la ULTIMA llamada, la
      // guarda vale a traves de ciclos, de latidos y de reinicios del service
      // worker — y de paso desaparece la espera inutil despues del ultimo
      // trabajo, que era la mitad de lo que se venia a arreglar.
      // ⚠️ LOS DE INTERFAZ NO SE CORREN ACÁ: se anotan y quedan tomados. Los corre
      // `avanzarInterfaz`, de a uno, y su resultado viaja en un latido posterior.
      // No pasan por el cooldown de abajo porque anotarlos no le habla a Google.
      if (esDeInterfaz(t)) {
        await recibirDeInterfaz(t);
        continue;
      }
      const falta = cooldownMs - (Date.now() - (await ultimaLlamadaFlow()));
      if (falta > 0) await new Promise((r) => setTimeout(r, falta));
      try {
        const r = await ejecutar(t);
        nuevos.push(r);

        // ⚠️ UN 403 FRENA EL LOTE ENTERO, EN EL ACTO.
        //
        // `out.pausado` se mira ANTES del bucle, así que un lote ya tomado seguía
        // hasta el final aunque el primer trabajo volviera con la sesión marcada.
        // Medido el 01/09/2026: tres trabajos de una clienta, tres 403 seguidos
        // de `PUBLIC_ERROR_UNUSUAL_ACTIVITY`. Con esto habría sido UNO.
        //
        // Y no es un detalle de eficiencia: `lib/flow-protocolo.ts` lo dice con
        // todas las letras — «`sesion_marcada` es el peor y el único que obliga a
        // frenar todo: seguir pegando con la sesión marcada es lo que la termina
        // de quemar». La regla estaba escrita y no la aplicaba nadie de este lado.
        //
        // ⚠️ Y ACÁ NO SE CLASIFICA, que es la regla de este archivo: quien decide
        // si algo se reintenta es el server, porque es quien sabe cuántos créditos
        // hay en juego. Frenar no es clasificar — es la dirección SEGURA, la única
        // que este lado tiene permitido tomar solo.
        // ⚠️ SE MARCA Y SE ROMPE DESPUES DEL SELLO. El `break` no puede saltearse
        // el `marcarLlamadaFlow()` de abajo: un pedido rechazado IGUAL SALIO, y
        // no sellarlo dejaria al proximo ciclo creyendo que la ultima llamada fue
        // hace rato — o sea reintentando rapido contra un bloqueo, que es
        // exactamente como se profundiza.
        if (r && r.ok === false && r.status === 403) {
          frenar = true;
          for (const resto of cola.slice(i + 1)) {
            // Se devuelven SIN intentar, y reintentables: no fallaron, no
            // salieron. Sin esto quedan `tomado` hasta que el rescate de diez
            // minutos los suelte, y el cliente mira un loader ese rato entero.
            nuevos.push({
              id: resto.id,
              ok: false,
              motivo: 'transitorio',
              error: 'No se intentó: Google frenó la sesión en el trabajo anterior.',
              reintentable: true,
            });
          }
        }
      } catch (e) {
        const msg = String(e && e.message ? e.message : e);
        nuevos.push({
          id: t.id,
          ok: false,
          motivo: msg === 'NO_FLOW_TAB' ? 'sin_sesion' : 'transitorio',
          error: msg,
          reintentable: true,
        });
      }
      // ⚠️ DESPUES Y NO ANTES, y en el `finally` de hecho: el ritmo original
      // dormia al TERMINAR la llamada, asi que el hueco real entre dos pedidos
      // era «lo que tardo el primero + 10 s». Sellando al empezar, ese hueco se
      // encogeria a 10 s a secas — mas rapido que antes, que es exactamente lo
      // que no se puede hacer sin medir. Se sella al terminar y la guarda queda
      // igual de estricta que siempre, solo que ahora tambien entre ciclos.
      //
      // Y se sella aunque la llamada falle: un pedido rechazado igual salio, y
      // reintentar rapido contra un bloqueo es como se profundiza un bloqueo.
      await marcarLlamadaFlow();
      if (frenar) break;
    }
    // Un paso del motor por interfaz: arranca el siguiente o cierra un huérfano.
    try { await avanzarInterfaz(); } catch (e) { console.warn('[mako] motor de interfaz:', e); }
    if (nuevos.length) {
      await chrome.storage.local.set({ pendientes: nuevos });
      hizoAlgo = true;
    }
  } catch (e) {
    latido.detalle = String((e && e.message) || e);
  } finally {
    await chrome.storage.local.set({ ultimoLatido: latido });
    // La INSIGNIA es lo unico que se ve sin abrir nada, y es lo que reemplaza a
    // «volver a la web para enterarse». Sin permiso nuevo.
    try {
      await chrome.action.setBadgeText({ text: latido.ok && latido.estado === 'listo' ? '' : '!' });
      await chrome.action.setBadgeBackgroundColor({ color: '#d59b0a' });
    } catch { /* el badge no puede tumbar el ciclo */ }
    corriendo = false;

    // ⚠️ EL RESULTADO NO ESPERA A LA PROXIMA ALARMA.
    //
    // Los resultados se guardan en `pendientes` y se mandan al PRINCIPIO del
    // ciclo siguiente (ver la linea que los lee y el `set({ pendientes: [] })`
    // de mas arriba). O sea que todo trabajo terminado dormia un latido entero
    // antes de que MaKo se enterara — y despues la pantalla todavia tardaba
    // hasta 10 s mas en preguntar. Eso explica el numero que no cerraba de la
    // medicion: una consulta de estado y un pedido de enlace, que son dos
    // operaciones que no se parecen en nada, tardaban las dos ~14 s. No era
    // trabajo: era espera nuestra.
    //
    // Encadenar otro ciclo hace las dos cosas de una: manda lo que acaba de
    // terminar y se trae lo que siga. No le habla a Google de mas —lo unico que
    // se adelanta es el viaje a NUESTRO servidor— y el `cooldownMs` sigue
    // separando cada llamada a Flow exactamente igual que antes.
    if (hizoAlgo && cadena < CADENA_MAX) {
      cadena++;
      setTimeout(() => { void ciclo(); }, 0);
    } else {
      cadena = 0;
    }
  }
}

// ═════════════════════════════════════════════════════════════════════════
// LO QUE EL POPUP PIDE
// ═════════════════════════════════════════════════════════════════════════
// Los cuatro pasos de configuracion se mudaron al popup de la extension. Lo que
// sigue es lo que hace falta para que ahi se pueda hacer todo lo que NO exige la
// sesion de MaKo: conectar (disparando a la pagina), abrir y recargar Flow, y
// leer el saldo.

const URL_MAKO_TAB = `${MAKO}/video-generator`;
// ⚠️ EL DOMINIO NUEVO. Abria `labs.google/fx/tools/flow`, donde Google ya no deja a
// nadie: la persona terminaba en flow.google.com y la extension no reconocia esa
// pestana, asi que el boton que abre Flow era el que garantizaba que Flow no se
// detectara. Si una cuenta todavia no esta migrada, Google la manda a labs.google y
// `PATRONES_FLOW` la reconoce igual.
const URL_FLOW = 'https://flow.google.com/';

/**
 * El proyecto que se conoce: el que vio este navegador, o el que el server ya sabe.
 *
 * ⚠️ El segundo es lo que evita que Mauricio tenga que tocar Flow: su Chrome nuevo
 * no vio ningun proyecto todavia, pero el workspace ya tiene uno.
 */
async function proyectoConocido() {
  const v = await chrome.storage.local.get(['projectId', 'projectIdServidor']);
  for (const c of [v.projectId, v.projectIdServidor]) if (ES_UUID.test(String(c || ''))) return String(c);
  return '';
}

/** A donde se abre Flow: el proyecto si se conoce, la portada si no. */
async function destinoDeFlow() {
  const id = await proyectoConocido();
  return id ? `${URL_FLOW}project/${id}` : URL_FLOW;
}

/**
 * Conectar: el disparo vive aca, el acunado vive en la pagina.
 *
 * ⚠️ NO se puede acunar el token desde el service worker, y no es por falta de
 * ganas: `crearTokenPuente` guarda un sha256 —no existe endpoint que devuelva el
 * token existente— y un POST de extension muere en el chequeo de Origin del
 * proxy de MaKo, que rechaza `chrome-extension://`. Abrirle una excepcion no es
 * opcion mientras la extension se instale descomprimida: el id es distinto en
 * cada maquina, asi que la excepcion tendria que ser para cualquier extension.
 *
 * Entonces: se busca una pestana de MaKo, se le pide a SU content script que le
 * pida el token a la pagina, y si no hay ninguna se abre una.
 */
async function conectar(forzar) {
  // La marca de tiempo es lo que le permite al popup distinguir «esta
  // conectando» de «se murio conectando». Sin ella, una sola de las dos existe.
  await chrome.storage.local.set({ emparejando: true, emparejandoDesde: Date.now(), emparejarError: '' });
  try {
    let tabs = [];
    try { tabs = await pestanasDeMaKo(); } catch { tabs = []; }

    // ⚠️ SE PRUEBAN TODAS, NO LA PRIMERA QUE CONTESTE ALGO.
    //
    // Antes esto hacia `if (r) return`, y `r` es la respuesta del content script
    // —que SIEMPRE contesta, aunque sea su propio timeout—. O sea que la primera
    // pestana de MaKo de la lista decidia por todas: con una pestana vieja del
    // CRM abierta y la de /video-generator al lado, se le pedia el token a la del
    // CRM, fallaba, y ahi terminaba. Con dos pestanas abiertas, cual gana depende
    // del orden en que Chrome las devuelve.
    //
    // Ahora: gana el PRIMER EXITO. Si ninguna acuna, se guarda el fallo mas
    // informativo — un 'rol' o un 'sin_ws' los contesto el server sabiendo algo,
    // mientras que 'sin_enlace' solo dice que nadie atendio.
    // ⚠️ Y SE CORTA ANTE CUALQUIER RESPUESTA DEL SERVER, no solo ante `ok`.
    //
    // REGRESION MEDIDA, introducida el mismo dia que este bucle: seguir probando
    // despues de un `otro_navegador` DESCONECTA AL OTRO NAVEGADOR SIN PREGUNTAR.
    //
    // El mecanismo: `conectarPuenteAction` no acepta un `forzar` del cliente —lo
    // emite el server—. La primera vez contesta «ya hay otro» Y DEJA UN TICKET
    // armado por 60 s (`KEY_FORZAR`); el segundo pedido lo consume y pisa. Eso
    // esta bien cuando los dos pedidos son dos CLICS de la persona, con la
    // pantalla de «Si continuas, ese se desconectara» en el medio. Pero este
    // bucle hace los dos pedidos SEGUIDOS, sin pantalla y sin persona: la pestana
    // 1 arma el ticket y la pestana 2 lo consume.
    //
    // Y hoy pasa SIEMPRE que haya dos pestanas de MaKo abiertas, porque
    // `<PuenteEnlace/>` se mudo al layout raiz y ahora TODAS contestan. Antes
    // contestaba una sola y el bucle no llegaba a la segunda.
    //
    // Un motivo del server es una RESPUESTA: llego, pregunto, y le dijeron que
    // no. Probar otra pestana no cambia la respuesta —es la misma sesion y el
    // mismo workspace— y en el unico caso donde cambia algo, lo que cambia es
    // que se saltea el consentimiento. Solo `sin_enlace` justifica seguir: ahi
    // nadie contesto, y la de al lado puede.
    for (const t of tabs) {
      const r = await pedirEmparejar(t.id, forzar);
      if (r && (r.ok || r.motivo !== 'sin_enlace')) return await finEmparejado(r, null);
    }

    // ⚠️ Y SI TODAS CALLARON CON PESTANAS ABIERTAS, se recarga UNA y se reintenta.
    // El silencio casi siempre es una pestana cargada antes de que la extension
    // se instalara o se actualizara: su content script quedo huerfano. Reponerlo
    // ya se intenta en `pedirEmparejar`; lo que eso no arregla es una PAGINA
    // vieja, servida antes de que el enlace existiera. Eso lo arregla un F5.
    if (tabs.length) {
      const t = tabs.find((x) => x.active) || tabs[0];
      try {
        await chrome.tabs.reload(t.id);
        await esperarCarga(t.id);
        const r = await pedirEmparejar(t.id, forzar);
        if (r && r.ok) return await finEmparejado(r, null);
        if (r) return await finEmparejado(r, null);
      } catch { /* la cerraron mientras tanto: sigue el camino de abrir una */ }
    }

    // Ninguna pestana de MaKo: se abre una en segundo plano. Si la persona no
    // tiene sesion, la pagina no va a poder acunar y el pedido vuelve como
    // `sesion` — ahi la pestana se ACTIVA para que pueda entrar.
    const nueva = await chrome.tabs.create({ url: URL_MAKO_TAB, active: false });
    await esperarCarga(nueva.id);
    const r = await pedirEmparejar(nueva.id, forzar);
    // ⚠️ 'sin_enlace' y no 'sesion': que la pagina nueva no conteste puede ser que
    // no haya sesion —lo mas probable, y por eso la pestana se ACTIVA— o que no
    // haya terminado de cargar. Afirmar la primera es adivinar; el popup dice lo
    // que se sabe y la pestana abierta muestra lo que falte.
    return await finEmparejado(r || { ok: false, motivo: 'sin_enlace' }, nueva.id);
  } catch (e) {
    return await finEmparejado({ ok: false, motivo: 'error', error: String((e && e.message) || e) }, null);
  }
}

/**
 * DEJA EL NAVEGADOR LISTO PARA FILMAR, SIN PEDIRLE NADA A LA PERSONA.
 *
 * ⚠️ ESTO EXISTE PORQUE CASI TODO LO QUE FALLABA NO ERA UN BUG: ERA UN ESTADO QUE
 * LE PEDIAMOS AL USUARIO QUE ARMARA A MANO.
 *
 * La lista de lo que se reporto en tres dias, y que era siempre lo mismo:
 *
 *   · «no hay ninguna pestana de Flow abierta» — con Flow abierto al lado;
 *   · «inicia sesion en Google Flow» — logueada, mirando su avatar;
 *   · «abre un proyecto» — que nadie sabe que hace falta hasta que se lo dicen;
 *   · y la pestana de Flow DORMIDA, que Chrome descarta justo por mirar la de MaKo.
 *
 * Cada uno tuvo su arreglo y su cartel. Pero un cartel que pide armar un estado es
 * una tarea delegada al que menos contexto tiene, y la unica forma de que deje de
 * fallar es que no haya que armarlo: lo arma la extension, que es la unica que ve
 * las pestanas de las dos apps a la vez.
 *
 * El dueno lo pidio con esas palabras: «seria mucho mas facil si MaKo manejara las
 * tabs, para que no tenga que estar haciendo nada, y le decimos No toques nada».
 *
 * ── Que hace, en orden y por que ese orden ─────────────────────────────────
 *
 * 1. La pestana de FLOW primero. Es la que tarda (carga la app entera) y la que
 *    puede necesitar login. Arrancarla primero le da tiempo mientras se prepara lo
 *    demas.
 * 2. Adentro de un PROYECTO, no en la portada. El bearer y el resto del trafico que
 *    el puente necesita solo existen dentro de un proyecto — medido: en la lista de
 *    proyectos la app pide todo con cookies y no emite nada que sirva. Se usa el
 *    ultimo `projectId` visto; sin ninguno, se abre la portada y se dice que hay que
 *    entrar a uno, que es lo unico que no se puede hacer por la persona (elegir en
 *    cual de sus proyectos trabajar es una decision suya).
 * 3. La pestana de MAKO despues, y queda ACTIVA. Es donde la persona tiene que
 *    mirar; la de Flow trabaja atras.
 *
 * ⚠️ Y la de Flow se abre `active: false` a proposito. Activarla la traeria al
 * frente y dejaria la de MaKo atras — que es exactamente lo que hace que Chrome la
 * descarte y que despues no se encuentre. El orden de las pestanas ES parte del
 * arreglo, no una preferencia estetica.
 */
async function prepararEscenario() {
  const pasos = [];
  let avisoProyecto = false;

  // ── 1. Flow ───────────────────────────────────────────────────────────────
  let tabFlow = null;
  try { tabFlow = await pestanaDeFlow(); } catch { tabFlow = null; }

  if (tabFlow && !enProyectoDeFlow(tabFlow.url)) {
    // Hay pestana pero esta en la portada: se la lleva al ultimo proyecto visto.
    const guardado = await proyectoConocido();
    if (ES_UUID.test(String(guardado || ''))) {
      await chrome.tabs.update(tabFlow.id, { url: `${origenDeFlow(tabFlow)}/project/${guardado}` }).catch(() => {});
      await esperarCarga(tabFlow.id);
      pasos.push('proyecto');
    } else {
      avisoProyecto = true;
    }
  } else if (!tabFlow) {
    const guardado = await proyectoConocido();
    const destino = ES_UUID.test(String(guardado || ''))
      ? `${URL_FLOW}project/${guardado}`
      : URL_FLOW;
    // ⚠️ `active: false`: ver el comentario de arriba. La de MaKo tiene que quedar
    // adelante o Chrome duerme la de Flow.
    const nueva = await chrome.tabs.create({ url: destino, active: false });
    await esperarCarga(nueva.id);
    tabFlow = nueva;
    pasos.push('flow');
    if (!ES_UUID.test(String(guardado || ''))) avisoProyecto = true;
  }

  // ── 2. MaKo, y queda al frente ────────────────────────────────────────────
  let tabMako = null;
  try {
    const tabs = await pestanasDeMaKo();
    tabMako = tabs.find((t) => String(t.url || '').includes('/video-generator')) || tabs[0] || null;
  } catch { tabMako = null; }

  if (!tabMako) {
    tabMako = await chrome.tabs.create({ url: URL_MAKO_TAB, active: true });
    await esperarCarga(tabMako.id);
    pasos.push('mako');
  } else {
    await chrome.tabs.update(tabMako.id, { active: true }).catch(() => {});
    await chrome.windows.update(tabMako.windowId, { focused: true }).catch(() => {});
  }

  // ── 3. Y se late, para no esperar la proxima alarma ───────────────────────
  // La persona acaba de apretar un boton: que el estado tarde 15 s en cambiar le
  // ensena que la app no se entera de lo que hace.
  await ciclo().catch(() => {});

  // ⚠️ QUEDA UNA GUARDIA PUESTA. Ver `CLAVE_CUIDANDO`.
  if (tabFlow && enProyectoDeFlow(tabFlow.url)) {
    await chrome.storage.local.set({
      [CLAVE_CUIDANDO]: { tabId: tabFlow.id, url: tabFlow.url, desde: Date.now() },
    });
  }

  return { ok: true, pasos, avisoProyecto, flow: !!tabFlow, mako: !!tabMako };
}
/**
 * Recarga la pestana de MaKo que no contesto y espera a que vuelva.
 *
 * Es el remedio de `sin_enlace`, y se hace desde aca porque el popup se cierra en
 * cuanto pierde el foco: una recarga disparada alla se corta a la mitad.
 */
async function recargarMako() {
  let tabs = [];
  try { tabs = await pestanasDeMaKo(); } catch { tabs = []; }
  const t = tabs.find((x) => x.active) || tabs[0];
  if (!t) return { ok: false };
  try {
    await chrome.tabs.reload(t.id);
    await esperarCarga(t.id);
    return { ok: true };
  } catch { return { ok: false }; }
}

async function pedirEmparejar(tabId, forzar) {
  try {
    return await chrome.tabs.sendMessage(tabId, { tipo: 'EMPAREJAR', forzar: !!forzar });
  } catch {
    // Content script HUERFANO: Chrome no lo inyecta hacia atras en una pestana
    // que ya estaba abierta cuando se instalo o se actualizo la extension. Con
    // hola-mako.com en `host_permissions` esto se puede reponer, y sin reponerlo
    // el sintoma es «apreto Conectar y no pasa nada» sobre una pestana abierta.
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ['mako-puente.js'] });
      return await chrome.tabs.sendMessage(tabId, { tipo: 'EMPAREJAR', forzar: !!forzar });
    } catch { return null; }
  }
}

async function finEmparejado(r, tabCreada) {
  const ok = !!(r && r.ok);
  await chrome.storage.local.set({
    emparejando: false,
    emparejarError: ok ? '' : String((r && r.motivo) || 'error'),
    // ⚠️ CUÁNDO. Sin la fecha, un error del emparejado se queda en el storage
    // PARA SIEMPRE y el popup lo repinta cada vez que se abre: un fallo de hace
    // media hora se lee exactamente igual que uno de recién, y manda a arreglar
    // algo que capaz ya está bien. Le paso a una clienta, con un mensaje de la
    // version anterior de la extension.
    emparejarCuando: ok ? 0 : Date.now(),
    emparejarEtiqueta: (r && r.etiqueta) || '',
  });
  if (ok) {
    // Se conecto: la pestana que abri yo ya no hace falta, y el latido sale ya
    // para que el popup no tenga que esperar 15 s a decir algo verdadero.
    if (tabCreada != null) { try { await chrome.tabs.remove(tabCreada); } catch { /* la cerro alguien */ } }
    await ciclo();
  } else if (tabCreada != null) {
    // No se pudo: la pestana se ACTIVA en vez de cerrarse. Es la unica forma de
    // que la persona vea que le falta iniciar sesion — cerrarla dejaria un error
    // sin ningun lugar donde resolverlo.
    try { await chrome.tabs.update(tabCreada, { active: true }); } catch { /* ya no esta */ }
  }
  return r || { ok: false, motivo: 'error' };
}

function esperarCarga(tabId) {
  return new Promise((resolve) => {
    const reloj = setTimeout(fin, 9000);
    function alCambiar(id, info) {
      if (id !== tabId || info.status !== 'complete') return;
      fin();
    }
    function fin() {
      clearTimeout(reloj);
      chrome.tabs.onUpdated.removeListener(alCambiar);
      resolve();
    }
    chrome.tabs.onUpdated.addListener(alCambiar);
  });
}

// ── WhatsApp Web, lista para leer (25/10/2026, 0.71.0) ─────────────────────────
// Por prefijo y no con el patrón de URL de Chrome: ese patrón termina en barra-asterisco, y los tests del worker quitan los
// comentarios con una regex que, ante esa secuencia dentro de un texto, se come todo el código que sigue hasta el próximo
// cierre de comentario (rompió tres tests ajenos, 24/10/2026). La URL se ve: hay permiso del sitio.
const WA_WEB = 'https://web.whatsapp.com/';
// ⛔ QUIÉN PUEDE PEDIRLE COSAS A LA EXTENSIÓN (01/11/2026, auditoría de seguridad). El puente corre en hola-mako.com y,
// para desarrollar, en localhost. Dos agujeros: (1) una página en localhost —cualquier servidor que corra en la PC del
// cliente— podía pedir las fichas de WhatsApp o contestar el emparejado con un token suyo; (2) la ventana de lectura del
// Landing Generator (`/api/landing-generator/diagnostico/pagina`) sirve el HTML de una página AJENA en hola-mako.com, con
// el puente adentro. Ahora: localhost sólo con la extensión cargada sin empaquetar (`installType: 'development'`), y en
// hola-mako.com nunca las rutas que sirven contenido ajeno (`/api/`, `/l/`). El manifiesto las excluye también.
let instalacionDeDesarrollo = false;
try { chrome.management?.getSelf?.().then((i) => { instalacionDeDesarrollo = i?.installType === 'development'; }, () => {}); } catch { /* sin management: no es de desarrollo */ }
function esUrlDeMaKo(url) {
  // Sin `new URL`: el worker lo tiene, pero los tests cargan este bloque en un contexto sin él. El host se compara
  // EXACTO (un «hola-mako.com@otro.com» trae usuario y no pasa), y sin «//» en la regex (los tests quitan comentarios).
  const m = /^(https?):[/][/]([^/?#]+)([^?#]*)/.exec(String(url || ''));
  if (!m) return false;
  const camino = m[3] || '/';
  if (camino.startsWith('/api/') || camino.startsWith('/l/')) return false;
  const host = m[2].toLowerCase();
  if (m[1] === 'https' && host === 'hola-mako.com') return true;
  return instalacionDeDesarrollo && m[1] === 'http' && (host === 'localhost' || host.startsWith('localhost:'));
}
/** ¿Este pedido lo puede hacer quien lo manda? El popup (una página de la extensión, sin pestaña) o una pestaña de MaKo. */
function pedidoPermitido(sender) {
  if (!sender?.tab && sender?.id === chrome.runtime?.id) return true;
  return esUrlDeMaKo(sender?.url || sender?.tab?.url);
}
/** Las pestañas de la app de MaKo: sin la ventana de lectura ni las páginas que sirven HTML de terceros. */
async function pestanasDeMaKo() {
  // El patrón se arma en dos pedazos: «barra-asterisco» dentro de un texto rompe el quitador de comentarios de los tests.
  const tabs = await chrome.tabs.query({ url: 'https://hola-mako.com/' + '*' });
  return tabs.filter((t) => esUrlDeMaKo(t.url));
}

// ── «Capturar» desde «Sus páginas» de Spy (0.76.0) ─────────────────────────────────────────────
// Lo pendiente vive en `chrome.storage.session` (se borra al cerrar el navegador) y no en una variable: el worker se duerme.
async function capturasPendientes() {
  const { spyCapturas } = await chrome.storage.session.get('spyCapturas').catch(() => ({}));
  return spyCapturas && typeof spyCapturas === 'object' ? spyCapturas : {};
}
async function anotarCaptura(tabId, p) {
  const todas = await capturasPendientes();
  todas[String(tabId)] = p;
  await chrome.storage.session.set({ spyCapturas: todas });
}
/** Saca la pendiente de esa pestaña y la devuelve (null si no había). */
async function sacarCaptura(tabId) {
  const todas = await capturasPendientes();
  const p = todas[String(tabId)] || null;
  if (p) { delete todas[String(tabId)]; await chrome.storage.session.set({ spyCapturas: todas }); }
  return p;
}
/** Vuelve a la pestaña de Spy que pidió y le dice cómo terminó (`lista`: se guardó; `cerrada`: la cerraron sin capturar). */
async function volverASpy(p, como) {
  const spyTab = await chrome.tabs.get(p.spyTabId).catch(() => null);
  if (!spyTab) return;
  if (como.lista) {
    await chrome.tabs.update(spyTab.id, { active: true }).catch(() => {});
    if (spyTab.windowId != null) await chrome.windows.update(spyTab.windowId, { focused: true }).catch(() => {});
  }
  await chrome.tabs.sendMessage(spyTab.id, { tipo: 'SPY_CAPTURA_TERMINO', competidorId: p.competidorId, url: p.url, ...como }).catch(() => {});
}
// Si la persona cierra la pestaña sin capturar, la pantalla deja de esperar. (Con `?.`: los tests cargan este worker con un
// `chrome` de mentira que no tiene todos los eventos.)
chrome.tabs?.onRemoved?.addListener((tabId) => {
  void sacarCaptura(tabId).then((p) => { if (p) void volverASpy(p, { cerrada: true }); });
});

/** Cuánto se espera a que la persona escanee el QR de WhatsApp Web (0.72.3). */
const ESPERA_QR_MS = 5 * 60000;
const esPestanaDeWhatsapp = (t) => !!t && t.id != null && typeof t.url === 'string' && t.url.startsWith('https://web.whatsapp.com/');

/** Una promesa con tope: pasado `ms`, `{ tope: true }` (un mensaje a una pestaña congelada no contesta nunca). */
function conTope(promesa, ms) {
  return Promise.race([promesa, new Promise((resolve) => setTimeout(() => resolve({ tope: true }), ms))]);
}

/**
 * MIENTRAS SE ESPERA A WHATSAPP WEB, UN LATIDO a la pantalla de MaKo que pidió, cada 10 s, sin texto (no cambia lo que dice).
 * ⚠️ MEDIDO el 27/10/2026: la pantalla se rinde a los 30 s sin noticias («La extensión no contestó», SILENCIO_FICHAS_MS) y
 * un paso podía tardar más (WhatsApp Web lento, o Chrome tapado por otra ventana): cortaba una extracción sana, y el recorrido
 * seguía vivo en WhatsApp Web; la siguiente chocaba con él («ocupado») y terminaba en «0 nombres» sin decir nada. Lo que se
 * espera ya tiene su tope acá (`conTope`): el latido sólo dice que el worker sigue.
 */
const LATIDO_MS = 10000;
function conLatido(promesa, origen, id) {
  if (origen == null || !id) return promesa;
  const t = setInterval(() => { chrome.tabs.sendMessage(origen, { tipo: 'WA_FICHAS_AVANCE', id, paso: 'latido' }).catch(() => {}); }, LATIDO_MS);
  return Promise.resolve(promesa).finally(() => clearInterval(t));
}

/** ¿Está el script de las fichas en esa pestaña? Su respuesta dice además si WhatsApp Web ya guardó su base. */
async function pingWhatsapp(tabId) {
  try {
    const r = await conTope(chrome.tabs.sendMessage(tabId, { tipo: 'WA_FICHAS_PING' }), 4000);
    return r && r.ok ? r : null;
  } catch { return null; }
}

/** Espera a que una pestaña termine de cargar, con tope. */
async function cargaConTope(tabId, ms) {
  await conTope(esperarCarga(tabId), ms);
}

/** El ping, repetido hasta `ms`: en una pestaña recién abierta el script entra recién cuando la página termina de cargar. */
async function pingConEspera(tabId, ms) {
  const hasta = Date.now() + ms;
  let ping = await pingWhatsapp(tabId);
  while (!ping && Date.now() < hasta) {
    await new Promise((r) => setTimeout(r, 1500));
    ping = await pingWhatsapp(tabId);
  }
  return ping;
}

/**
 * LA PESTAÑA DE WHATSAPP WEB, LISTA PARA LEER. Lo que antes le tocaba a la persona («abrí WhatsApp Web», «recargá la
 * pestaña», «la extensión no contestó»), acá: abrirla si no hay (de fondo, para no sacarla de MaKo), despertarla si Chrome la
 * descartó, ponerle el script si es de antes de la extensión, recargarla si igual no contesta, y esperar a que cargue los
 * chats. `motivo` sólo cuando no se pudo: `sin_sesion` (WhatsApp Web abierta sin chats: falta iniciar la sesión) o
 * `sin_respuesta_wa`. No toca la interfaz de WhatsApp: abrir la página no abre ningún chat.
 */
async function pestanaDeWhatsappLista(avisar) {
  const tabs = await chrome.tabs.query({});
  let tab = tabs.find(esPestanaDeWhatsapp) || null;
  let recien = false;
  if (!tab) {
    avisar('abriendo', 'Abriendo WhatsApp Web en otra pestaña…');
    tab = await chrome.tabs.create({ url: WA_WEB, active: false });
    await cargaConTope(tab.id, 45000);
    recien = true;
  } else if (tab.discarded) {
    avisar('abriendo', 'Despertando la pestaña de WhatsApp Web…');
    await chrome.tabs.reload(tab.id);
    await cargaConTope(tab.id, 45000);
    recien = true;
  }
  let ping = recien ? await pingConEspera(tab.id, 30000) : await pingWhatsapp(tab.id);
  if (!ping) {
    // Abierta ANTES de instalar o actualizar la extensión: no tiene el script. Se le pone sin recargarla.
    try { await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['wa-fichas-reglas.js', 'wa-fichas.js', 'wa-recorrer.js'] }); } catch { /* sigue abajo */ }
    ping = await pingWhatsapp(tab.id);
  } else if (ping.recorre === false) {
    // Con el script de la 0.71 (sin el recorrido a la vista): se le suma, sin recargar.
    try { await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['wa-recorrer.js'] }); } catch { /* sin recorrido: sólo la base */ }
  }
  if (!ping) {
    avisar('abriendo', 'Recargando WhatsApp Web…');
    try { await chrome.tabs.reload(tab.id); await cargaConTope(tab.id, 45000); } catch { /* sigue abajo */ }
    ping = await pingConEspera(tab.id, 30000);
  }
  if (!ping) return { tab, motivo: 'sin_respuesta_wa' };
  // Recién abierta, WhatsApp Web todavía no guardó su base: se espera un minuto, contándolo.
  // ⚠️ Y SI PIDE EL QR, SE ESPERA UNOS MINUTOS (0.72.3, Martín 26/10: «si el usuario no escaneó el QR, que la extensión le diga
  // y se quede esperando unos minutos... Aprovechá lo que tenemos»: como el desplegable con Google Flow). La pestaña va al
  // frente (ahí está el código) y cada vuelta lo dice; escaneado, sigue sola. La 0.71 no miraba la pantalla: con el QR
  // esperaba un minuto y decía `sin_sesion`.
  const lista = (p) => (p.sesion ? p.sesion === 'lista' && p.base !== false : p.base !== false);
  let hasta = Date.now() + 60000;
  let enQr = false;
  while (!lista(ping) && Date.now() < hasta) {
    if (ping.sesion === 'qr') {
      if (!enQr) { enQr = true; hasta = Date.now() + ESPERA_QR_MS; await alFrente(tab); }
      avisar('qr', 'Escanea el QR en WhatsApp Web: te espero unos minutos…');
    } else {
      avisar('cargando', 'Esperando que WhatsApp Web cargue tus chats…');
    }
    await new Promise((r) => setTimeout(r, 2500));
    ping = (await pingWhatsapp(tab.id)) || ping;
  }
  if (!lista(ping)) return { tab, motivo: 'sin_sesion' };
  return { tab, motivo: null };
}

// ── «Extraer» a la vista y el REGISTRO de las extracciones (26/10/2026, 0.72.0) ─────────────
// Martín: «Quiero que el scraper, con la extensión me redirija a la tab de whatsapp y se vea que está interactuando o
// buscando, que se vea que entra al grupo y ve los contactos. Y que se despliegue la extensión y que allí se vea la animación
// de la extracción... que se guarde el registro de las extracciones». Un pedido con `visible` pone al frente la pestaña de
// WhatsApp Web que YA está (⚠️ nunca una segunda: le cierra la sesión; sólo se abre una si no hay ninguna), abre el
// desplegable y recorre el grupo (wa-recorrer.js). Cada paso queda en `extracciones` (storage), que el desplegable dibuja.
const TOPE_REGISTRO = 30;
/** Lo que se dice si WhatsApp Web corre oculta (Chrome tapado): la pantalla de MaKo y el desplegable. */
const TEXTO_OCULTA = 'Chrome quedó tapado por otra ventana y así va lento: tráelo al frente.';
/** Las extracciones en curso: de qué pestaña de MaKo vino cada una, y en qué pestaña de WhatsApp corre. */
const extraccionesVivas = new Map();
let colaRegistro = Promise.resolve();
/**
 * Anota en el registro. En fila: dos avances seguidos no se pisan. Sólo el pedido que EMPIEZA crea su fila (`crear`): un aviso
 * con un id que no está (de antes de recargarse la extensión, o de otra pestaña) no inventa una extracción.
 */
function anotarExtraccion(id, cambios, crear = false) {
  if (!id) return colaRegistro;
  colaRegistro = colaRegistro.then(async () => {
    const { extracciones } = await chrome.storage.local.get('extracciones');
    const lista = Array.isArray(extracciones) ? extracciones.filter((e) => e && typeof e.id === 'string') : [];
    const i = lista.findIndex((e) => e.id === id);
    const ahora = Date.now();
    const limpio = Object.fromEntries(Object.entries(cambios || {}).filter(([, v]) => v !== undefined));
    // ⚠️ EL TIEMPO DE CADA ETAPA, MEDIDO EN CADA CORRIDA (27/10/2026; Leandro: «se tarda mucho», y con Aaron se trabó): en qué
    // segundo empezó cada fase (`tiempos`) y cuánto tardó todo (`duracion`). Así un «tarda» se lee en el registro de quien lo
    // dijo, no se adivina.
    const conTiempos = (e) => {
      const seg = Math.round((ahora - (e.cuando || ahora)) / 1000);
      const out = { ...e };
      if (typeof limpio.fase === 'string' && limpio.fase && (out.tiempos || {})[limpio.fase] == null) out.tiempos = { ...(out.tiempos || {}), [limpio.fase]: seg };
      if (typeof limpio.estado === 'string' && limpio.estado !== 'corriendo' && out.duracion == null) out.duracion = seg;
      return out;
    };
    if (i < 0) { if (!crear) return; lista.unshift(conTiempos({ id, cuando: ahora, estado: 'corriendo', ...limpio, actualizado: ahora })); }
    else lista[i] = conTiempos({ ...lista[i], ...limpio, actualizado: ahora });
    await chrome.storage.local.set({ extracciones: lista.slice(0, TOPE_REGISTRO) });
  }).catch(() => {});
  return colaRegistro;
}

/** La pestaña al frente, y su ventana. */
async function alFrente(tab) {
  try { await chrome.tabs.update(tab.id, { active: true }); } catch { /* nada */ }
  try { if (tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true }); } catch { /* nada */ }
}

/**
 * El desplegable de la extensión, abierto en esa ventana (Chrome 127+). Si no se puede, el cartel de WhatsApp Web cuenta igual.
 * ⚠️ Chrome lo rechaza si la ventana todavía no tiene el foco, y `windows.update({ focused })` lo da DESPUÉS: se reintenta
 * unas veces, y la última sin ventana (la activa). Devuelve `true` o el porqué (va al registro: sin eso no se sabe por qué
 * no se abrió).
 */
async function abrirDesplegable(windowId) {
  if (typeof chrome.action?.openPopup !== 'function') return 'sin_openPopup';
  let porque = '';
  for (let i = 0; i < 4; i++) {
    try {
      await chrome.action.openPopup(windowId != null && i < 3 ? { windowId } : {});
      return true;
    } catch (e) {
      porque = String(e?.message || e).slice(0, 160);
      await new Promise((r) => setTimeout(r, 350));
    }
  }
  return porque || 'no_abrio';
}

/** Terminada a la vista: unos segundos para ver el final y de vuelta a MaKo, si la persona sigue en WhatsApp Web. */
// ⚠️ A LA PESTAÑA EXACTA DESDE LA QUE SE TOCÓ «EXTRAER» (Martín, 26/10/2026: «tiene que identificar cuál tab es, porque
// puede tener varios CRM abiertos u otras tab de MaKo. Por eso, que identifique dónde fue que le dio click»). `viva.origen`
// es la pestaña que MANDÓ el pedido (el `sender.tab` del mensaje), nunca «la primera de hola-mako.com». Al terminar, y
// también si se corta. Si esa pestaña ya no está, no se elige otra: queda dicho en el registro (`volver: 'sin_pestana'`) y el
// desplegable lo muestra.
// ⚠️ SIN `viva` TAMBIÉN (30/10/2026, «aun no veo... que cuando termina de scrapear debe regresar a la app de mako»). `extraccionesVivas`
// vive en la memoria del service worker, y Chrome lo mata después de 30 s sin eventos: guardar los nombres sin una pestaña que lo
// despierte alcanza. Al final llegaba `viva` undefined y `return`, sin rastro. El aviso final lo manda LA PESTAÑA de la extracción:
// `sender.tab` ES la de origen. La de WhatsApp Web se busca si no se recuerda.
function volverAMako(viva, id) {
  if (!viva || viva.origen == null) return;
  setTimeout(async () => {
    try {
      const waTab = viva.waTab ?? (await chrome.tabs.query({})).find(esPestanaDeWhatsapp)?.id;
      if (waTab == null) return;
      const wa = await chrome.tabs.get(waTab).catch(() => null);
      // Si la persona ya se fue de WhatsApp Web a otra cosa, no se la saca de ahí.
      if (wa && !wa.active) return;
      const mako = await chrome.tabs.get(viva.origen).catch(() => null);
      if (!mako) { if (id) void anotarExtraccion(id, { volver: 'sin_pestana' }); return; }
      await alFrente(mako);
    } catch { /* nada */ }
  }, 4000);
}

/** Abre Flow, o enfoca la pestana que ya esta. */
async function abrirFlow() {
  try {
    const t = await pestanaDeFlow();
    await chrome.tabs.update(t.id, { active: true });
    await chrome.windows.update(t.windowId, { focused: true });
    return { ok: true, creada: false };
  } catch {
    await chrome.tabs.create({ url: await destinoDeFlow(), active: true });
    return { ok: true, creada: true };
  }
}

/**
 * Recarga la pestana de Flow.
 *
 * Lo hace la EXTENSION, no la persona. Es la diferencia concreta entre el panel
 * viejo y esto: la web solo podia PEDIR «recargala (F5)»; el popup ve la
 * pestana, la recarga, y despues late para que el estado se actualice solo.
 */
async function recargarFlow() {
  try {
    const t = await pestanaDeFlow();
    await chrome.tabs.reload(t.id);
    return { ok: true };
  } catch {
    await chrome.tabs.create({ url: await destinoDeFlow(), active: true });
    return { ok: true, creada: true };
  }
}

/**
 * El saldo, LOCAL: sin dar la vuelta por la cola de MaKo.
 *
 * ⚠️ El pedido a `/v1/credits` sale de la PAGINA de Flow y nunca del service
 * worker: desde aca viaja con `Origin: chrome-extension://` y sin las cookies del
 * sitio, y Google contesta su pagina de bloqueo. Esta medido y es la razon de que
 * el paso 4 siga necesitando la pestana abierta.
 *
 * NO escribe nada en el server: `saldoAction` sigue siendo el unico escritor del
 * saldo guardado, que es lo que alimenta el costo por clip.
 */
/**
 * Los creditos, leidos de la respuesta que el Flow NUEVO ya trajo.
 *
 * ⚠️ NUNCA SE MOVIERON DE LUGAR: estan en el menu de la cuenta, arriba a la derecha,
 * como siempre. Lo que cambio es POR DONDE los pide la app.
 *
 * Medido el 05/09/2026 con el menu abierto y confirmado en pantalla: el `rpcids=nzlxg`
 * contesta, textual,
 *
 *   ["wrb.fr","nzlxg","[569,1,2,2,null,569]",null,null,null,"generic"]
 *
 * y 569 es exactamente el numero que muestra el menu. El primer elemento es el saldo.
 *
 * ⚠️ Y ESTO NO PIDE NADA: el espejo ya guarda la respuesta de cada `batchexecute`, asi
 * que leer los creditos deja de costar una llamada a Google. Es lo que el propio
 * espejo dice que existe para hacer —«con esto una consulta de creditos no necesita un
 * pedido nuestro»— y hasta hoy no se usaba en este camino.
 *
 * ⚠️ COMO SE ME PASO, que es lo que vale escribir: en la primera medicion busque la
 * palabra `credit` en las respuestas y no aparecia, asi que reporte que los creditos
 * ya no existian. El numero 569 ESTABA en esa misma captura, dos veces. Un predicado
 * mal elegido no devuelve «no se»: devuelve «no», que es indistinguible de un hecho.
 */
function creditosDeBoq(texto) {
  try {
    const m = /\["wrb\.fr","nzlxg","((?:[^"\\]|\\.)*)"/.exec(String(texto || ''));
    if (!m) return null;
    // Doble parseo a proposito: el tercer campo es un JSON guardado DENTRO de un
    // string JSON, asi que primero se desescapa el string y despues se parsea.
    const dentro = JSON.parse(JSON.parse('"' + m[1] + '"'));
    const n = Array.isArray(dentro) ? Number(dentro[0]) : NaN;
    return Number.isFinite(n) && n >= 0 ? n : null;
  } catch { return null; }
}

/**
 * El saldo del Flow nuevo, sin pedirle nada a Google.
 *
 * Devuelve `null` si todavia no se vio pasar un `nzlxg` — que es un estado distinto de
 * «no hay creditos» y por eso no se confunde con cero.
 */
async function saldoDeBoq() {
  try {
    const tab = await pestanaDeFlow();
    if (!esFlowNuevo(tab.url)) return null;
    if ((await asegurarContentScript(tab.id)) === 'mudo') return null;
    const r = await chrome.tabs.sendMessage(tab.id, { tipo: 'VER_RESPUESTAS' });
    const texto = r && r.respuestas && r.respuestas['boq:nzlxg'];
    const creditos = creditosDeBoq(texto);
    return creditos == null ? null : { creditos, cuando: Date.now(), tier: '' };
  } catch { return null; }
}
async function saldoLocal(forzar) {
  const { saldoLocal: prev } = await chrome.storage.local.get('saldoLocal');
  // Piso de ritmo: abrir el popup no puede ser un pedido a Google cada vez.
  if (!forzar && prev && Date.now() - prev.cuando < 60000) return prev;

  // ⚠️ EL FLOW NUEVO PRIMERO, Y SIN PEDIR NADA. El camino de abajo llama a
  // `/v1/credits` con el bearer, que en flow.google.com no existe: ahi falla
  // SIEMPRE. Este lee el numero de una respuesta que la app ya trajo.
  const boq = await saldoDeBoq();
  if (boq) {
    await chrome.storage.local.set({ saldoLocal: boq });
    return boq;
  }

  try {
    const tab = await pestanaDeFlow();
    if ((await asegurarContentScript(tab.id)) === 'mudo') {
      return { error: 'MUDO', cuando: Date.now() };
    }
    const r = await chrome.tabs.sendMessage(tab.id, {
      tipo: 'HACER_FETCH',
      // ⚠️ `credits`, NO `creditos`. La clase de una plantilla es el ULTIMO TRAMO
      // DEL PATH (`claseDePath`), no el nombre que le damos en `ENDPOINTS`. Con el
      // nombre nuestro no hay respaldo que buscar, el espejo no puede armar el
      // pedido, y el popup contesta «no pude leer tus creditos» con Flow abierto y
      // andando — un error que culpa a Google por un typo nuestro.
      clase: 'credits',
      path: '/v1/credits',
      cuerpo: null,
      // ⚠️ `parches: null` EXPLICITO: `content.js` lo reenvia e `injected.js` lo
      // consulta para decidir si puede usar la respuesta cacheada. Omitirlo lo
      // deja `undefined`, que hoy se comporta igual y no tiene por que seguir
      // haciendolo.
      parches: null,
      soloLectura: true,
      bearer,
      respaldo: await respaldoDe('credits'),
    });
    // ⚠️ `r.texto`, NO `r.resultado`. Ese campo NO EXISTE en ningun lado de la
    // extension: `injected.js` contesta `{ status, texto, metodo, urlUsada }` o
    // `{ error }` (injected.js:795). Leyendo un campo que nadie escribe, `d` era
    // `undefined` SIEMPRE y este boton contestaba «No pude leer tus creditos» en
    // el 100% de los casos, con Flow abierto y andando.
    //
    // Es un bug de CONTRATO: dos lados de un mensaje que no se pusieron de
    // acuerdo sobre el nombre de un campo, sin que nada falle ruidoso. Y no
    // hacia falta inventar nada — el otro consumidor del mismo mensaje, treinta
    // lineas mas arriba (`ejecutar`), ya lo hacia bien: `String(r.texto || '')`,
    // `JSON.parse`, y mirar el `status`.
    if (!r || r.error) return { error: String((r && r.error) || 'SIN_RESPUESTA'), cuando: Date.now() };

    // ⚠️ Y EL STATUS SE MIRA. Un 200 con la pagina de bloqueo de Google adentro
    // parsea como HTML y cae al `catch` de abajo; un 401 o un 403 traen JSON
    // valido y sin `credits`, asi que sin esto se leerian como «cero creditos».
    // Cero y «no me dejaron preguntar» no son lo mismo.
    if (!(r.status >= 200 && r.status < 300)) {
      return { error: `HTTP_${r.status}`, cuando: Date.now() };
    }

    let d = null;
    try { d = r.texto ? JSON.parse(r.texto) : null; } catch { /* no era JSON: se dice abajo */ }
    // Google contesta HTML cuando bloquea. Que no sea JSON ES el dato.
    if (!d || typeof d !== 'object') return { error: 'RESPUESTA_NO_JSON', cuando: Date.now() };
    // ⚠️ SIN EL NUMERO NO HAY SALDO. `creditos: null` se guardaba igual, y el
    // popup lo pinta solo si es `number` — asi que caia en «Todo listo · Ver mis
    // creditos», el mismo boton, otra vez. Un dato ausente que se guarda como
    // valido es un bucle con cara de pantalla.
    if (typeof d.credits !== 'number') return { error: 'SIN_CREDITOS_EN_LA_RESPUESTA', cuando: Date.now() };

    const saldo = {
      creditos: d.credits,
      // En POSITIVO: se afirma «gratuito» solo con la marca explicita de Google.
      // Es la misma regla que `leerSaldo` del server, y dice lo mismo o calla.
      gratuito: d.userPaygateTier === 'PAYGATE_TIER_NOT_PAID' || d.sku === 'WS_FREEMIUM',
      sku: String(d.sku || ''),
      cuando: Date.now(),
    };
    await chrome.storage.local.set({ saldoLocal: saldo });
    return saldo;
  } catch (e) {
    return { error: String((e && e.message) || e), cuando: Date.now() };
  }
}

// El service worker MV3 se duerme: el alarm es lo que lo despierta. Con
// setInterval solo, el puente deja de existir a los 30 segundos sin que nada
// avise.
//
// ⚠️ Y LA ALARMA NO ALCANZA CON CREARLA ACA ARRIBA. Esta linea corre cuando el
// service worker ARRANCA, y despues de una actualizacion el worker se termina y
// NO vuelve a arrancar hasta que llegue un evento. Si la actualizacion se llevo
// la alarma —y esa es la unica que despertaba al worker—, no queda ningun evento
// que pueda arrancarlo: el puente se apaga PARA SIEMPRE y nada lo dice.
//
// Medido en produccion el 01/09/2026: el ultimo latido de una clienta reporto la
// version 0.37.1 y su popup corria la 0.37.3. Desde la actualizacion no volvio a
// latir ni una vez. Su trabajo quedo `pendiente` con `intentos=0` durante horas,
// y la pantalla mostrando un clip que se generaba eternamente.
//
// `onInstalled` (que dispara con reason 'update') y `onStartup` SI despiertan al
// worker. Son los dos unicos momentos que pueden reponer la alarma, y por eso
// tienen que estar los dos: `onStartup` cubre reabrir Chrome, `onInstalled`
// cubre instalar y actualizar.
const PERIODO_MIN = 0.25;

async function asegurarAlarma() {
  try {
    const a = await chrome.alarms.get('ciclo');
    if (!a) await chrome.alarms.create('ciclo', { periodInMinutes: PERIODO_MIN });
  } catch {
    // `get` puede fallar si el worker se esta apagando: crearla igual es barato
    // y `create` sobre una que ya existe la reemplaza sin duplicarla.
    try { await chrome.alarms.create('ciclo', { periodInMinutes: PERIODO_MIN }); } catch { /* no hay mas que hacer */ }
  }
  // Y SE LATE YA. Sin esto, despues de una actualizacion el puente se queda
  // callado hasta el primer disparo —y para MaKo, un puente que no late hace un
  // minuto es un puente muerto: el gate no deja filmar.
  void ciclo();
}

/**
 * EL PUENTE EN LAS PESTAÑAS DE MaKo QUE YA ESTABAN ABIERTAS (25/10/2026, 0.71.0). Chrome no mete los content scripts en una
 * pestaña abierta ANTES de instalar o actualizar la extensión: la de MaKo no se enteraba de que la extensión estaba («Instala la
 * extensión» con la extensión recién instalada) hasta recargarla, y Martín pidió que al volver de instalarla «empiece sola».
 * Se repone sólo donde no corre (`__makoPuenteCargado`, lo deja mako-puente.js), para no correrlo dos veces en el mismo mundo.
 */
async function reponerPuenteEnMako() {
  let tabs = [];
  try { tabs = await chrome.tabs.query({}); } catch { return; }
  for (const t of tabs) {
    if (t.id == null || typeof t.url !== 'string' || !t.url.startsWith(`${MAKO}/`)) continue;
    try {
      const [ya] = await chrome.scripting.executeScript({ target: { tabId: t.id }, func: () => globalThis.__makoPuenteCargado === true });
      if (ya && ya.result) continue;
      await chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['mako-puente.js'] });
    } catch { /* una pestaña descartada o sin permiso: la repone su próxima carga */ }
  }
}

chrome.runtime.onInstalled.addListener(() => { void asegurarAlarma(); void reponerPuenteEnMako(); });
chrome.runtime.onStartup.addListener(() => { void asegurarAlarma(); });
void asegurarAlarma();
// La carpeta puede traer una version nueva (`alDiaConSuCarpeta`): se mira al arrancar y despues de cada latido.
void alDiaConSuCarpeta();

chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'ciclo') void ciclo().then(() => alDiaConSuCarpeta()); });

// ⚠️ Y NO SE ESPERA AL PROXIMO LATIDO PARA CONTAR LA BUENA NOTICIA.
//
// Abrir Flow es el paso que la persona acaba de hacer, mirando la pantalla. Si el
// aviso de MaKo tarda en irse, lo que aprende es que la app no se entera de lo
// que hace — y encima el reloj del navegador y el de la pagina son dos esperas
// que SE SUMAN: hasta 15 s hasta que la extension reporta, mas hasta 15 s hasta
// que la pagina pregunta. Medio minuto mirando un cartel que ya no es cierto.
//
// Con esto el lado de la extension pasa a ser inmediato: en cuanto una pestana de
// Flow termina de cargar, se late. `complete` y no `loading` porque antes de eso
// no hay content script al que preguntarle nada.
/**
 * Si la pestana cuidada se va del proyecto, se la devuelve.
 *
 * ⚠️ UNA SOLA VEZ POR SALIDA, y por eso se compara contra la URL guardada: sin eso,
 * la propia navegacion que hacemos dispararia el listener otra vez y quedaria un
 * lazo que la persona no puede cortar ni cerrando la pestana.
 *
 * Y se suelta la guardia si la persona insiste: `veces` cuenta los rebotes, y al
 * segundo se deja de pelear. Alguien que vuelve a irse despues de que lo trajimos
 * de vuelta no se equivoco — quiere estar en otro lado, y el producto no esta para
 * discutirle.
 */
chrome.tabs.onUpdated.addListener((id, info) => {
  void (async () => {
    try {
      if (!info.url) return;
      const g = (await chrome.storage.local.get(CLAVE_CUIDANDO))[CLAVE_CUIDANDO];
      if (!g || g.tabId !== id) return;
      if (Date.now() - Number(g.desde || 0) > CUIDADO_MS) return soltarGuardia();
      // Sigue en su proyecto: nada que hacer.
      if (enProyectoDeFlow(info.url)) return;
      // Se fue de Flow del todo (cerro, o navego a otro sitio): no se lo persigue
      // fuera de Flow — eso ya no es «tocar algo de Flow», es irse.
      if (!esUrlDeFlow(info.url)) return soltarGuardia();
      if (Number(g.veces || 0) >= 1) return soltarGuardia();
      await chrome.storage.local.set({
        [CLAVE_CUIDANDO]: { ...g, veces: Number(g.veces || 0) + 1, avisado: true },
      });
      await chrome.tabs.update(id, { url: g.url }).catch(() => {});
    } catch { /* la guardia nunca puede romper la navegacion */ }
  })();
});

chrome.tabs.onUpdated.addListener((_id, info, tab) => {
  if (info.status !== 'complete') return;
  // ⚠️ EL DECIMO SITIO QUE CLAVABA EL DOMINIO, y el mas silencioso de todos: no
  // rompe nada, solo hace que la buena noticia tarde hasta 30 s en llegar. Sale de
  // `PATRONES_FLOW` para que no vuelva a quedarse atras.
  if (!esUrlDeFlow(tab.url)) return;
  void ciclo();
});

chrome.runtime.onMessage.addListener((msg, _s, responder) => {
  // ⚠️ MAKO AVISA QUE HAY TRABAJO, EN VEZ DE QUE ESTE LADO LO DESCUBRA TARDE.
  //
  // El primer trabajo de una tanda esperaba a la proxima alarma —hasta 15 s, y
  // en una extension empaquetada Chrome puede llevar el minimo a 30— con la
  // persona mirando el loader inmediatamente despues de apretar «Generar». Nada
  // pasaba en ese rato: el trabajo ya estaba encolado y este lado no lo sabia.
  //
  // Viaja por el content script de hola-mako.com, igual que el emparejado, y por
  // la misma razon: `externally_connectable` necesita el ID de la extension, que
  // cambia al publicarse en la tienda.
  //
  // No abre ninguna puerta: `ciclo()` hace exactamente lo que ya hacia cada 15 s
  // —le pregunta al servidor si hay algo suyo, con el token de este navegador—.
  // Lo unico que cambia es CUANDO. Y `corriendo` lo hace idempotente: un aviso
  // que llega con un ciclo en curso no lo duplica.
  if (msg?.tipo === 'DESPERTAR') {
    void ciclo();
    responder?.({ ok: true });
    return false;
  }

  // LAS FICHAS DE WHATSAPP WEB (24/10/2026, wa-fichas.js). MaKo, desde la pestaña de hola-mako.com, pide lo que el WhatsApp Web
  // de esta persona ya guardó sobre los teléfonos de sus leads; esto lo lleva a la pestaña de WhatsApp Web. La pestaña sólo
  // LEE su base: no toca la interfaz ni la red.
  // ⚠️ DESDE LA 0.71.0 (25/10/2026), Martín: «La extensión no contestó... no hay ninguna acción que el usuario vea para saber
  // que está corriendo bien». Ahora el worker resuelve lo que antes era un error para la persona: si no hay WhatsApp Web lo
  // ABRE (en otra pestaña), si la pestaña está dormida la despierta, si no tiene el script se lo pone, y espera a que cargue los
  // chats; y le cuenta cada paso a la pestaña de MaKo que pidió (`WA_FICHAS_AVANCE`, con el mismo `id`).
  // La pantalla de MaKo vio una extension vieja: si la carpeta ya trae la nueva, recargarse ahora y no al proximo latido.
  if (msg?.tipo === 'REVISAR_CARPETA') {
    void alDiaConSuCarpeta().then(() => responder({ ok: true }));
    return true;
  }

  if (msg?.tipo === 'WA_FICHAS_PEDIDO') {
    if (!pedidoPermitido(_s)) { responder({ ok: false, error: 'origen' }); return false; }
    const origen = _s?.tab?.id;
    const pedidoId = typeof msg.id === 'string' ? msg.id : '';
    // «Extraer» (0.72.0): a la vista, con el desplegable y su registro. Sin `visible` (la 0.71), sólo se lee la base.
    const visible = msg.visible === true && !!pedidoId;
    const grupos = Array.isArray(msg.grupos) ? msg.grupos.filter((g) => typeof g === 'string').slice(0, 20) : [];
    const avisar = (paso, texto, datos) => {
      if (visible) void anotarExtraccion(pedidoId, { fase: paso, ...(texto ? { texto } : {}), ...(datos || {}) });
      if (origen == null) return;
      chrome.tabs.sendMessage(origen, { tipo: 'WA_FICHAS_AVANCE', id: pedidoId, paso, texto }).catch(() => {});
    };
    fichasEnVuelo++;
    void (async () => {
      const viva = { origen, waTab: null, parado: false };
      if (visible) {
        extraccionesVivas.set(pedidoId, viva);
        await anotarExtraccion(pedidoId, {
          titulo: typeof msg.titulo === 'string' ? msg.titulo.slice(0, 160) : grupos[0] || 'Tus contactos', grupos: grupos.slice(0, 5),
          // La pestaña desde la que se tocó «Extraer» (el desplegable vuelve a ésa con «Ver en MaKo»).
          origenTab: origen ?? null,
          total: Array.isArray(msg.pedidos) ? msg.pedidos.length : 0, fase: 'abriendo', estado: 'corriendo',
        }, true);
        await chrome.storage.local.set({ popupVista: { pantalla: 'extraccion', id: pedidoId } }).catch(() => {});
      }
      try {
        const lista = await conLatido(pestanaDeWhatsappLista(avisar), origen, pedidoId);
        if (lista.motivo) {
          if (visible) {
            void anotarExtraccion(pedidoId, { estado: 'error', fase: 'error', motivo: lista.motivo });
            extraccionesVivas.delete(pedidoId);
            volverAMako(viva, pedidoId);
            if (lista.motivo === 'sin_sesion' && lista.tab) await alFrente(lista.tab);
          }
          responder({ ok: false, motivo: lista.motivo });
          return;
        }
        // A LA VISTA: la pestaña que ya está, al frente; el desplegable, abierto; y el grupo, recorrido.
        const vistas = [];
        let desplegable = null;
        let ocupado = false;
        if (visible && grupos.length) {
          viva.waTab = lista.tab.id;
          await alFrente(lista.tab);
          desplegable = await abrirDesplegable(lista.tab.windowId);
          void anotarExtraccion(pedidoId, { desplegable: desplegable === true ? 'abierto' : desplegable });
          for (const g of grupos.slice(0, 3)) {
            if (viva.parado || viva.cerrada) break;
            const r = await conLatido(conTope(chrome.tabs.sendMessage(lista.tab.id, { tipo: 'WA_RECORRER', id: pedidoId, grupo: g }), 300000).catch(() => null), origen, pedidoId);
            // Otro recorrido sigue en esa pestaña: se dice, no se sigue como si nada (antes: «0 nombres», sin recorrido ni perfiles).
            if (r && r.motivo === 'ocupado') { ocupado = true; break; }
            // Pasado su tope, que no quede andando: chocaría con el próximo.
            if (r && r.tope) chrome.tabs.sendMessage(lista.tab.id, { tipo: 'WA_RECORRER_PARAR', id: pedidoId }).catch(() => {});
            if (r && Array.isArray(r.filas)) vistas.push(...r.filas.slice(0, 5000));
            if (r && r.motivo === 'no_encontrado') void anotarExtraccion(pedidoId, { noEncontrado: g });
          }
        }
        // La pantalla de MaKo ya la dio por terminada (se rindió o la paró): ni se sigue ni se pisa su registro.
        if (viva.cerrada) { responder({ ok: false, motivo: 'parado' }); return; }
        if (ocupado) {
          void anotarExtraccion(pedidoId, { estado: 'error', fase: 'error', motivo: 'ocupado' });
          extraccionesVivas.delete(pedidoId);
          volverAMako(viva, pedidoId);
          responder({ ok: false, motivo: 'ocupado' });
          return;
        }
        if (viva.parado) {
          void anotarExtraccion(pedidoId, { estado: 'parado', fase: 'parado' });
          extraccionesVivas.delete(pedidoId);
          volverAMako(viva, pedidoId);
          responder({ ok: false, motivo: 'parado' });
          return;
        }
        avisar('leyendo', grupos.length === 1 ? `Buscando el grupo «${grupos[0]}» en tu WhatsApp Web…` : grupos.length > 1 ? `Buscando ${grupos.length} grupos en tu WhatsApp Web…` : 'Leyendo tu WhatsApp Web…');
        const r = await conLatido(conTope(chrome.tabs.sendMessage(lista.tab.id, {
          tipo: 'WA_FICHAS',
          telefonos: Array.isArray(msg.telefonos) ? msg.telefonos : [],
          pedidos: Array.isArray(msg.pedidos) ? msg.pedidos : undefined,
          grupos,
          vistas,
        }), 90000), origen, pedidoId);
        if (r && r.tope) {
          if (visible) { void anotarExtraccion(pedidoId, { estado: 'error', fase: 'error', motivo: 'sin_respuesta_wa' }); extraccionesVivas.delete(pedidoId); volverAMako(viva, pedidoId); }
          responder({ ok: false, motivo: 'sin_respuesta_wa' });
          return;
        }
        if (visible && r && r.ok) void anotarExtraccion(pedidoId, { fase: 'leyendo', conFicha: Array.isArray(r.fichas) ? r.fichas.length : 0 });
        // Si el desplegable se abrió (o por qué no), también a la pantalla: es lo primero que hay que saber si «no se ve».
        responder(r ? (visible ? { ...r, desplegable: desplegable === true ? 'abierto' : desplegable } : r) : { ok: false, motivo: 'sin_respuesta' });
      } catch (e) {
        if (visible) { void anotarExtraccion(pedidoId, { estado: 'error', fase: 'error', motivo: 'recargar_whatsapp_web' }); extraccionesVivas.delete(pedidoId); volverAMako(viva, pedidoId); }
        responder({ ok: false, motivo: 'recargar_whatsapp_web', error: String(e?.message || e) });
      } finally { fichasEnVuelo = Math.max(0, fichasEnVuelo - 1); }
    })();
    return true;
  }

  // LOS PERFILES, DE A TANDAS (0.73.2). Martín: «podría entrar a cada perfil y fijarse si tiene links, redes sociales, email».
  // ⚠️ MEDIDO en vivo con la 0.73.0/0.73.1 (26/10): 60 perfiles en UN pedido son más de 5 minutos, y Chrome MATA el service
  // worker de una extensión cuando un pedido pasa de 5 minutos: se perdían el avance y la respuesta, y la pantalla decía «La
  // extensión no contestó». Ahora la pantalla pide los perfiles de a tandas (`perfilesEnTandas`, lib/wa-fichas-cliente.ts:
  // 12 por pedido, ~1 minuto), con el MISMO id de la extracción, y cada tanda es un pedido corto.
  if (msg?.tipo === 'WA_PERFILES_PEDIDO') {
    if (!pedidoPermitido(_s)) { responder({ ok: false, error: 'origen' }); return false; }
    const origen = _s?.tab?.id;
    const id = typeof msg.id === 'string' ? msg.id : '';
    const grupo = typeof msg.grupo === 'string' ? msg.grupo.slice(0, 120) : '';
    const candidatos = Array.isArray(msg.candidatos) ? msg.candidatos.filter((c) => c && typeof c.telefono === 'string').slice(0, 20) : [];
    const n = (x) => (typeof x === 'number' && Number.isFinite(x) ? x : 0);
    fichasEnVuelo++;
    void (async () => {
      try {
        let viva = extraccionesVivas.get(id);
        if (!viva) { viva = { origen, waTab: null, parado: false }; extraccionesVivas.set(id, viva); }
        if (viva.parado) { responder({ ok: false, motivo: 'parado' }); return; }
        if (!id || !grupo || !candidatos.length) { responder({ ok: true, perfiles: [], diag: null }); return; }
        const lista = await conLatido(pestanaDeWhatsappLista(() => {}), origen, id);
        if (lista.motivo) { responder({ ok: false, motivo: lista.motivo }); return; }
        viva.waTab = lista.tab.id;
        if (n(msg.desde) === 0) void anotarExtraccion(id, { fase: 'perfiles', perfilesTotal: n(msg.total), perfilesHechos: 0 });
        const r = await conLatido(conTope(chrome.tabs.sendMessage(lista.tab.id, {
          tipo: 'WA_PERFILES', id, grupo, candidatos, tope: candidatos.length, desde: n(msg.desde), total: n(msg.total),
        }), 4 * 60000).catch(() => null), origen, id);
        responder(r && !r.tope ? r : { ok: false, motivo: 'sin_respuesta_wa' });
      } catch (e) {
        responder({ ok: false, motivo: 'error', error: String(e?.message || e) });
      } finally { fichasEnVuelo = Math.max(0, fichasEnVuelo - 1); }
    })();
    return true;
  }

  // Cada paso del recorrido (wa-recorrer.js): al registro, y a la pestaña de MaKo que pidió (su espera vive de estos avisos).
  if (msg?.tipo === 'WA_RECORRER_AVANCE') {
    const id = typeof msg.id === 'string' ? msg.id : '';
    const viva = extraccionesVivas.get(id);
    if (!viva) return false;
    const n = (x) => (typeof x === 'number' && Number.isFinite(x) ? x : undefined);
    // Si WhatsApp Web corre OCULTA (Chrome tapado), se anota y se dice: es por qué se arrastra, y se arregla trayendo Chrome.
    const oculta = msg.oculta === true;
    if (msg.paso === 'perfiles') void anotarExtraccion(id, { fase: 'perfiles', perfilesHechos: n(msg.hechos), perfilesTotal: n(msg.total), ahora: typeof msg.texto === 'string' ? msg.texto.slice(0, 160) : undefined, oculta });
    else void anotarExtraccion(id, { fase: String(msg.paso || ''), miembros: n(msg.total), vistos: n(msg.vistos), conNombre: n(msg.conNombre), oculta });
    if (oculta) void anotarExtraccion(id, { vecesOculta: (viva.vecesOculta = (viva.vecesOculta || 0) + 1) });
    if (viva.origen != null) {
      const texto = oculta ? TEXTO_OCULTA
        : msg.paso === 'recorriendo' ? 'Leyendo los miembros del grupo…' : msg.paso === 'perfiles' ? 'Leyendo los perfiles…' : typeof msg.texto === 'string' ? msg.texto : '';
      chrome.tabs.sendMessage(viva.origen, { tipo: 'WA_FICHAS_AVANCE', id, paso: String(msg.paso || ''), texto }).catch(() => {});
    }
    return false;
  }

  // La pantalla de MaKo cuenta cómo sigue (guardando, el final): al registro. Al terminar, de vuelta a MaKo.
  if (msg?.tipo === 'WA_EXTRACCION') {
    if (!pedidoPermitido(_s)) { responder({ ok: false, error: 'origen' }); return false; }
    const id = typeof msg.id === 'string' ? msg.id : '';
    const c = {};
    for (const k of ['fase', 'estado', 'texto']) if (typeof msg[k] === 'string') c[k] = msg[k].slice(0, 400);
    for (const k of ['guardados', 'nombres', 'empresas', 'nuevos', 'total', 'perfiles']) if (typeof msg[k] === 'number' && Number.isFinite(msg[k])) c[k] = msg[k];
    void anotarExtraccion(id, c);
    if (c.estado && c.estado !== 'corriendo') {
      const viva = extraccionesVivas.get(id);
      extraccionesVivas.delete(id);
      // Lo que siga andando en WhatsApp Web para esta extracción, se para (MEDIDO 27/10: la pantalla se rindió y el recorrido
      // siguió solo diez minutos; la extracción siguiente chocó con él).
      if (viva) {
        viva.cerrada = true;
        if (viva.waTab != null) chrome.tabs.sendMessage(viva.waTab, { tipo: 'WA_RECORRER_PARAR', id }).catch(() => {});
      }
      volverAMako(viva ?? { origen: _s?.tab?.id, waTab: null }, id);
    }
    responder?.({ ok: true });
    return false;
  }

  // «Parar», desde el desplegable: corta el recorrido en WhatsApp Web y el guardado en MaKo.
  if (msg?.tipo === 'WA_PARAR') {
    if (!pedidoPermitido(_s)) { responder({ ok: false, error: 'origen' }); return false; }
    const id = typeof msg.id === 'string' ? msg.id : '';
    const viva = extraccionesVivas.get(id);
    if (viva) {
      viva.parado = true;
      if (viva.waTab != null) chrome.tabs.sendMessage(viva.waTab, { tipo: 'WA_RECORRER_PARAR', id }).catch(() => {});
      if (viva.origen != null) chrome.tabs.sendMessage(viva.origen, { tipo: 'WA_FICHAS_PARAR', id }).catch(() => {});
    }
    void anotarExtraccion(id, viva ? { fase: 'parando' } : { estado: 'parado', fase: 'parado' });
    responder?.({ ok: true });
    return false;
  }

  // Cómo está WhatsApp Web, para el desplegable (0.72.3, como el estado de Flow): SÓLO MIRA. Sin pestaña, sin despertar ni
  // inyectar nada; una dormida o sin el script dice «se está preparando» y se arregla al extraer.
  if (msg?.tipo === 'WA_ESTADO') {
    if (!pedidoPermitido(_s)) { responder({ ok: false, error: 'origen' }); return false; }
    void (async () => {
      try {
        const tab = (await chrome.tabs.query({})).find(esPestanaDeWhatsapp);
        if (!tab) { responder({ pestana: false }); return; }
        if (tab.discarded) { responder({ pestana: true, sesion: 'dormida' }); return; }
        const p = await pingWhatsapp(tab.id);
        responder({ pestana: true, sesion: p ? (p.sesion || (p.base === false ? 'cargando' : 'lista')) : 'sin_script' });
      } catch { responder({ pestana: null }); }
    })();
    return true;
  }

  // «Ir a WhatsApp Web» desde MaKo (para iniciar la sesión, 25/10/2026): la pestaña que hay, al frente; si no hay, una nueva.
  if (msg?.tipo === 'WA_ENFOCAR') {
    if (!pedidoPermitido(_s)) { responder({ ok: false, error: 'origen' }); return false; }
    void (async () => {
      try {
        const tabs = await chrome.tabs.query({});
        const tab = tabs.find(esPestanaDeWhatsapp);
        if (tab) {
          await chrome.tabs.update(tab.id, { active: true });
          if (tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true });
        } else {
          await chrome.tabs.create({ url: WA_WEB, active: true });
        }
        responder({ ok: true });
      } catch { responder({ ok: false }); }
    })();
    return true;
  }

  // «Capturar» desde «Sus páginas» de Spy (0.76.0, 4/11/2026). La pantalla de MaKo pide abrir ESA página a la vista; acá se abre
  // y se anota para qué. No se lee nada: la lee el desplegable cuando la persona toca el ícono en esa pestaña (`activeTab`). Si la
  // página pide comprobar que es una persona, lo hace ella.
  if (msg?.tipo === 'SPY_CAPTURAR') {
    if (!pedidoPermitido(_s) || !_s?.tab?.id) { responder({ ok: false, motivo: 'origen' }); return false; }
    const competidorId = Number(msg.competidorId);
    let url = null;
    try { const u = new URL(String(msg.url)); if (u.protocol === 'https:' || u.protocol === 'http:') url = u.toString(); } catch { url = null; }
    if (!Number.isInteger(competidorId) || competidorId <= 0 || !url) { responder({ ok: false, motivo: 'pedido' }); return false; }
    void (async () => {
      try {
        const t = await chrome.tabs.create({ url, active: true, openerTabId: _s.tab.id, index: (_s.tab.index ?? 0) + 1 });
        await anotarCaptura(t.id, { competidorId, url, spyTabId: _s.tab.id, desde: Date.now() });
        responder({ ok: true });
      } catch { responder({ ok: false, motivo: 'abrir' }); }
    })();
    return true;
  }
  // El desplegable guardó la captura: se cierra esa pestaña, se vuelve a Spy y se le avisa (la pantalla la muestra sola).
  if (msg?.tipo === 'SPY_CAPTURA_LISTA') {
    if (_s?.tab) { responder({ ok: false }); return false; }
    void (async () => {
      const p = await sacarCaptura(Number(msg.tabId));
      if (p) {
        await chrome.tabs.remove(Number(msg.tabId)).catch(() => {});
        await volverASpy(p, { lista: true });
      }
      responder({ ok: !!p });
    })();
    return true;
  }

  // El reloj del motor por interfaz. La pestaña de Flow está de fondo y Chrome le
  // frena los timers (hasta uno por minuto); el del service worker no.
  if (msg?.tipo === 'INTERFAZ_DORMIR') {
    setTimeout(() => responder({ ok: true }), Math.max(0, Math.min(Number(msg.ms) || 0, 30000)));
    return true;
  }

  // ⚠️ ESTADO SE LEE DE STORAGE, NO DE LOS GLOBALES.
  //
  // Contestaba `{ conectado: !!bearer }` de forma SINCRONA, leyendo un global que
  // se hidrata por callback al arrancar el worker. El propio `sendMessage` del
  // popup despierta al worker en frio: el callback todavia no corrio, `bearer` es
  // null, y el popup pintaba «falta abrir Flow» con Flow perfectamente abierto.
  // Un dato que depende de una carrera no es un dato.
  if (msg?.tipo === 'ESTADO') {
    chrome.storage.local.get(
      ['token', 'bearer', 'apiKey', 'ultimoLatido', 'saldoLocal', 'emparejando', 'emparejandoDesde', 'emparejarError', 'emparejarCuando', 'emparejarEtiqueta', 'workspaceNombre', 'versionEsperada'],
      async (v) => {
        let hayFlow = false;
        // Dos preguntas y no una: «hay pestana de Flow» y «esa pestana esta dentro de
        // un proyecto». Ver `enProyectoDeFlow`: sin la segunda, a alguien logueado se
        // le pide que inicie sesion.
        let flowEnProyecto = false;
        let flowNuevo = false;
        // ⚠️ SI YA APRENDIÓ A GENERAR, y no es un adorno: es lo único que le dice a
        // la persona si la generación de prueba sirvió. Sin esto genera a ciegas y
        // no tiene forma de saber si hay que repetirla.
        //
        // `sentinela` lo escribe el espejo cuando encuentra la frase conocida dentro
        // del cuerpo capturado; si es `null`, la plantilla existe pero no sabemos
        // dónde va el prompt — que es un estado distinto de «no hay plantilla» y se
        // muestra distinto.
        // Que operaciones ya sabe hacer, y cual toca ensenar. Reemplaza al booleano:
        // «aprendio» sin decir QUE no es una respuesta cuando son cinco.
        let ops = {};
        let siguiente = null;
        // El juicio entero, para que el popup no pueda leer «no falta nada que
        // enseñar» como «puede filmar»: con el motor por interfaz no se enseña nada
        // y aun así la pestaña puede no estar lista.
        let juicio = null;
        // ⚠️ SI LA GUARDIA TUVO QUE DEVOLVER LA PESTAÑA, hay que decirlo. Sin esto,
        // la persona ve que Flow «se movió solo» y no sabe que fue MaKo — que es
        // peor que no haberla movido: parece que el navegador hace cosas raras.
        let volviAlProyecto = false;
        try {
          const g = (await chrome.storage.local.get(CLAVE_CUIDANDO))[CLAVE_CUIDANDO];
          volviAlProyecto = !!(g && g.avisado);
        } catch { volviAlProyecto = false; }
        try {
          const guardadas = (await chrome.storage.local.get(CLAVE_PLANTILLAS))[CLAVE_PLANTILLAS] || {};
          // ⚠️ SE PREGUNTA POR LA PROPIEDAD, NO POR LA CLAVE.
          //
          // Esto era `guardadas['boq:YhhmEf']`, un rpcid MEDIDO el 04/09 contra el bundle
          // de ese dia. Dos formas de que la clave no sea esa con la captura perfecta al
          // lado: Google despliega un bundle nuevo y el rpcid rota, o BOQ manda la
          // generacion en un batch (`rpcids=YhhmEf,ngNC2`) y la clase es 'boq:YhhmEf,ngNC2'.
          // En los dos casos el lookup exacto contesta `undefined` — y `undefined` no se
          // queja, se lee como «no aprendio».
          //
          // La sentinela solo la puede tener el pedido que llevaba la frase, o sea el de
          // generar. No hace falta saber su rpcid para reconocerlo.
          // Una entrada por operacion aprendida, con la clase que la trajo. La clase
          // es un DATO, no la llave: el rpcid rota con el bundle de Google.
          for (const [clase, p] of Object.entries(guardadas)) {
            if (!p || !p.op) continue;
            // ⚠️ UN SET, NO UN DETALLE. Los seis consumidores preguntan por truthiness
            // o por las llaves; `clase`, `donde` y `cuando` viajaban y se tiraban.
            //
            // Y no era solo ruido: dos plantillas que resuelven a la MISMA operacion
            // hacian que la segunda pisara a la primera, asi que esos tres campos
            // terminaban siendo «los de la ultima que itero» — un dato sin dueno, que
            // es peor que no tenerlo porque alguien lo va a leer creyendo que decide.
            ops[p.op] = true;
          }
          // Y las que se aprenden mirando trafico se dan por sabidas cuando su clase
          // esta guardada, aunque no lleven ancla: no hay frase que buscarles.
          for (const o of A_ENSENAR) {
            if (o.como !== 'trafico' || ops[o.op]) continue;
            const hit = Object.entries(guardadas).find(([, p]) => p && p.op === o.op);
            if (hit) ops[o.op] = true;
          }
          // ⚠️ SALE DE `A_PEDIR`, NO DE `A_ENSENAR`, Y LA DIFERENCIA ES UN BUG QUE YA
          // SE REPORTO.
          //
          // `creditos` y `estado_clips` se aprenden solas mirando lo que Flow hace
          // igual: no hay NINGUNA accion que la persona pueda tomar para que pasen
          // antes. Ofrecerlas como «el siguiente paso» mostraba una pantalla que pide
          // algo imposible, con un boton «Entendido» que solo cerraba la ventana.
          // Reportado textual: «le doy a Entendido y no hace nada».
          //
          // Y lo caro no era el boton muerto: dejaba TRABADO ahi, sin llegar nunca a
          // las tres que si necesitan a la persona.
          // ⚠️ Y LAS QUE PIDEN ALGO SE RE-JUZGAN CON EL ENSAYO EN SECO.
          //
          // Tener una entrada guardada NO es saber hacerla. El cuerpo puede estar
          // vacio, faltarle la url, o haber sido PISADO por una generacion posterior
          // de la misma clase que no llevaba la frase (el guardado conserva el `op` y
          // reemplaza el `cuerpo`). `ejecutar()` lo iba a descubrir igual, pero con el
          // boton ya apretado y el trabajo tomado.
          //
          // Ademas es lo que hace que `cuantasListas` y `siguiente` no puedan
          // contradecirse: salen del mismo juicio.
          for (const o of A_PEDIR) ops[o.op] = ensayarOperacion(guardadas, o).puede;
          // El MISMO juicio que el latido, con la misma pregunta a la pestaña: con el
          // motor por interfaz no hay nada que enseñar, y el popup no puede pedirlo.
          const ensayo = puedeFilmar(guardadas, A_PEDIR, await estadoInterfaz());
          if (ensayo.motor === 'interfaz') for (const o of A_PEDIR) ops[o.op] = ensayo.puede;
          juicio = { motor: ensayo.motor || 'plantilla', puede: ensayo.puede, porQue: ensayo.porQue };
          const falta = ensayo.falta ? A_PEDIR.find((o) => o.op === ensayo.falta) : null;
          siguiente = falta
            ? {
              op: falta.op, frase: falta.frase, que: falta.que,
              cuesta: falta.cuesta, boton: falta.boton,
            }
            : null;
        } catch {
          // ⚠️ UN `catch` NO PUEDE RESOLVER A «TODO LISTO», Y ESTE RESOLVIA.
          //
          // Dejaba `siguiente = null`, que el popup lee como «no falta nada»: un
          // error de lectura se pintaba como exito, sin dejar nada que investigar.
          // Ahora cae al PRIMER paso. Lo peor que puede pasar es pedir algo que ya
          // estaba hecho; lo peor de verdad era afirmar que se puede filmar.
          ops = {};
          const primera = A_PEDIR[0];
          siguiente = primera
            ? {
              op: primera.op, frase: primera.frase, que: primera.que,
              cuesta: primera.cuesta, boton: primera.boton,
            }
            : null;
        }
        let espejoViejo = false;
        try {
          const tf = await pestanaDeFlow();
          hayFlow = true;
          flowEnProyecto = enProyectoDeFlow(tf.url);
          flowNuevo = esFlowNuevo(tf.url);
          // ⚠️ EL ESPEJO SOBREVIVE A LA ACTUALIZACION y nadie lo decia. Medido: manifest
          // 0.64.0 con espejo 0.63.0 en la pestaña, o sea que la url absoluta y la
          // proteccion del cuerpo con ancla no corrian ahi, con el popup en verde. Un
          // espejo que no contesta NO cuenta como viejo: puede ser una pestaña dormida.
          try {
            const r = await chrome.tabs.sendMessage(tf.id, { tipo: 'VER_VERSION_ESPEJO' });
            const e = (r && r.version) || '';
            espejoViejo = !!e && e !== chrome.runtime.getManifest().version;
          } catch { /* no contesta: no se afirma nada */ }
        } catch { hayFlow = false; }
        responder({
          // Booleanos: el popup no necesita ninguna credencial, y lo que no sale
          // de aca no se puede filtrar por una pantalla.
          token: !!v.token,
          bearer: !!v.bearer,
          apiKey: !!v.apiKey,
          hayFlow,
          flowEnProyecto,
          flowNuevo,
          espejoViejo,
          ops,
          siguiente,
          juicio,
          // ⚠️ EL «N de M» CUENTA LO QUE SE PIDE, no todo lo que el puente necesita.
          // Contar las que se aprenden solas hace que el numero no baje haga lo que
          // haga la persona — un progreso que no se mueve se lee como que esta roto.
          cuantasOps: A_PEDIR.length,
          cuantasListas: A_PEDIR.filter((o) => ops[o.op]).length,
          // Y lo que se aprende solo se dice aparte, para que no parezca que falta
          // algo que nadie tiene que hacer.
          // ⚠️ TODO LO QUE FALTA Y NO SE PIDE VIAJA ACA, no solo lo que se aprende
          // solo. Son dos motivos distintos y los dos terminan en «no te lo pido»:
          //
          //   · `creditos` y `estado_clips` se aprenden solas — no hay nada que hacer.
          //   · `subir_imagen` SI pide algo, pero el sistema todavia no la sabe
          //     RECONOCER: no lleva prompt, asi que no hay texto que buscarle entre
          //     los 39 pedidos que la pagina hace. Pedirla seria pedir algo que no se
          //     puede satisfacer, y eso ya se reporto: «ya subi la foto y nada».
          //
          // Se manda igual porque callarlo hace que alguien cuente las operaciones y
          // concluya que falta algo que hacer.
          solas: A_ENSENAR.filter((o) => !ops[o.op] && !A_PEDIR.some((x) => x.op === o.op))
            .map((o) => o.op),
          // Y aparte, cuales de esas es porque todavia no las sabemos reconocer. Es un
          // limite NUESTRO y se dice como tal, no como algo que la persona deba hacer.
          // ⚠️ VIAJAN LOS NOMBRES PARA PERSONAS, NO LOS `op`. Esto se pinta en la
          // pantalla de un cliente, y un identificador de codigo ahi se lee como que
          // la app esta a medio hacer. Ya paso.
          sinDetectar: SIN_DETECTAR.filter((o) => !ops[o.op]).map((o) => o.nombre),
          volviAlProyecto,
          ultimoLatido: v.ultimoLatido || null,
          saldo: v.saldoLocal || null,
          emparejando: !!v.emparejando,
          emparejandoDesde: Number(v.emparejandoDesde) || 0,
          emparejarError: v.emparejarError || '',
          emparejarCuando: Number(v.emparejarCuando) || 0,
          emparejarEtiqueta: v.emparejarEtiqueta || '',
          workspace: v.workspaceNombre || '',
          version: chrome.runtime.getManifest().version,
          // ⚠️ LA COMPARACION SE HACE ACA, no en el popup. `esMasVieja` ya vive
          // en este archivo y compara ORDENADO —no `!==`—, porque una igualdad
          // tambien dispara cuando la instalada va ADELANTE: la maquina de
          // desarrollo, los minutos entre el push y el deploy, y para siempre si
          // el build fallo. Duplicarla en el popup serian dos respuestas posibles
          // a la misma pregunta.
          versionEsperada: v.versionEsperada || '',
          // ⚠️ `deLaTienda` VIAJABA ACA Y NO LO LEIA NADIE — el mismo modo de
          // falla que `r.resultado`, en chiquito y recien nacido. Su condicion
          // (de la tienda actualiza Chrome solo, asi que ahi no hay paso a paso
          // que dar y frenar seria encerrar a alguien esperando a Google) ya vive
          // adentro de `versionVieja`, dos lineas mas abajo. Un campo de mas es
          // un contrato que alguien va a leer creyendo que decide algo.
          versionVieja: !!v.versionEsperada
            && !chrome.runtime.getManifest().update_url
            && esMasVieja(chrome.runtime.getManifest().version, v.versionEsperada),
        });
      },
    );
    return true;
  }
  if (msg?.tipo === 'CONECTAR') { void conectar(!!msg.forzar).then(responder); return true; }
  if (msg?.tipo === 'RECARGAR_MAKO') { void recargarMako().then(responder); return true; }
  if (msg?.tipo === 'ABRIR_FLOW') { void abrirFlow().then(responder); return true; }
  // Se limpia el aviso cuando el popup ya lo mostró: es un EVENTO, no un estado, y
  // dejarlo puesto lo repetiría cada vez que se abre el popup.
  if (msg?.tipo === 'AVISO_VISTO') {
    void (async () => {
      try {
        const g = (await chrome.storage.local.get(CLAVE_CUIDANDO))[CLAVE_CUIDANDO];
        if (g) await chrome.storage.local.set({ [CLAVE_CUIDANDO]: { ...g, avisado: false } });
      } catch { /* nada */ }
      responder({ ok: true });
    })();
    return true;
  }
  if (msg?.tipo === 'PREPARAR') { void prepararEscenario().then(responder, (e) => responder({ ok: false, error: String((e && e.message) || e) })); return true; }
  if (msg?.tipo === 'RECARGAR_FLOW') { void recargarFlow().then(responder); return true; }
  if (msg?.tipo === 'SALDO') { void saldoLocal(true).then(responder); return true; }
  if (msg?.tipo === 'LATIR') { void ciclo().then(() => responder({ ok: true })); return true; }
  // ⚠️ El `return true` estaba FUERA del if, asi que dejaba el canal abierto para
  // TODO mensaje desconocido y el emisor esperaba una respuesta que no llegaba
  // nunca.
  return false;
});
