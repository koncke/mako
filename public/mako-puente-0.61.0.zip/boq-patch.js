// =============================================================================
// GENERADO por scripts/sync-boq-patch.mjs desde lib/flow-boq-patch.ts — NO EDITAR A MANO
// =============================================================================
// El pre-push falla si quedó viejo. El desfase acá es caro de una forma concreta:
// este módulo decide el cuerpo de un pedido que GASTA CRÉDITOS del cliente, así que
// dos versiones distintas significa que la que corre no es la que se probó.
// =============================================================================

// El puente funciona COPIANDO el pedido que hace la propia página de Flow, porque
// reconstruirlo a mano falló cinco veces. Para repetirlo con OTRO prompt hay que
// meter el texto nuevo donde estaba el viejo.
//
// ⚠️ NO SE PARSEA EL ÁRBOL, Y ES UNA DECISIÓN. El cuerpo de BOQ es
// `f.req=<array JSON anidado y POSICIONAL>&at=<token>`: sin nombres de campo, con
// varios niveles de escapado, y con una forma que Google cambia cuando quiere. Un
// parcheador que camina ese árbol adivina la posición del prompt — y este repo ya
// tiene escrito que si hay que desempatar, todavía estás adivinando.
//
// Lo que NO es una adivinanza: la frase de aprendizaje. La persona la escribió
// exacta, así que sabemos el texto literal que Flow puso en ese cuerpo. Se busca
// ESE string, con la codificación con la que viajó, y se reemplaza. No hace falta
// saber en qué posición del array vive ni cómo se llama.
//
// ⚠️ SIN `server-only`: esto arma el cuerpo de un pedido que gasta créditos del
// cliente. Es exactamente la clase de código que necesita test.

/**
 * Las formas en que un texto puede viajar dentro de un cuerpo.
 *
 * ⚠️ CADA UNA ES SU PROPIO INVERSO PORQUE SE APLICA, NO SE DESHACE. Para reemplazar
 * no hace falta decodificar el cuerpo: alcanza con codificar el texto viejo (para
 * encontrarlo) y el nuevo (para ponerlo). Decodificar el cuerpo entero sería
 * reescribir partes que no son nuestras.
 */
const CODS = Object.freeze([
  ['crudo', (t) => t],
  ['json', (t) => JSON.stringify(t).slice(1, -1)],
  ['uri', (t) => encodeURIComponent(t)],
  ['json+uri', (t) => encodeURIComponent(JSON.stringify(t).slice(1, -1))],
  ['form', (t) => new URLSearchParams({ x: t }).toString().slice(2)],
  ['json2', (t) => JSON.stringify(JSON.stringify(t).slice(1, -1)).slice(1, -1)],
  ['json2+uri', (t) => encodeURIComponent(JSON.stringify(JSON.stringify(t).slice(1, -1)).slice(1, -1))],
  ['json2+form', (t) => new URLSearchParams({ x: JSON.stringify(JSON.stringify(t).slice(1, -1)).slice(1, -1) }).toString().slice(2)],
]);

/** Aplica una codificación por su nombre, o `null` si no existe. */
export function codificar(texto, nombre) {
  const c = CODS.find(([n]) => n === nombre);
  return c ? c[1](texto) : null;
}

/** Los nombres de codificación conocidos, para que un test los pueda recorrer. */
export const CODIFICACIONES = Object.freeze(CODS.map(([n]) => n));

/**
 * Con qué codificación aparece `texto` en `cuerpo`, o `null`.
 *
 * Se prueban de la más simple a la más anidada: la primera que matchea gana. Con un
 * texto que tenga espacios eso es determinista, porque cada codificación produce un
 * string distinto.
 */
export function comoViajo(cuerpo, texto) {
  if (!cuerpo || !texto) return null;
  for (const [nombre, cod] of CODS) {
    try { if (cuerpo.includes(cod(texto))) return nombre; } catch { /* sigue */ }
  }
  return null;
}

/**
 * Deja un prompt en condiciones de entrar en un cuerpo ya codificado.
 *
 * ⚠️ SE SACAN LAS COMILLAS, LAS BARRAS Y LOS SALTOS, y no es paranoia de más: el
 * prompt entra a un string JSON que a su vez vive adentro de otro string JSON. Una
 * comilla doble sin escapar cierra el string un nivel antes y el `f.req` deja de
 * ser un array válido — Google contesta 400 y el error apunta a nuestro cuerpo, no
 * al carácter.
 *
 * No se ESCAPAN, se SACAN: escaparlos bien exige saber cuántos niveles de anidado
 * hay, que es justo lo que este módulo evita averiguar. Un prompt sin comillas dice
 * lo mismo; un prompt mal escapado no dice nada.
 */
export function sanearPrompt(texto, tope = 2000) {
  return String(texto || '')
    // ⚠️ LOS CONTROLES VAN COMO ESCAPES, NUNCA COMO BYTES. Un caracter de control
    // crudo en el fuente hace que la busqueda del repo declare el archivo BINARIO y
    // no devuelva ni una linea — y ahi el archivo se lee igual que si no tuviera lo
    // que buscas. Cubre \n, \r, \t y el DEL.
    .replace(/[\u0000-\u001f\u007f]+/g, ' ')
    // Comillas —rectas y tipograficas— y barras invertidas: es lo que rompe el
    // anidado de strings JSON. Se SACAN en vez de reemplazarse por espacio, para no
    // partir una palabra al medio.
    .replace(/["'\u2018\u2019\u201c\u201d\\]+/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, tope);
}


/**
 * Reemplaza `viejo` por `nuevo` dentro de `cuerpo`, respetando cómo viajó.
 *
 * ⚠️ FALLA EN VEZ DE ADIVINAR. Si la frase no aparece con ninguna codificación
 * conocida, devuelve `SIN_ANCLA` y NO toca el cuerpo. Mandar el pedido con el
 * prompt de la frase de aprendizaje sería generar —y cobrarle al cliente— un cubo
 * violeta girando sobre arena en vez de su anuncio.
 */
export function reemplazarEnCuerpo(cuerpo, viejo, nuevo) {
  if (!cuerpo) return { ok: false, error: 'CUERPO_VACIO', donde: null };
  const limpio = sanearPrompt(nuevo);
  if (!limpio) return { ok: false, error: 'PROMPT_VACIO', donde: null };

  const donde = comoViajo(cuerpo, viejo);
  if (!donde) return { ok: false, error: 'SIN_ANCLA', donde: null };

  const buscar = codificar(viejo, donde);
  const poner = codificar(limpio, donde);
  if (buscar == null || poner == null) return { ok: false, error: 'SIN_ANCLA', donde };

  // ⚠️ SE REEMPLAZAN TODAS LAS APARICIONES, y se cuentan.
  //
  // Flow manda el prompt más de una vez en el mismo cuerpo (el pedido y su eco de
  // telemetría), y dejar una sin cambiar es la peor mezcla: el pedido sale, cuesta
  // un crédito, y trae un video del prompt equivocado. El conteo se devuelve para
  // que quien llama pueda decidir si le cierra.
  let cuantas = 0;
  let i = cuerpo.indexOf(buscar);
  let out = '';
  let desde = 0;
  while (i !== -1) {
    out += cuerpo.slice(desde, i) + poner;
    desde = i + buscar.length;
    cuantas++;
    i = cuerpo.indexOf(buscar, desde);
  }
  out += cuerpo.slice(desde);

  return { ok: true, cuerpo: out, donde, cuantas };
}

/**
 * Repone el `at` redactado con uno vivo.
 *
 * ⚠️ EL `at` NUNCA SE GUARDA, Y ÉSTA ES LA CONTRAPARTE. `sinCredenciales` lo
 * reemplaza por `__MAKO_AT__` antes de persistir, a propósito: es el token
 * anti-CSRF de la sesión de Google del cliente. Al repetir el pedido hay que poner
 * uno FRESCO, del tráfico vivo de la pestaña.
 *
 * Devuelve `null` si el cuerpo no tiene la marca — eso significa que la plantilla
 * se guardó con otra versión del espejo, y mandarla con un `at` que no es de esta
 * sesión da un rechazo que se lee como un problema de la cuenta del cliente.
 */
export function reponerAt(cuerpo, atVivo) {
  if (!cuerpo || !atVivo) return null;
  if (!cuerpo.includes('__MAKO_AT__')) return null;
  // El `at` va tal cual en un form-urlencoded, pero puede traer `:` y `_`, que son
  // seguros. Se codifica igual por si trae algo más.
  return cuerpo.replace(/__MAKO_AT__/g, encodeURIComponent(atVivo));
}
